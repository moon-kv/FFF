"""Для администратора гостиницы реализовать следующий функционал:

- фильтрацию записей в таблице по указанному периоду. Пользователь указывает начало периода, конец периода и по нажатию кнопки «Фильтровать» должна происходить фильтрация данных в таблице, т.е. отображаться бронирования, попадающие в указанный диапазон. По нажатию на кнопку «Показать все» отменяется фильтрация записей;
- ввод анкетных данных вновь прибывшего гостя. Помимо стандартной информации (паспортные данные, цель приезда, планируемые сроки проживания), указать дополнитель-ную информацию: оценку уровня притязаний клиента, индивидуальные пожелания, пере-чень скидок на услуги;
- изменение параметров размещения (можно поменять нужные параметры на новые, после нажатия кнопки «Изменить» изменённые параметры вступают в силу);
- обновление для всех номеров со статусом "Назначен к уборке" статус "Чистый";


- регистрация оплаты проживания и/или услуг гостя либо выписка счёта на возврат (автоматически учитываются все оказанные гостю дополнительные услуги и заданные скидки);
- формирование счёта за оказанные услуги (можно настроить печать счёта и разбить услуги на несколько счетов).


Для клиентов и гостей гостиницы реализовать следующий функционал:
- просмотр свободных номеров гостиницы по указанному периоду. Создать функцию для проверки наличия свободных номеров при попытке бронирования с выводом статуса;
- ввод анкетных данных (паспортные данные, цель приезда, планируемые сроки про-живания), дополнительной информации (выбор из перечня) при бронировании номера;
- просматривать статус заявки;



- задавать вопросы о предстоящем проживании, особенностях номера, услугах и дру-гих деталях пребывания, просматривать переписку.




помоги реализовать простую базу данных на mysql в mysql workbench. также помоги реализовать простой интерфейс для написания (+ должна быть авторизация в программе)
реализуй код в разных модулях (типа окно администратора и окно клиента)"""

import sys
import traceback
from PyQt6.QtWidgets import QApplication
from PyQt6.QtCore import Qt
from database import Database
from auth_window import AuthWindow
from admin_panel import AdminPanel
from client_panel import ClientPanel


def excepthook(exctype, value, tb):
    """Обработчик необработанных исключений"""
    print("Произошла ошибка:")
    traceback.print_exception(exctype, value, tb)
    sys.exit(1)


class HotelManagementSystem:
    def __init__(self):
        self.db = Database()
        sys.excepthook = excepthook

        # Устанавливаем высокий DPI масштабирование для Windows
        QApplication.setHighDpiScaleFactorRoundingPolicy(
            Qt.HighDpiScaleFactorRoundingPolicy.PassThrough
        )

        self.app = QApplication(sys.argv)
        self.app.setStyle('Fusion')  # Более стабильный стиль

    def run(self):
        # Подключаемся к базе данных
        if not self.db.connect():
            print("Не удалось подключиться к базе данных")
            sys.exit(1)

        try:
            # Показываем окно авторизации
            auth_window = AuthWindow(self.db, self.on_auth_success)
            auth_window.show()

            sys.exit(self.app.exec())
        except Exception as e:
            print(f"Ошибка при запуске приложения: {e}")
            traceback.print_exc()
            sys.exit(1)

    def on_auth_success(self, user):
        try:
            # Открываем соответствующую панель в зависимости от роли
            if user['role'] == 'admin':
                self.admin_panel = AdminPanel(self.db, user)
                self.admin_panel.show()
            elif user['role'] == 'client':
                self.client_panel = ClientPanel(self.db, user)
                self.client_panel.show()
            else:
                print(f"Неизвестная роль: {user['role']}")
        except Exception as e:
            print(f"Ошибка при открытии панели: {e}")
            traceback.print_exc()


if __name__ == "__main__":
    print("Запуск системы управления гостиницей...")
    system = HotelManagementSystem()
    system.run()