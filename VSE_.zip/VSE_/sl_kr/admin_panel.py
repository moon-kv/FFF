from PyQt6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                             QTabWidget, QTableWidget, QTableWidgetItem, QPushButton,
                             QLabel, QLineEdit, QDateEdit, QComboBox, QTextEdit,
                             QGroupBox, QMessageBox, QHeaderView, QFormLayout,
                             QTimeEdit, QGridLayout)
from PyQt6.QtCore import Qt, QDate, QTime
from PyQt6.QtGui import QFont, QColor
from pymysql import Error
from datetime import datetime, timedelta


class AdminPanel(QMainWindow):
    def __init__(self, db, user):
        super().__init__()
        self.db = db
        self.user = user
        self.current_editing_appointment_id = None

        self.setWindowTitle(f"Панель администратора - {user['full_name']}")
        self.setGeometry(100, 100, 1400, 800)

        self.setup_ui()
        self.load_initial_data()

    def setup_ui(self):
        # Центральный виджет
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        # Основной layout
        main_layout = QVBoxLayout(central_widget)

        # Вкладки
        self.tabs = QTabWidget()

        # Создаем вкладки
        self.create_appointments_tab()
        self.create_clients_tab()
        self.create_masters_tab()

        main_layout.addWidget(self.tabs)

    def create_appointments_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        # ФОРМА ЗАПИСИ
        appointment_form_group = QGroupBox("Форма записи на прием")
        appointment_form_layout = QVBoxLayout()

        # Первый ряд: Клиент и Мастер
        first_row = QHBoxLayout()
        first_row.addWidget(QLabel("Клиент:"))
        self.client_combo = QComboBox()
        self.client_combo.setMinimumWidth(300)
        first_row.addWidget(self.client_combo)

        first_row.addWidget(QLabel("Мастер:"))
        self.master_combo = QComboBox()
        self.master_combo.setMinimumWidth(250)
        self.master_combo.currentIndexChanged.connect(self.update_services_combo)
        first_row.addWidget(self.master_combo)

        first_row.addStretch()
        appointment_form_layout.addLayout(first_row)

        # Второй ряд: Услуга и Дата
        second_row = QHBoxLayout()
        second_row.addWidget(QLabel("Услуга:"))
        self.service_combo = QComboBox()
        self.service_combo.setMinimumWidth(250)
        self.service_combo.currentIndexChanged.connect(self.update_duration_and_price)
        second_row.addWidget(self.service_combo)

        second_row.addWidget(QLabel("Дата:"))
        self.appointment_date = QDateEdit()
        self.appointment_date.setDate(QDate.currentDate().addDays(1))
        self.appointment_date.setCalendarPopup(True)
        self.appointment_date.setMinimumDate(QDate.currentDate())
        self.appointment_date.dateChanged.connect(self.check_time_availability)
        second_row.addWidget(self.appointment_date)

        second_row.addStretch()
        appointment_form_layout.addLayout(second_row)

        # Третий ряд: Время и Длительность
        third_row = QHBoxLayout()
        third_row.addWidget(QLabel("Время:"))
        self.appointment_time = QTimeEdit()
        self.appointment_time.setTime(QTime(9, 0))
        self.appointment_time.timeChanged.connect(self.check_time_availability)
        third_row.addWidget(self.appointment_time)

        third_row.addWidget(QLabel("Длительность (мин):"))
        self.duration_input = QLineEdit()
        self.duration_input.setReadOnly(True)
        self.duration_input.setMaximumWidth(80)
        third_row.addWidget(self.duration_input)

        third_row.addWidget(QLabel("Стоимость:"))
        self.price_input = QLineEdit()
        self.price_input.setReadOnly(True)
        self.price_input.setMaximumWidth(100)
        third_row.addWidget(self.price_input)

        third_row.addStretch()
        appointment_form_layout.addLayout(third_row)

        # Четвертый ряд: Статус
        fourth_row = QHBoxLayout()
        fourth_row.addWidget(QLabel("Статус:"))
        self.status_combo = QComboBox()
        self.status_combo.addItems(['scheduled', 'completed', 'cancelled', 'no_show'])
        fourth_row.addWidget(self.status_combo)

        fourth_row.addWidget(QLabel("Примечания:"))
        self.notes_text = QTextEdit()
        self.notes_text.setMaximumHeight(60)
        fourth_row.addWidget(self.notes_text)

        appointment_form_layout.addLayout(fourth_row)

        # Кнопки управления формой
        buttons_row = QHBoxLayout()
        self.new_appointment_btn = QPushButton("Создать запись")
        self.new_appointment_btn.clicked.connect(self.create_appointment_from_form)
        buttons_row.addWidget(self.new_appointment_btn)

        self.update_appointment_btn = QPushButton("Обновить запись")
        self.update_appointment_btn.clicked.connect(self.update_appointment_from_form)
        self.update_appointment_btn.setEnabled(False)
        buttons_row.addWidget(self.update_appointment_btn)

        self.delete_appointment_btn = QPushButton("Удалить запись")
        self.delete_appointment_btn.clicked.connect(self.delete_appointment)
        self.delete_appointment_btn.setEnabled(False)
        buttons_row.addWidget(self.delete_appointment_btn)

        buttons_row.addStretch()
        appointment_form_layout.addLayout(buttons_row)

        appointment_form_group.setLayout(appointment_form_layout)
        layout.addWidget(appointment_form_group)

        # Группа фильтров
        filter_group = QGroupBox("Фильтр записей")
        filter_layout = QVBoxLayout()

        # Фильтр по дате
        date_filter_layout = QHBoxLayout()
        date_filter_layout.addWidget(QLabel("Период с:"))
        self.start_date_filter = QDateEdit()
        self.start_date_filter.setDate(QDate.currentDate())
        self.start_date_filter.setCalendarPopup(True)
        date_filter_layout.addWidget(self.start_date_filter)

        date_filter_layout.addWidget(QLabel("по:"))
        self.end_date_filter = QDateEdit()
        self.end_date_filter.setDate(QDate.currentDate().addDays(30))
        self.end_date_filter.setCalendarPopup(True)
        date_filter_layout.addWidget(self.end_date_filter)

        filter_button = QPushButton("Фильтровать по дате")
        filter_button.clicked.connect(self.filter_appointments_by_date)
        date_filter_layout.addWidget(filter_button)

        date_filter_layout.addStretch()
        filter_layout.addLayout(date_filter_layout)

        # Фильтр по услуге
        service_filter_layout = QHBoxLayout()
        service_filter_layout.addWidget(QLabel("Услуга:"))
        self.service_filter_combo = QComboBox()
        self.service_filter_combo.addItem("Все услуги", 0)
        service_filter_layout.addWidget(self.service_filter_combo)

        filter_service_button = QPushButton("Фильтровать по услуге")
        filter_service_button.clicked.connect(self.filter_appointments_by_service)
        service_filter_layout.addWidget(filter_service_button)

        show_all_button = QPushButton("Показать все")
        show_all_button.clicked.connect(self.show_all_appointments)
        service_filter_layout.addWidget(show_all_button)

        service_filter_layout.addStretch()
        filter_layout.addLayout(service_filter_layout)

        filter_group.setLayout(filter_layout)
        layout.addWidget(filter_group)

        # Таблица записей
        self.appointments_table = QTableWidget()
        self.appointments_table.setColumnCount(10)
        self.appointments_table.setHorizontalHeaderLabels([
            "ID", "Клиент", "Телефон", "Мастер", "Услуга",
            "Дата", "Время", "Длительность", "Стоимость", "Статус"
        ])

        header = self.appointments_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)  # Клиент
        header.setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)  # Мастер

        self.appointments_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.appointments_table.clicked.connect(self.on_appointment_table_click)

        layout.addWidget(self.appointments_table)

        self.tabs.addTab(tab, "Записи")

        # Загружаем данные для формы
        self.load_clients_for_combo()
        self.load_masters_for_combo()
        self.load_services_for_filter()

    def create_clients_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        # ФОРМА РЕГИСТРАЦИИ КЛИЕНТА
        client_form_group = QGroupBox("Регистрация нового клиента")
        client_form_layout = QGridLayout()

        # Ряд 1: ФИО и телефон
        client_form_layout.addWidget(QLabel("ФИО:"), 0, 0)
        self.new_client_name = QLineEdit()
        self.new_client_name.setPlaceholderText("Иванов Иван Иванович")
        client_form_layout.addWidget(self.new_client_name, 0, 1)

        client_form_layout.addWidget(QLabel("Телефон:"), 0, 2)
        self.new_client_phone = QLineEdit()
        self.new_client_phone.setPlaceholderText("+79991234567")
        client_form_layout.addWidget(self.new_client_phone, 0, 3)

        # Ряд 2: Email и дата рождения
        client_form_layout.addWidget(QLabel("Email:"), 1, 0)
        self.new_client_email = QLineEdit()
        self.new_client_email.setPlaceholderText("client@mail.ru")
        client_form_layout.addWidget(self.new_client_email, 1, 1)

        client_form_layout.addWidget(QLabel("Дата рождения:"), 1, 2)
        self.new_client_birth_date = QDateEdit()
        self.new_client_birth_date.setCalendarPopup(True)
        self.new_client_birth_date.setDate(QDate(1990, 1, 1))
        client_form_layout.addWidget(self.new_client_birth_date, 1, 3)

        # Ряд 3: Логин и пароль
        client_form_layout.addWidget(QLabel("Логин:"), 2, 0)
        self.new_client_username = QLineEdit()
        self.new_client_username.setPlaceholderText("Логин для входа")
        client_form_layout.addWidget(self.new_client_username, 2, 1)

        client_form_layout.addWidget(QLabel("Пароль:"), 2, 2)
        self.new_client_password = QLineEdit()
        self.new_client_password.setPlaceholderText("Пароль для входа")
        client_form_layout.addWidget(self.new_client_password, 2, 3)

        # Ряд 4: Примечания
        client_form_layout.addWidget(QLabel("Примечания:"), 3, 0)
        self.new_client_notes = QTextEdit()
        self.new_client_notes.setMaximumHeight(50)
        client_form_layout.addWidget(self.new_client_notes, 3, 1, 1, 3)

        # Ряд 5: Кнопки
        client_buttons_layout = QHBoxLayout()
        register_client_btn = QPushButton("Зарегистрировать клиента")
        register_client_btn.clicked.connect(self.register_new_client)
        client_buttons_layout.addWidget(register_client_btn)

        clear_client_btn = QPushButton("Очистить форму")
        clear_client_btn.clicked.connect(self.clear_client_form)
        client_buttons_layout.addWidget(clear_client_btn)

        client_buttons_layout.addStretch()
        client_form_layout.addLayout(client_buttons_layout, 4, 0, 1, 4)

        client_form_group.setLayout(client_form_layout)
        layout.addWidget(client_form_group)

        # Таблица клиентов
        self.clients_table = QTableWidget()
        self.clients_table.setColumnCount(6)
        self.clients_table.setHorizontalHeaderLabels([
            "ID", "ФИО", "Телефон", "Email", "Дата рождения", "Дата регистрации"
        ])

        header = self.clients_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)  # ФИО

        layout.addWidget(self.clients_table)

        self.tabs.addTab(tab, "Клиенты")

    def create_masters_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        # ФОРМА ДОБАВЛЕНИЯ МАСТЕРА
        master_form_group = QGroupBox("Добавление нового мастера")
        master_form_layout = QGridLayout()

        # Ряд 1: ФИО и специализация
        master_form_layout.addWidget(QLabel("ФИО:"), 0, 0)
        self.new_master_name = QLineEdit()
        self.new_master_name.setPlaceholderText("Иванова Мария Петровна")
        master_form_layout.addWidget(self.new_master_name, 0, 1)

        master_form_layout.addWidget(QLabel("Специализация:"), 0, 2)
        self.new_master_specialization = QComboBox()
        self.new_master_specialization.addItems([
            "Парикмахер", "Мастер маникюра", "Косметолог",
            "Барбер", "Массажист", "Визажист"
        ])
        master_form_layout.addWidget(self.new_master_specialization, 0, 3)

        # Ряд 2: Телефон и email
        master_form_layout.addWidget(QLabel("Телефон:"), 1, 0)
        self.new_master_phone = QLineEdit()
        self.new_master_phone.setPlaceholderText("+79991234567")
        master_form_layout.addWidget(self.new_master_phone, 1, 1)

        master_form_layout.addWidget(QLabel("Email:"), 1, 2)
        self.new_master_email = QLineEdit()
        self.new_master_email.setPlaceholderText("master@salon.ru")
        master_form_layout.addWidget(self.new_master_email, 1, 3)

        # Ряд 3: Опыт и график работы
        master_form_layout.addWidget(QLabel("Опыт (лет):"), 2, 0)
        self.new_master_experience = QLineEdit()
        self.new_master_experience.setPlaceholderText("5")
        master_form_layout.addWidget(self.new_master_experience, 2, 1)

        master_form_layout.addWidget(QLabel("График работы:"), 2, 2)
        self.new_master_schedule = QLineEdit()
        self.new_master_schedule.setPlaceholderText("Пн-Пт 9:00-18:00")
        master_form_layout.addWidget(self.new_master_schedule, 2, 3)

        # Ряд 4: Логин и пароль
        master_form_layout.addWidget(QLabel("Логин:"), 3, 0)
        self.new_master_username = QLineEdit()
        self.new_master_username.setPlaceholderText("Логин для входа")
        master_form_layout.addWidget(self.new_master_username, 3, 1)

        master_form_layout.addWidget(QLabel("Пароль:"), 3, 2)
        self.new_master_password = QLineEdit()
        self.new_master_password.setPlaceholderText("Пароль для входа")
        master_form_layout.addWidget(self.new_master_password, 3, 3)

        # Ряд 5: Кнопки
        master_buttons_layout = QHBoxLayout()
        add_master_btn = QPushButton("Добавить мастера")
        add_master_btn.clicked.connect(self.add_new_master)
        master_buttons_layout.addWidget(add_master_btn)

        clear_master_btn = QPushButton("Очистить форму")
        clear_master_btn.clicked.connect(self.clear_master_form)
        master_buttons_layout.addWidget(clear_master_btn)

        master_buttons_layout.addStretch()
        master_form_layout.addLayout(master_buttons_layout, 4, 0, 1, 4)

        master_form_group.setLayout(master_form_layout)
        layout.addWidget(master_form_group)

        # Таблица мастеров
        self.masters_table = QTableWidget()
        self.masters_table.setColumnCount(6)
        self.masters_table.setHorizontalHeaderLabels([
            "ID", "ФИО", "Специализация", "Телефон", "Опыт (лет)", "График работы"
        ])

        header = self.masters_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)  # ФИО
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)  # Специализация

        layout.addWidget(self.masters_table)

        self.tabs.addTab(tab, "Мастера")

    def load_initial_data(self):
        self.show_all_appointments()
        self.load_clients()
        self.load_masters()

    def register_new_client(self):
        """Регистрация нового клиента"""
        # Получаем данные из формы
        full_name = self.new_client_name.text().strip()
        phone = self.new_client_phone.text().strip()
        email = self.new_client_email.text().strip() or None
        birth_date = self.new_client_birth_date.date().toString("yyyy-MM-dd")
        username = self.new_client_username.text().strip()
        password = self.new_client_password.text()
        notes = self.new_client_notes.toPlainText().strip() or None

        # Проверяем обязательные поля
        if not full_name or not phone or not username or not password:
            QMessageBox.warning(self, "Ошибка", "Заполните все обязательные поля")
            return

        try:
            # Создаем пользователя
            with self.db.connection.cursor() as cursor:
                user_sql = """
                INSERT INTO users (username, password, full_name, role, phone, email, is_active)
                VALUES (%s, %s, %s, 'client', %s, %s, TRUE)
                """
                cursor.execute(user_sql, (username, password, full_name, phone, email))
                user_id = cursor.lastrowid

                # Создаем клиента
                client_sql = """
                INSERT INTO clients (user_id, full_name, phone, email, 
                                   birth_date, registration_date, created_by_admin, notes)
                VALUES (%s, %s, %s, %s, %s, CURDATE(), TRUE, %s)
                """
                cursor.execute(client_sql, (user_id, full_name, phone, email, birth_date, notes))

                self.db.connection.commit()

                QMessageBox.information(self, "Успех",
                    f"Клиент успешно зарегистрирован!\n\nЛогин: {username}\nПароль: {password}")

                # Обновляем данные
                self.load_clients()
                self.load_clients_for_combo()
                self.clear_client_form()

        except Error as e:
            print(f"Ошибка при регистрации клиента: {e}")
            QMessageBox.critical(self, "Ошибка", "Не удалось зарегистрировать клиента")

    def clear_client_form(self):
        """Очистка формы регистрации клиента"""
        self.new_client_name.clear()
        self.new_client_phone.clear()
        self.new_client_email.clear()
        self.new_client_birth_date.setDate(QDate(1990, 1, 1))
        self.new_client_username.clear()
        self.new_client_password.clear()
        self.new_client_notes.clear()

    def add_new_master(self):
        """Добавление нового мастера"""
        # Получаем данные из формы
        full_name = self.new_master_name.text().strip()
        specialization = self.new_master_specialization.currentText()
        phone = self.new_master_phone.text().strip()
        email = self.new_master_email.text().strip() or None
        experience = self.new_master_experience.text().strip()
        schedule = self.new_master_schedule.text().strip()
        username = self.new_master_username.text().strip()
        password = self.new_master_password.text()

        # Проверяем обязательные поля
        if not full_name or not specialization or not phone or not username or not password:
            QMessageBox.warning(self, "Ошибка", "Заполните все обязательные поля")
            return

        try:
            # Преобразуем опыт в число
            try:
                experience_years = int(experience) if experience else 0
            except ValueError:
                experience_years = 0

            # Создаем пользователя
            with self.db.connection.cursor() as cursor:
                user_sql = """
                INSERT INTO users (username, password, full_name, role, phone, email, is_active)
                VALUES (%s, %s, %s, 'admin', %s, %s, TRUE)
                """
                cursor.execute(user_sql, (username, password, full_name, phone, email))
                user_id = cursor.lastrowid

                # Создаем мастера
                master_sql = """
                INSERT INTO masters (full_name, specialization, phone, email, 
                                   experience_years, work_schedule, is_active)
                VALUES (%s, %s, %s, %s, %s, %s, TRUE)
                """
                cursor.execute(master_sql, (full_name, specialization, phone, email,
                                           experience_years, schedule))

                self.db.connection.commit()

                QMessageBox.information(self, "Успех",
                    f"Мастер успешно добавлен!\n\nЛогин: {username}\nПароль: {password}")

                # Обновляем данные
                self.load_masters()
                self.load_masters_for_combo()
                self.clear_master_form()

        except Error as e:
            print(f"Ошибка при добавлении мастера: {e}")
            QMessageBox.critical(self, "Ошибка", "Не удалось добавить мастера")

    def clear_master_form(self):
        """Очистка формы добавления мастера"""
        self.new_master_name.clear()
        self.new_master_specialization.setCurrentIndex(0)
        self.new_master_phone.clear()
        self.new_master_email.clear()
        self.new_master_experience.clear()
        self.new_master_schedule.clear()
        self.new_master_username.clear()
        self.new_master_password.clear()

    def load_clients_for_combo(self):
        try:
            clients = self.db.get_all_clients()
            self.client_combo.clear()
            for client in clients:
                self.client_combo.addItem(
                    f"{client['full_name']} (тел: {client.get('phone', '')})",
                    client['id']
                )
        except Error as e:
            print(f"Ошибка при загрузке клиентов для комбобокса: {e}")

    def load_masters_for_combo(self):
        try:
            masters = self.db.get_all_masters()
            self.master_combo.clear()
            for master in masters:
                self.master_combo.addItem(
                    f"{master['full_name']} ({master['specialization']})",
                    master['id']
                )
        except Error as e:
            print(f"Ошибка при загрузке мастеров для комбобокса: {e}")

    def load_services_for_filter(self):
        try:
            services = self.db.get_all_services()
            self.service_filter_combo.clear()
            self.service_filter_combo.addItem("Все услуги", 0)
            for service in services:
                self.service_filter_combo.addItem(
                    f"{service['service_name']} - {float(service['price']):.2f} руб.",
                    service['id']
                )
        except Error as e:
            print(f"Ошибка при загрузке услуг для фильтра: {e}")

    def update_services_combo(self):
        master_id = self.master_combo.currentData()
        if not master_id:
            return

        try:
            services = self.db.get_all_services()
            self.service_combo.clear()
            for service in services:
                self.service_combo.addItem(
                    f"{service['service_name']} - {float(service['price']):.2f} руб. ({service['duration_minutes']} мин)",
                    (service['id'], service['duration_minutes'], service['price'])
                )
        except Error as e:
            print(f"Ошибка при обновлении списка услуг: {e}")

    def update_duration_and_price(self):
        current_data = self.service_combo.currentData()
        if current_data:
            service_id, duration, price = current_data
            self.duration_input.setText(str(duration))
            self.price_input.setText(f"{float(price):.2f}")

    def check_time_availability(self):
        master_id = self.master_combo.currentData()
        appointment_date = self.appointment_date.date().toString("yyyy-MM-dd")
        appointment_time = self.appointment_time.time().toString("HH:mm")
        duration_text = self.duration_input.text()

        if not master_id or not duration_text:
            return

        duration = int(duration_text)
        is_available = self.db.check_time_availability(
            master_id, appointment_date, appointment_time, duration
        )

        if not is_available:
            QMessageBox.warning(self, "Внимание", "Выбранное время уже занято. Пожалуйста, выберите другое время.")

    def show_all_appointments(self):
        appointments = self.db.get_all_appointments()
        self.update_appointments_table(appointments)

    def filter_appointments_by_date(self):
        start_date = self.start_date_filter.date().toString("yyyy-MM-dd")
        end_date = self.end_date_filter.date().toString("yyyy-MM-dd")

        appointments = self.db.get_appointments_by_period(start_date, end_date)
        self.update_appointments_table(appointments)

    def filter_appointments_by_service(self):
        service_id = self.service_filter_combo.currentData()

        if service_id == 0:  # Все услуги
            self.show_all_appointments()
            return

        appointments = self.db.get_appointments_by_service(service_id)
        self.update_appointments_table(appointments)

    def update_appointments_table(self, appointments):
        self.appointments_table.setRowCount(len(appointments))

        for row, appointment in enumerate(appointments):
            self.appointments_table.setItem(row, 0, QTableWidgetItem(str(appointment.get('id', ''))))
            self.appointments_table.setItem(row, 1, QTableWidgetItem(appointment.get('client_name', '')))
            self.appointments_table.setItem(row, 2, QTableWidgetItem(appointment.get('client_phone', '')))
            self.appointments_table.setItem(row, 3, QTableWidgetItem(appointment.get('master_name', '')))
            self.appointments_table.setItem(row, 4, QTableWidgetItem(appointment.get('service_name', '')))
            self.appointments_table.setItem(row, 5, QTableWidgetItem(appointment.get('appointment_date', '')))
            self.appointments_table.setItem(row, 6, QTableWidgetItem(appointment.get('appointment_time', '')))
            self.appointments_table.setItem(row, 7, QTableWidgetItem(str(appointment.get('duration_minutes', ''))))
            self.appointments_table.setItem(row, 8,
                                            QTableWidgetItem(f"{float(appointment.get('total_price', 0)):.2f} руб."))

            status_item = QTableWidgetItem(appointment.get('status', ''))
            status_text = appointment.get('status', '')

            # Раскрашиваем статусы
            if status_text == 'completed':
                status_item.setBackground(QColor(200, 255, 200))  # Зеленый
            elif status_text == 'cancelled':
                status_item.setBackground(QColor(255, 200, 200))  # Красный
            elif status_text == 'no_show':
                status_item.setBackground(QColor(255, 150, 150))  # Темно-красный
            elif status_text == 'scheduled':
                status_item.setBackground(QColor(255, 255, 200))  # Желтый

            self.appointments_table.setItem(row, 9, status_item)

    def load_clients(self):
        clients = self.db.get_all_clients()
        self.clients_table.setRowCount(len(clients))

        for row, client in enumerate(clients):
            self.clients_table.setItem(row, 0, QTableWidgetItem(str(client['id'])))
            self.clients_table.setItem(row, 1, QTableWidgetItem(client['full_name']))
            self.clients_table.setItem(row, 2, QTableWidgetItem(client.get('phone', '')))
            self.clients_table.setItem(row, 3, QTableWidgetItem(client.get('email', '')))
            self.clients_table.setItem(row, 4, QTableWidgetItem(client.get('birth_date', '')))
            self.clients_table.setItem(row, 5, QTableWidgetItem(client.get('registration_date', '')))

    def load_masters(self):
        masters = self.db.get_all_masters()
        self.masters_table.setRowCount(len(masters))

        for row, master in enumerate(masters):
            self.masters_table.setItem(row, 0, QTableWidgetItem(str(master['id'])))
            self.masters_table.setItem(row, 1, QTableWidgetItem(master['full_name']))
            self.masters_table.setItem(row, 2, QTableWidgetItem(master['specialization']))
            self.masters_table.setItem(row, 3, QTableWidgetItem(master.get('phone', '')))
            self.masters_table.setItem(row, 4, QTableWidgetItem(str(master.get('experience_years', ''))))
            self.masters_table.setItem(row, 5, QTableWidgetItem(master.get('work_schedule', '')))

    def create_appointment_from_form(self):
        client_id = self.client_combo.currentData()
        master_id = self.master_combo.currentData()
        service_data = self.service_combo.currentData()

        if not client_id or not master_id or not service_data:
            QMessageBox.warning(self, "Ошибка", "Заполните все обязательные поля")
            return

        service_id, duration, price = service_data
        appointment_date = self.appointment_date.date().toString("yyyy-MM-dd")
        appointment_time = self.appointment_time.time().toString("HH:mm")
        status = self.status_combo.currentText()
        notes = self.notes_text.toPlainText()

        # Проверяем доступность времени
        is_available = self.db.check_time_availability(
            master_id, appointment_date, appointment_time, duration
        )

        if not is_available:
            QMessageBox.warning(self, "Ошибка", "Выбранное время уже занято")
            return

        appointment_data = (
            client_id, master_id, service_id,
            appointment_date, appointment_time,
            duration, price, status, notes
        )

        try:
            appointment_id = self.db.create_appointment(appointment_data)
            if appointment_id:
                QMessageBox.information(self, "Успех", f"Запись создана. ID: {appointment_id}")
                self.show_all_appointments()
                self.clear_appointment_form()
        except Error as e:
            print(f"Ошибка при создании записи: {e}")
            QMessageBox.critical(self, "Ошибка", "Не удалось создать запись")

    def update_appointment_from_form(self):
        if not self.current_editing_appointment_id:
            QMessageBox.warning(self, "Ошибка", "Сначала выберите запись из таблицы")
            return

        client_id = self.client_combo.currentData()
        master_id = self.master_combo.currentData()
        service_data = self.service_combo.currentData()

        if not client_id or not master_id or not service_data:
            QMessageBox.warning(self, "Ошибка", "Заполните все обязательные поля")
            return

        service_id, duration, price = service_data
        appointment_date = self.appointment_date.date().toString("yyyy-MM-dd")
        appointment_time = self.appointment_time.time().toString("HH:mm")
        status = self.status_combo.currentText()
        notes = self.notes_text.toPlainText()

        update_data = (
            master_id, service_id,
            appointment_date, appointment_time,
            duration, price, status, notes
        )

        try:
            success = self.db.update_appointment(self.current_editing_appointment_id, update_data)
            if success:
                QMessageBox.information(self, "Успех", "Запись обновлена")
                self.show_all_appointments()
                self.clear_appointment_form()
                self.current_editing_appointment_id = None
                self.new_appointment_btn.setEnabled(True)
                self.update_appointment_btn.setEnabled(False)
                self.delete_appointment_btn.setEnabled(False)
        except Error as e:
            print(f"Ошибка при обновлении записи: {e}")
            QMessageBox.critical(self, "Ошибка", "Не удалось обновить запись")

    def delete_appointment(self):
        if not self.current_editing_appointment_id:
            QMessageBox.warning(self, "Ошибка", "Сначала выберите запись из таблицы")
            return

        reply = QMessageBox.question(
            self, 'Подтверждение',
            'Вы уверены, что хотите удалить эту запись?',
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )

        if reply == QMessageBox.StandardButton.Yes:
            try:
                success = self.db.delete_appointment(self.current_editing_appointment_id)
                if success:
                    QMessageBox.information(self, "Успех", "Запись удалена")
                    self.show_all_appointments()
                    self.clear_appointment_form()
                    self.current_editing_appointment_id = None
                    self.new_appointment_btn.setEnabled(True)
                    self.update_appointment_btn.setEnabled(False)
                    self.delete_appointment_btn.setEnabled(False)
            except Error as e:
                print(f"Ошибка при удалении записи: {e}")
                QMessageBox.critical(self, "Ошибка", "Не удалось удалить запись")

    def on_appointment_table_click(self):
        selected = self.appointments_table.currentRow()
        if selected < 0:
            return

        appointment_id = int(self.appointments_table.item(selected, 0).text())
        self.current_editing_appointment_id = appointment_id

        # Получаем данные выбранной записи
        try:
            appointments = self.db.get_all_appointments()
            selected_appointment = None
            for app in appointments:
                if app['id'] == appointment_id:
                    selected_appointment = app
                    break

            if selected_appointment:
                # Заполняем форму данными записи
                # Находим клиента в комбобоксе
                for i in range(self.client_combo.count()):
                    if self.client_combo.itemData(i) == selected_appointment['client_id']:
                        self.client_combo.setCurrentIndex(i)
                        break

                # Находим мастера в комбобоксе
                for i in range(self.master_combo.count()):
                    if self.master_combo.itemData(i) == selected_appointment['master_id']:
                        self.master_combo.setCurrentIndex(i)
                        break

                # Обновляем список услуг и выбираем текущую
                self.update_services_combo()
                for i in range(self.service_combo.count()):
                    service_data = self.service_combo.itemData(i)
                    if service_data and service_data[0] == selected_appointment['service_id']:
                        self.service_combo.setCurrentIndex(i)
                        break

                # Устанавливаем дату и время
                if selected_appointment.get('appointment_date'):
                    self.appointment_date.setDate(
                        QDate.fromString(selected_appointment['appointment_date'], 'yyyy-MM-dd'))

                if selected_appointment.get('appointment_time'):
                    time_str = selected_appointment['appointment_time']
                    # Исправленная обработка времени (может содержать секунды)
                    if ':' in time_str:
                        time_parts = time_str.split(':')
                        hours = int(time_parts[0])  # Часы
                        minutes = int(time_parts[1]) if len(time_parts) > 1 else 0  # Минуты
                        self.appointment_time.setTime(QTime(hours, minutes))

                # Устанавливаем статус
                status_text = selected_appointment.get('status', 'scheduled')
                index = self.status_combo.findText(status_text)
                if index >= 0:
                    self.status_combo.setCurrentIndex(index)

                # Устанавливаем примечания
                self.notes_text.setPlainText(selected_appointment.get('notes', ''))

                # Активируем кнопки обновления и удаления
                self.new_appointment_btn.setEnabled(False)
                self.update_appointment_btn.setEnabled(True)
                self.delete_appointment_btn.setEnabled(True)

        except Error as e:
            print(f"Ошибка при загрузке данных записи: {e}")
            QMessageBox.critical(self, "Ошибка", "Не удалось загрузить данные записи")

    def clear_appointment_form(self):
        self.appointment_date.setDate(QDate.currentDate().addDays(1))
        self.appointment_time.setTime(QTime(9, 0))
        self.status_combo.setCurrentIndex(0)
        self.notes_text.clear()
        self.duration_input.clear()
        self.price_input.clear()