from datetime import timedelta
from PyQt6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                             QTabWidget, QTableWidget, QTableWidgetItem, QPushButton,
                             QLabel, QLineEdit, QDateEdit, QComboBox, QTextEdit,
                             QGroupBox, QMessageBox, QHeaderView, QTimeEdit, QSpinBox,
                             QGridLayout)
from PyQt6.QtCore import Qt, QDate, QTime
from PyQt6.QtGui import QFont, QColor
from pymysql import Error


class ClientPanel(QMainWindow):
    def __init__(self, db, user):
        super().__init__()
        self.db = db
        self.user = user
        self.client = None

        self.setWindowTitle(f"Клиентский портал - {user['full_name']}")
        self.setGeometry(100, 100, 1200, 700)

        self.load_client_data()
        self.setup_ui()

    def load_client_data(self):
        self.client = self.db.get_client_by_user_id(self.user['id'])
        if not self.client:
            QMessageBox.warning(self, "Внимание", "Профиль клиента не найден")

    def setup_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)

        self.tabs = QTabWidget()
        self.create_service_appointments_tab()
        self.create_my_cars_tab()
        self.create_my_appointments_tab()

        main_layout.addWidget(self.tabs)

    def create_service_appointments_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        # ФОРМА ЗАПИСИ НА СЕРВИС
        appointment_group = QGroupBox("Запись на сервис")
        appointment_layout = QGridLayout()

        # Ряд 0: Мой автомобиль
        appointment_layout.addWidget(QLabel("Мой автомобиль:"), 0, 0)
        self.client_car_combo = QComboBox()
        appointment_layout.addWidget(self.client_car_combo, 0, 1, 1, 3)

        # Ряд 1: Мастер
        appointment_layout.addWidget(QLabel("Мастер:"), 1, 0)
        self.client_master_combo = QComboBox()
        appointment_layout.addWidget(self.client_master_combo, 1, 1, 1, 3)

        # Ряд 2: Услуга
        appointment_layout.addWidget(QLabel("Услуга:"), 2, 0)
        self.client_service_combo = QComboBox()
        self.client_service_combo.currentIndexChanged.connect(self.on_service_changed)
        appointment_layout.addWidget(self.client_service_combo, 2, 1, 1, 3)

        # Ряд 3: Дата и время
        appointment_layout.addWidget(QLabel("Дата:"), 3, 0)
        self.client_appointment_date = QDateEdit()
        self.client_appointment_date.setDate(QDate.currentDate().addDays(1))
        self.client_appointment_date.setCalendarPopup(True)
        self.client_appointment_date.setMinimumDate(QDate.currentDate())
        appointment_layout.addWidget(self.client_appointment_date, 3, 1)

        appointment_layout.addWidget(QLabel("Время:"), 3, 2)
        self.client_appointment_time = QTimeEdit()
        self.client_appointment_time.setTime(QTime(9, 0))
        appointment_layout.addWidget(self.client_appointment_time, 3, 3)

        # Ряд 4: Стоимость
        appointment_layout.addWidget(QLabel("Стоимость:"), 4, 0)
        self.client_price_label = QLabel("0.00 руб.")
        self.client_price_label.setStyleSheet("font-weight: bold;")
        appointment_layout.addWidget(self.client_price_label, 4, 1)

        # Ряд 5: Описание проблемы
        appointment_layout.addWidget(QLabel("Описание проблемы:"), 5, 0, Qt.AlignmentFlag.AlignTop)
        self.client_problem_input = QTextEdit()
        self.client_problem_input.setMaximumHeight(100)
        appointment_layout.addWidget(self.client_problem_input, 5, 1, 1, 3)

        # Ряд 6: Кнопка
        appointment_btn_layout = QHBoxLayout()
        new_appointment_btn = QPushButton("Записаться на сервис")
        new_appointment_btn.clicked.connect(self.create_service_appointment)
        appointment_btn_layout.addStretch()
        appointment_btn_layout.addWidget(new_appointment_btn)
        appointment_btn_layout.addStretch()
        appointment_layout.addLayout(appointment_btn_layout, 6, 0, 1, 4)

        appointment_group.setLayout(appointment_layout)
        layout.addWidget(appointment_group)

        # Группа для добавления нового автомобиля
        add_car_group = QGroupBox("Добавить новый автомобиль")
        add_car_layout = QGridLayout()

        add_car_layout.addWidget(QLabel("Марка:"), 0, 0)
        self.new_car_brand = QLineEdit()
        self.new_car_brand.setPlaceholderText("Toyota")
        add_car_layout.addWidget(self.new_car_brand, 0, 1)

        add_car_layout.addWidget(QLabel("Модель:"), 0, 2)
        self.new_car_model = QLineEdit()
        self.new_car_model.setPlaceholderText("Camry")
        add_car_layout.addWidget(self.new_car_model, 0, 3)

        add_car_layout.addWidget(QLabel("Год:"), 1, 0)
        self.new_car_year = QSpinBox()
        self.new_car_year.setRange(1990, 2024)
        self.new_car_year.setValue(2020)
        add_car_layout.addWidget(self.new_car_year, 1, 1)

        add_car_layout.addWidget(QLabel("Госномер:"), 1, 2)
        self.new_car_plate = QLineEdit()
        self.new_car_plate.setPlaceholderText("А123АА178")
        add_car_layout.addWidget(self.new_car_plate, 1, 3)

        add_car_layout.addWidget(QLabel("VIN:"), 2, 0)
        self.new_car_vin = QLineEdit()
        self.new_car_vin.setPlaceholderText("JTDKBRFU903456789")
        add_car_layout.addWidget(self.new_car_vin, 2, 1)

        add_car_layout.addWidget(QLabel("Цвет:"), 2, 2)
        self.new_car_color = QLineEdit()
        self.new_car_color.setPlaceholderText("черный")
        add_car_layout.addWidget(self.new_car_color, 2, 3)

        add_car_btn_layout = QHBoxLayout()
        add_car_btn = QPushButton("Добавить автомобиль")
        add_car_btn.clicked.connect(self.add_new_car)
        add_car_btn_layout.addStretch()
        add_car_btn_layout.addWidget(add_car_btn)
        add_car_btn_layout.addStretch()
        add_car_layout.addLayout(add_car_btn_layout, 3, 0, 1, 4)

        add_car_group.setLayout(add_car_layout)
        layout.addWidget(add_car_group)

        self.tabs.addTab(tab, "Запись на сервис")

        # Загружаем данные
        self.load_client_cars()
        self.load_client_masters()
        self.load_client_services()

    def create_my_cars_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        # ТАБЛИЦА МОИХ АВТОМОБИЛЕЙ
        self.my_cars_table = QTableWidget()
        self.my_cars_table.setColumnCount(7)
        self.my_cars_table.setHorizontalHeaderLabels([
            "ID", "Марка", "Модель", "Год", "Госномер", "VIN", "Цвет"
        ])

        header = self.my_cars_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)

        layout.addWidget(self.my_cars_table)

        self.tabs.addTab(tab, "Мои автомобили")

        # Загружаем автомобили клиента
        if self.client:
            self.load_my_cars()

    def create_my_appointments_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        # ТАБЛИЦА МОИХ ЗАПИСЕЙ
        self.my_appointments_table = QTableWidget()
        self.my_appointments_table.setColumnCount(7)
        self.my_appointments_table.setHorizontalHeaderLabels([
            "ID", "Автомобиль", "Мастер", "Услуга", "Дата", "Время", "Статус"
        ])

        header = self.my_appointments_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)

        layout.addWidget(self.my_appointments_table)

        self.tabs.addTab(tab, "Мои записи")

        # Загружаем записи
        if self.client:
            self.load_client_service_appointments()

    # Методы загрузки данных
    def load_client_cars(self):
        if not self.client:
            return

        try:
            cars = self.db.get_client_cars(self.client['id'])
            self.client_car_combo.clear()
            for car in cars:
                self.client_car_combo.addItem(
                    f"{car['brand']} {car['model']} ({car['license_plate']})",
                    car['id']
                )
        except Error as e:
            print(f"Ошибка при загрузке автомобилей: {e}")

    def load_my_cars(self):
        if not self.client:
            return

        try:
            cars = self.db.get_client_cars(self.client['id'])
            self.my_cars_table.setRowCount(len(cars))

            for row, car in enumerate(cars):
                self.my_cars_table.setItem(row, 0, QTableWidgetItem(str(car['id'])))
                self.my_cars_table.setItem(row, 1, QTableWidgetItem(car['brand']))
                self.my_cars_table.setItem(row, 2, QTableWidgetItem(car['model']))
                self.my_cars_table.setItem(row, 3, QTableWidgetItem(str(car['year'])))
                self.my_cars_table.setItem(row, 4, QTableWidgetItem(car['license_plate']))
                self.my_cars_table.setItem(row, 5, QTableWidgetItem(car.get('vin', '')))
                self.my_cars_table.setItem(row, 6, QTableWidgetItem(car.get('color', '')))
        except Error as e:
            print(f"Ошибка при загрузке моих автомобилей: {e}")

    def load_client_masters(self):
        try:
            masters = self.db.get_all_masters()
            self.client_master_combo.clear()
            for master in masters:
                self.client_master_combo.addItem(
                    f"{master['full_name']} ({master['specialization']})",
                    master['id']
                )
        except Error as e:
            print(f"Ошибка при загрузке мастеров: {e}")

    def load_client_services(self):
        try:
            services = self.db.get_all_services()
            self.client_service_combo.clear()
            for service in services:
                self.client_service_combo.addItem(
                    f"{service['service_name']} - {service['price']:.2f} руб.",
                    (service['id'], service['price'])
                )
        except Error as e:
            print(f"Ошибка при загрузке услуг: {e}")

    def on_service_changed(self):
        """Обновляет цену при выборе услуги"""
        service_data = self.client_service_combo.currentData()
        if not service_data:
            self.client_price_label.setText("0.00 руб.")
            return

        if isinstance(service_data, tuple) and len(service_data) >= 2:
            service_id, price = service_data
            self.client_price_label.setText(f"{float(price):.2f} руб.")

    def add_new_car(self):
        if not self.client:
            QMessageBox.warning(self, "Ошибка", "Профиль клиента не найден")
            return

        brand = self.new_car_brand.text().strip()
        model = self.new_car_model.text().strip()
        year = self.new_car_year.value()
        license_plate = self.new_car_plate.text().strip()
        vin = self.new_car_vin.text().strip() or None
        color = self.new_car_color.text().strip() or None

        if not brand or not model or not license_plate:
            QMessageBox.warning(self, "Ошибка", "Заполните обязательные поля (марка, модель, госномер)")
            return

        car_data = (
            self.client['id'], brand, model, year, license_plate, vin,
            0.0, 'бензин', 'автомат', 0, color
        )

        try:
            car_id = self.db.add_client_car(car_data)
            if car_id:
                QMessageBox.information(self, "Успех", "Автомобиль добавлен")
                self.load_client_cars()
                self.load_my_cars()
                self.clear_new_car_form()
        except Error as e:
            print(f"Ошибка при добавлении автомобиля: {e}")
            QMessageBox.critical(self, "Ошибка", "Не удалось добавить автомобиль")

    def clear_new_car_form(self):
        self.new_car_brand.clear()
        self.new_car_model.clear()
        self.new_car_year.setValue(2020)
        self.new_car_plate.clear()
        self.new_car_vin.clear()
        self.new_car_color.clear()

    def create_service_appointment(self):
        if not self.client:
            QMessageBox.warning(self, "Ошибка", "Профиль клиента не найден")
            return

        car_id = self.client_car_combo.currentData()
        master_id = self.client_master_combo.currentData()
        service_data = self.client_service_combo.currentData()

        if not service_data:
            QMessageBox.warning(self, "Ошибка", "Выберите услугу")
            return

        if isinstance(service_data, tuple) and len(service_data) >= 2:
            service_id, service_price = service_data
        else:
            service_id = service_data
            service_price = 0.0

        appointment_date = self.client_appointment_date.date().toString("yyyy-MM-dd")
        appointment_time = self.client_appointment_time.time().toString("HH:mm")
        problem = self.client_problem_input.toPlainText().strip()

        if not car_id or not master_id or not service_id or not problem:
            QMessageBox.warning(self, "Ошибка", "Заполните все обязательные поля")
            return

        # Стандартная длительность - 1 час для услуг
        duration = 1

        is_available = self.db.check_time_availability(
            master_id, appointment_date, appointment_time, duration
        )

        if not is_available:
            QMessageBox.warning(self, "Ошибка", "Выбранное время уже занято")
            return

        appointment_data = (
            self.client['id'], master_id, car_id, service_id, appointment_date, appointment_time,
            duration, problem, 'запланировано', service_price, ""
        )

        try:
            appointment_id = self.db.create_service_appointment(appointment_data)
            if appointment_id:
                QMessageBox.information(self, "Успех",
                                        f"Вы успешно записаны на сервис!\nНомер записи: {appointment_id}\nСтоимость: {service_price:.2f} руб.")
                self.load_client_service_appointments()
                self.clear_service_form()
        except Error as e:
            print(f"Ошибка при создании записи: {e}")
            QMessageBox.critical(self, "Ошибка", "Не удалось создать запись")

    def clear_service_form(self):
        self.client_appointment_date.setDate(QDate.currentDate().addDays(1))
        self.client_appointment_time.setTime(QTime(9, 0))
        self.client_problem_input.clear()
        self.client_price_label.setText("0.00 руб.")

    def load_client_service_appointments(self):
        if not self.client:
            return

        try:
            appointments = self.db.get_client_service_appointments(self.client['id'])
            self.my_appointments_table.setRowCount(len(appointments))

            for row, appointment in enumerate(appointments):
                self.my_appointments_table.setItem(row, 0, QTableWidgetItem(str(appointment.get('id', ''))))

                car_info = f"{appointment.get('car_brand', '')} {appointment.get('car_model', '')} ({appointment.get('license_plate', '')})"
                self.my_appointments_table.setItem(row, 1, QTableWidgetItem(car_info))

                self.my_appointments_table.setItem(row, 2, QTableWidgetItem(appointment.get('master_name', '')))
                self.my_appointments_table.setItem(row, 3, QTableWidgetItem(appointment.get('service_name', '')))

                # Безопасное получение даты
                appointment_date = appointment.get('appointment_date', '')
                if appointment_date:
                    if not isinstance(appointment_date, str):
                        if hasattr(appointment_date, 'strftime'):
                            appointment_date = appointment_date.strftime('%Y-%m-%d')
                        else:
                            appointment_date = str(appointment_date)
                self.my_appointments_table.setItem(row, 4, QTableWidgetItem(appointment_date))

                # Безопасное получение времени
                appointment_time = appointment.get('appointment_time', '')
                if appointment_time:
                    if not isinstance(appointment_time, str):
                        if hasattr(appointment_time, 'strftime'):
                            appointment_time = appointment_time.strftime('%H:%M')
                        elif isinstance(appointment_time, timedelta):
                            total_seconds = int(appointment_time.total_seconds())
                            hours = total_seconds // 3600
                            minutes = (total_seconds % 3600) // 60
                            appointment_time = f"{hours:02d}:{minutes:02d}"
                        else:
                            appointment_time = str(appointment_time)
                self.my_appointments_table.setItem(row, 5, QTableWidgetItem(appointment_time))

                status_item = QTableWidgetItem(appointment.get('status', ''))
                status_text = appointment.get('status', '')

                if status_text == 'завершено':
                    status_item.setBackground(QColor(200, 255, 200))
                elif status_text == 'отменено':
                    status_item.setBackground(QColor(255, 200, 200))
                elif status_text == 'в работе':
                    status_item.setBackground(QColor(255, 255, 200))
                elif status_text == 'запланировано':
                    status_item.setBackground(QColor(200, 230, 255))

                self.my_appointments_table.setItem(row, 6, status_item)
        except Error as e:
            print(f"Ошибка при загрузке записей клиента: {e}")