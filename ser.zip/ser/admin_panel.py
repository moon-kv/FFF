from datetime import timedelta
from PyQt6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                             QTabWidget, QTableWidget, QTableWidgetItem, QPushButton,
                             QLabel, QLineEdit, QDateEdit, QComboBox, QTextEdit,
                             QGroupBox, QMessageBox, QHeaderView, QFormLayout,
                             QTimeEdit, QGridLayout, QSpinBox)
from PyQt6.QtCore import Qt, QDate, QTime
from PyQt6.QtGui import QFont, QColor
from pymysql import Error


class AdminPanel(QMainWindow):
    def __init__(self, db, user):
        super().__init__()
        self.db = db
        self.user = user
        self.current_editing_appointment_id = None

        self.setWindowTitle(f"Панель администратора - {user['full_name']}")
        self.setGeometry(100, 100, 1400, 800)

        self.setup_ui()
        self.load_initial_data()

    def setup_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)

        self.tabs = QTabWidget()
        self.create_service_appointments_tab()
        self.create_clients_tab()
        self.create_masters_tab()

        main_layout.addWidget(self.tabs)

    def create_service_appointments_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        # ФОРМА ЗАПИСИ НА СЕРВИС
        appointment_form_group = QGroupBox("Запись клиента на сервис")
        appointment_form_layout = QGridLayout()
        appointment_form_layout.setSpacing(10)

        # Ряд 0: Клиент
        appointment_form_layout.addWidget(QLabel("Клиент:"), 0, 0)
        self.client_combo = QComboBox()
        self.client_combo.currentIndexChanged.connect(self.on_client_changed)
        appointment_form_layout.addWidget(self.client_combo, 0, 1, 1, 3)

        # Ряд 1: Автомобиль клиента
        appointment_form_layout.addWidget(QLabel("Автомобиль:"), 1, 0)
        self.car_combo = QComboBox()
        appointment_form_layout.addWidget(self.car_combo, 1, 1, 1, 3)

        # Ряд 2: Мастер и Услуга
        appointment_form_layout.addWidget(QLabel("Мастер:"), 2, 0)
        self.master_combo = QComboBox()
        appointment_form_layout.addWidget(self.master_combo, 2, 1)

        appointment_form_layout.addWidget(QLabel("Услуга:"), 2, 2)
        self.service_combo = QComboBox()
        self.service_combo.currentIndexChanged.connect(self.on_service_changed)
        appointment_form_layout.addWidget(self.service_combo, 2, 3)

        # Ряд 3: Дата и время
        appointment_form_layout.addWidget(QLabel("Дата:"), 3, 0)
        self.appointment_date = QDateEdit()
        self.appointment_date.setDate(QDate.currentDate().addDays(1))
        self.appointment_date.setCalendarPopup(True)
        appointment_form_layout.addWidget(self.appointment_date, 3, 1)

        appointment_form_layout.addWidget(QLabel("Время:"), 3, 2)
        self.appointment_time = QTimeEdit()
        self.appointment_time.setTime(QTime(9, 0))
        appointment_form_layout.addWidget(self.appointment_time, 3, 3)

        # Ряд 4: Длительность и стоимость
        appointment_form_layout.addWidget(QLabel("Длительность (часы):"), 4, 0)
        self.duration_input = QSpinBox()
        self.duration_input.setRange(1, 8)
        self.duration_input.setValue(1)
        appointment_form_layout.addWidget(self.duration_input, 4, 1)

        appointment_form_layout.addWidget(QLabel("Стоимость:"), 4, 2)
        self.price_input = QLineEdit()
        self.price_input.setPlaceholderText("0.00")
        appointment_form_layout.addWidget(self.price_input, 4, 3)

        # Ряд 5: Описание проблемы
        appointment_form_layout.addWidget(QLabel("Описание проблемы:"), 5, 0, Qt.AlignmentFlag.AlignTop)
        self.problem_input = QTextEdit()
        self.problem_input.setMaximumHeight(80)
        appointment_form_layout.addWidget(self.problem_input, 5, 1, 1, 3)

        # Ряд 6: Статус и примечания
        appointment_form_layout.addWidget(QLabel("Статус:"), 6, 0)
        self.status_combo = QComboBox()
        self.status_combo.addItems(['запланировано', 'в работе', 'завершено', 'отменено'])
        appointment_form_layout.addWidget(self.status_combo, 6, 1)

        appointment_form_layout.addWidget(QLabel("Примечания:"), 6, 2)
        self.notes_text = QTextEdit()
        self.notes_text.setMaximumHeight(60)
        appointment_form_layout.addWidget(self.notes_text, 6, 3)

        # Ряд 7: Кнопки
        buttons_row = QHBoxLayout()
        self.new_appointment_btn = QPushButton("Создать запись")
        self.new_appointment_btn.clicked.connect(self.create_appointment_from_form)
        buttons_row.addWidget(self.new_appointment_btn)

        self.update_appointment_btn = QPushButton("Обновить запись")
        self.update_appointment_btn.clicked.connect(self.update_appointment_from_form)
        self.update_appointment_btn.setEnabled(False)
        buttons_row.addWidget(self.update_appointment_btn)

        self.delete_appointment_btn = QPushButton("Удалить запись")
        self.delete_appointment_btn.clicked.connect(self.delete_appointment)
        self.delete_appointment_btn.setEnabled(False)
        buttons_row.addWidget(self.delete_appointment_btn)

        buttons_row.addStretch()
        appointment_form_layout.addLayout(buttons_row, 7, 0, 1, 4)

        appointment_form_group.setLayout(appointment_form_layout)
        layout.addWidget(appointment_form_group)

        # Группа фильтров
        filter_group = QGroupBox("Фильтр записей")
        filter_layout = QVBoxLayout()

        # Фильтр по дате
        date_filter_layout = QHBoxLayout()
        date_filter_layout.addWidget(QLabel("Период с:"))
        self.start_date_filter = QDateEdit()
        self.start_date_filter.setDate(QDate.currentDate().addDays(-7))
        self.start_date_filter.setCalendarPopup(True)
        date_filter_layout.addWidget(self.start_date_filter)

        date_filter_layout.addWidget(QLabel("по:"))
        self.end_date_filter = QDateEdit()
        self.end_date_filter.setDate(QDate.currentDate().addDays(30))
        self.end_date_filter.setCalendarPopup(True)
        date_filter_layout.addWidget(self.end_date_filter)

        filter_date_button = QPushButton("Фильтровать по дате")
        filter_date_button.clicked.connect(self.filter_appointments_by_date)
        date_filter_layout.addWidget(filter_date_button)

        date_filter_layout.addStretch()
        filter_layout.addLayout(date_filter_layout)

        # Фильтр по мастеру
        master_filter_layout = QHBoxLayout()
        master_filter_layout.addWidget(QLabel("Мастер:"))
        self.master_filter_combo = QComboBox()
        self.master_filter_combo.addItem("Все мастера", 0)
        master_filter_layout.addWidget(self.master_filter_combo)

        filter_master_button = QPushButton("Фильтровать по мастеру")
        filter_master_button.clicked.connect(self.filter_appointments_by_master)
        master_filter_layout.addWidget(filter_master_button)

        # Фильтр по услуге
        master_filter_layout.addWidget(QLabel("Услуга:"))
        self.service_filter_combo = QComboBox()
        self.service_filter_combo.addItem("Все услуги", 0)
        master_filter_layout.addWidget(self.service_filter_combo)

        filter_service_button = QPushButton("Фильтровать по услуге")
        filter_service_button.clicked.connect(self.filter_appointments_by_service)
        master_filter_layout.addWidget(filter_service_button)

        show_all_button = QPushButton("Показать все")
        show_all_button.clicked.connect(self.show_all_appointments)
        master_filter_layout.addWidget(show_all_button)

        master_filter_layout.addStretch()
        filter_layout.addLayout(master_filter_layout)

        filter_group.setLayout(filter_layout)
        layout.addWidget(filter_group)

        # ТАБЛИЦА ЗАПИСЕЙ
        self.appointments_table = QTableWidget()
        self.appointments_table.setColumnCount(9)
        self.appointments_table.setHorizontalHeaderLabels([
            "ID", "Клиент", "Автомобиль", "Мастер", "Услуга", "Дата", "Время", "Стоимость", "Статус"
        ])

        header = self.appointments_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)

        self.appointments_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.appointments_table.clicked.connect(self.on_appointment_table_click)
        layout.addWidget(self.appointments_table)

        self.tabs.addTab(tab, "Записи на сервис")

        # Загружаем данные для формы
        self.load_clients_for_combo()
        self.load_masters_for_combo()
        self.load_services_for_combo()
        self.load_filters_data()

    def load_filters_data(self):
        """Загрузка данных для фильтров"""
        try:
            # Загрузка мастеров для фильтра
            masters = self.db.get_all_masters()
            self.master_filter_combo.clear()
            self.master_filter_combo.addItem("Все мастера", 0)
            for master in masters:
                self.master_filter_combo.addItem(
                    f"{master['full_name']} ({master['specialization']})",
                    master['id']
                )

            # Загрузка услуг для фильтра
            services = self.db.get_all_services()
            self.service_filter_combo.clear()
            self.service_filter_combo.addItem("Все услуги", 0)
            for service in services:
                self.service_filter_combo.addItem(
                    f"{service['service_name']}",
                    service['id']
                )
        except Error as e:
            print(f"Ошибка при загрузке данных для фильтров: {e}")

    def filter_appointments_by_date(self):
        """Фильтрация записей по дате"""
        start_date = self.start_date_filter.date().toString("yyyy-MM-dd")
        end_date = self.end_date_filter.date().toString("yyyy-MM-dd")

        try:
            appointments = self.db.get_appointments_by_period(start_date, end_date)
            self.update_appointments_table(appointments)

            QMessageBox.information(self, "Фильтр",
                                    f"Найдено {len(appointments)} записей в выбранном периоде")

        except Exception as e:
            print(f"Ошибка при фильтрации по дате: {e}")
            QMessageBox.critical(self, "Ошибка", "Не удалось применить фильтр по дате")

    def filter_appointments_by_master(self):
        """Фильтрация записей по мастеру"""
        master_id = self.master_filter_combo.currentData()

        if master_id == 0:  # Все мастера
            self.show_all_appointments()
            return

        try:
            appointments = self.db.get_appointments_by_master(master_id)
            self.update_appointments_table(appointments)

            master_name = self.master_filter_combo.currentText()
            QMessageBox.information(self, "Фильтр",
                                    f"Найдено {len(appointments)} записей у мастера: {master_name}")

        except Exception as e:
            print(f"Ошибка при фильтрации по мастеру: {e}")
            QMessageBox.critical(self, "Ошибка", "Не удалось применить фильтр по мастеру")

    def filter_appointments_by_service(self):
        """Фильтрация записей по услуге"""
        service_id = self.service_filter_combo.currentData()

        if service_id == 0:  # Все услуги
            self.show_all_appointments()
            return

        try:
            appointments = self.db.get_appointments_by_service(service_id)
            self.update_appointments_table(appointments)

            service_name = self.service_filter_combo.currentText()
            QMessageBox.information(self, "Фильтр",
                                    f"Найдено {len(appointments)} записей по услуге: {service_name}")

        except Exception as e:
            print(f"Ошибка при фильтрации по услуге: {e}")
            QMessageBox.critical(self, "Ошибка", "Не удалось применить фильтр по услуге")

    def show_all_appointments(self):
        """Показать все записи"""
        appointments = self.db.get_all_service_appointments()
        self.update_appointments_table(appointments)
        QMessageBox.information(self, "Фильтр", "Показаны все записи")

    def create_clients_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        # ФОРМА РЕГИСТРАЦИИ КЛИЕНТА
        client_form_group = QGroupBox("Регистрация нового клиента")
        client_form_layout = QGridLayout()

        # Личные данные
        client_form_layout.addWidget(QLabel("ФИО:"), 0, 0)
        self.new_client_name = QLineEdit()
        client_form_layout.addWidget(self.new_client_name, 0, 1)

        client_form_layout.addWidget(QLabel("Телефон:"), 0, 2)
        self.new_client_phone = QLineEdit()
        client_form_layout.addWidget(self.new_client_phone, 0, 3)

        client_form_layout.addWidget(QLabel("Email:"), 1, 0)
        self.new_client_email = QLineEdit()
        client_form_layout.addWidget(self.new_client_email, 1, 1)

        client_form_layout.addWidget(QLabel("Дата рождения:"), 1, 2)
        self.new_client_birth_date = QDateEdit()
        self.new_client_birth_date.setCalendarPopup(True)
        self.new_client_birth_date.setDate(QDate(1990, 1, 1))
        client_form_layout.addWidget(self.new_client_birth_date, 1, 3)

        # Данные для входа
        client_form_layout.addWidget(QLabel("Логин:"), 2, 0)
        self.new_client_username = QLineEdit()
        client_form_layout.addWidget(self.new_client_username, 2, 1)

        client_form_layout.addWidget(QLabel("Пароль:"), 2, 2)
        self.new_client_password = QLineEdit()
        client_form_layout.addWidget(self.new_client_password, 2, 3)

        # Водительские права
        client_form_layout.addWidget(QLabel("В/у:"), 3, 0)
        self.new_client_license = QLineEdit()
        client_form_layout.addWidget(self.new_client_license, 3, 1)

        client_form_layout.addWidget(QLabel("Срок действия:"), 3, 2)
        self.new_client_license_expiry = QDateEdit()
        self.new_client_license_expiry.setCalendarPopup(True)
        self.new_client_license_expiry.setDate(QDate(2030, 1, 1))
        client_form_layout.addWidget(self.new_client_license_expiry, 3, 3)

        client_form_layout.addWidget(QLabel("Предпочтения:"), 4, 0, Qt.AlignmentFlag.AlignTop)
        self.new_client_preferences = QTextEdit()
        self.new_client_preferences.setMaximumHeight(60)
        client_form_layout.addWidget(self.new_client_preferences, 4, 1, 1, 3)

        # Кнопки
        client_buttons_layout = QHBoxLayout()
        register_client_btn = QPushButton("Зарегистрировать клиента")
        register_client_btn.clicked.connect(self.register_new_client)
        client_buttons_layout.addWidget(register_client_btn)

        clear_client_btn = QPushButton("Очистить форму")
        clear_client_btn.clicked.connect(self.clear_client_form)
        client_buttons_layout.addWidget(clear_client_btn)

        client_buttons_layout.addStretch()
        client_form_layout.addLayout(client_buttons_layout, 5, 0, 1, 4)

        client_form_group.setLayout(client_form_layout)
        layout.addWidget(client_form_group)

        # ТАБЛИЦА КЛИЕНТОВ
        self.clients_table = QTableWidget()
        self.clients_table.setColumnCount(6)
        self.clients_table.setHorizontalHeaderLabels([
            "ID", "ФИО", "Телефон", "Email", "В/у", "Дата рождения"
        ])

        header = self.clients_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)

        layout.addWidget(self.clients_table)

        self.tabs.addTab(tab, "Клиенты")

    def create_masters_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        # ФОРМА ДОБАВЛЕНИЯ МАСТЕРА
        master_form_group = QGroupBox("Добавление нового мастера")
        master_form_layout = QGridLayout()

        # Основная информация
        master_form_layout.addWidget(QLabel("ФИО:"), 0, 0)
        self.new_master_name = QLineEdit()
        master_form_layout.addWidget(self.new_master_name, 0, 1)

        master_form_layout.addWidget(QLabel("Специализация:"), 0, 2)
        self.new_master_specialization = QLineEdit()
        master_form_layout.addWidget(self.new_master_specialization, 0, 3)

        master_form_layout.addWidget(QLabel("Квалификация:"), 1, 0)
        self.new_master_qualification = QLineEdit()
        master_form_layout.addWidget(self.new_master_qualification, 1, 1)

        master_form_layout.addWidget(QLabel("Опыт (лет):"), 1, 2)
        self.new_master_experience = QSpinBox()
        self.new_master_experience.setRange(0, 50)
        master_form_layout.addWidget(self.new_master_experience, 1, 3)

        # Контакты
        master_form_layout.addWidget(QLabel("Телефон:"), 2, 0)
        self.new_master_phone = QLineEdit()
        master_form_layout.addWidget(self.new_master_phone, 2, 1)

        master_form_layout.addWidget(QLabel("Email:"), 2, 2)
        self.new_master_email = QLineEdit()
        master_form_layout.addWidget(self.new_master_email, 2, 3)

        master_form_layout.addWidget(QLabel("Ставка (час):"), 3, 0)
        self.new_master_rate = QLineEdit()
        self.new_master_rate.setPlaceholderText("1500.00")
        master_form_layout.addWidget(self.new_master_rate, 3, 1)

        master_form_layout.addWidget(QLabel("График:"), 3, 2)
        self.new_master_schedule = QLineEdit()
        self.new_master_schedule.setPlaceholderText("Пн-Пт 9:00-18:00")
        master_form_layout.addWidget(self.new_master_schedule, 3, 3)

        # Кнопки
        master_buttons_layout = QHBoxLayout()
        add_master_btn = QPushButton("Добавить мастера")
        add_master_btn.clicked.connect(self.add_new_master)
        master_buttons_layout.addWidget(add_master_btn)

        clear_master_btn = QPushButton("Очистить форму")
        clear_master_btn.clicked.connect(self.clear_master_form)
        master_buttons_layout.addWidget(clear_master_btn)

        master_buttons_layout.addStretch()
        master_form_layout.addLayout(master_buttons_layout, 4, 0, 1, 4)

        master_form_group.setLayout(master_form_layout)
        layout.addWidget(master_form_group)

        # ТАБЛИЦА МАСТЕРОВ
        self.masters_table = QTableWidget()
        self.masters_table.setColumnCount(6)
        self.masters_table.setHorizontalHeaderLabels([
            "ID", "ФИО", "Специализация", "Квалификация", "Телефон", "Ставка"
        ])

        header = self.masters_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)

        layout.addWidget(self.masters_table)

        self.tabs.addTab(tab, "Мастера")

    def load_initial_data(self):
        self.load_service_appointments()
        self.load_clients()
        self.load_masters()
        self.load_filters_data()  # Добавляем загрузку фильтров

    # Методы для загрузки данных в комбобоксы
    def load_clients_for_combo(self):
        try:
            clients = self.db.get_all_clients()
            self.client_combo.clear()
            for client in clients:
                self.client_combo.addItem(
                    f"{client['full_name']} ({client.get('phone', '')})",
                    client['id']
                )
        except Error as e:
            print(f"Ошибка при загрузке клиентов: {e}")

    def load_masters_for_combo(self):
        try:
            masters = self.db.get_all_masters()
            self.master_combo.clear()
            for master in masters:
                self.master_combo.addItem(
                    f"{master['full_name']} ({master['specialization']})",
                    master['id']
                )
        except Error as e:
            print(f"Ошибка при загрузке мастеров: {e}")

    def load_services_for_combo(self):
        try:
            services = self.db.get_all_services()
            self.service_combo.clear()
            for service in services:
                self.service_combo.addItem(
                    f"{service['service_name']} - {service['price']:.2f} руб.",
                    (service['id'], service['price'])
                )
        except Error as e:
            print(f"Ошибка при загрузке услуг: {e}")

    def load_cars_for_client(self, client_id):
        try:
            cars = self.db.get_client_cars(client_id)
            self.car_combo.clear()
            for car in cars:
                self.car_combo.addItem(
                    f"{car['brand']} {car['model']} ({car['license_plate']})",
                    car['id']
                )
        except Error as e:
            print(f"Ошибка при загрузке автомобилей клиента: {e}")

    def on_client_changed(self):
        """Загружаем автомобили клиента при его выборе"""
        client_id = self.client_combo.currentData()
        if client_id:
            self.load_cars_for_client(client_id)

    # Методы для работы с записями на сервис
    def on_service_changed(self):
        """Обновляет цену при выборе услуги"""
        service_data = self.service_combo.currentData()
        if not service_data:
            return

        if isinstance(service_data, tuple) and len(service_data) >= 2:
            service_id, price = service_data
            self.price_input.setText(f"{float(price):.2f}")

    # Методы для работы с записями на сервис
    def load_service_appointments(self):
        try:
            appointments = self.db.get_all_service_appointments()
            self.update_appointments_table(appointments)
        except Exception as e:
            print(f"Ошибка при загрузке записей: {e}")

    def update_appointments_table(self, appointments):
        self.appointments_table.setRowCount(len(appointments))

        for row, appointment in enumerate(appointments):
            self.appointments_table.setItem(row, 0, QTableWidgetItem(str(appointment.get('id', ''))))
            self.appointments_table.setItem(row, 1, QTableWidgetItem(appointment.get('client_name', '')))

            car_info = f"{appointment.get('car_brand', '')} {appointment.get('car_model', '')} ({appointment.get('license_plate', '')})"
            self.appointments_table.setItem(row, 2, QTableWidgetItem(car_info))

            self.appointments_table.setItem(row, 3, QTableWidgetItem(appointment.get('master_name', '')))
            self.appointments_table.setItem(row, 4, QTableWidgetItem(appointment.get('service_name', '')))

            # Безопасное получение даты
            appointment_date = appointment.get('appointment_date', '')
            if appointment_date:
                if not isinstance(appointment_date, str):
                    if hasattr(appointment_date, 'strftime'):
                        appointment_date = appointment_date.strftime('%Y-%m-%d')
                    else:
                        appointment_date = str(appointment_date)
            self.appointments_table.setItem(row, 5, QTableWidgetItem(appointment_date))

            # Безопасное получение времени
            appointment_time = appointment.get('appointment_time', '')
            if appointment_time:
                if not isinstance(appointment_time, str):
                    if hasattr(appointment_time, 'strftime'):
                        appointment_time = appointment_time.strftime('%H:%M')
                    elif isinstance(appointment_time, timedelta):
                        total_seconds = int(appointment_time.total_seconds())
                        hours = total_seconds // 3600
                        minutes = (total_seconds % 3600) // 60
                        appointment_time = f"{hours:02d}:{minutes:02d}"
                    else:
                        appointment_time = str(appointment_time)
            self.appointments_table.setItem(row, 6, QTableWidgetItem(appointment_time))

            price = appointment.get('total_price', 0)
            self.appointments_table.setItem(row, 7, QTableWidgetItem(f"{price:.2f} руб."))

            status_item = QTableWidgetItem(appointment.get('status', ''))
            status_text = appointment.get('status', '')

            if status_text == 'завершено':
                status_item.setBackground(QColor(200, 255, 200))
            elif status_text == 'отменено':
                status_item.setBackground(QColor(255, 200, 200))
            elif status_text == 'в работе':
                status_item.setBackground(QColor(255, 255, 200))
            elif status_text == 'запланировано':
                status_item.setBackground(QColor(200, 230, 255))

            self.appointments_table.setItem(row, 8, status_item)

    def create_appointment_from_form(self):
        client_id = self.client_combo.currentData()
        car_id = self.car_combo.currentData()
        master_id = self.master_combo.currentData()
        service_data = self.service_combo.currentData()

        if not service_data:
            QMessageBox.warning(self, "Ошибка", "Выберите услугу")
            return

        if isinstance(service_data, tuple) and len(service_data) >= 2:
            service_id, service_price = service_data
        else:
            service_id = service_data
            service_price = 0.0

        appointment_date = self.appointment_date.date().toString("yyyy-MM-dd")
        appointment_time = self.appointment_time.time().toString("HH:mm")
        duration = self.duration_input.value()
        problem = self.problem_input.toPlainText().strip()
        status = self.status_combo.currentText()

        price_text = self.price_input.text().strip()
        try:
            price = float(price_text) if price_text else service_price
        except ValueError:
            price = service_price

        notes = self.notes_text.toPlainText().strip()

        if not client_id or not car_id or not master_id or not service_id or not problem:
            QMessageBox.warning(self, "Ошибка", "Заполните все обязательные поля")
            return

        is_available = self.db.check_time_availability(
            master_id, appointment_date, appointment_time, duration
        )

        if not is_available:
            QMessageBox.warning(self, "Ошибка", "Выбранное время уже занято")
            return

        appointment_data = (
            client_id, master_id, car_id, service_id, appointment_date, appointment_time,
            duration, problem, status, price, notes
        )

        try:
            appointment_id = self.db.create_service_appointment(appointment_data)
            if appointment_id:
                QMessageBox.information(self, "Успех", f"Запись создана. ID: {appointment_id}")
                self.load_service_appointments()
                self.clear_appointment_form()
        except Error as e:
            print(f"Ошибка при создании записи: {e}")
            QMessageBox.critical(self, "Ошибка", "Не удалось создать запись")

    def update_appointment_from_form(self):
        if not self.current_editing_appointment_id:
            QMessageBox.warning(self, "Ошибка", "Сначала выберите запись из таблицы")
            return

        client_id = self.client_combo.currentData()
        car_id = self.car_combo.currentData()
        master_id = self.master_combo.currentData()
        service_data = self.service_combo.currentData()

        if isinstance(service_data, tuple) and len(service_data) >= 2:
            service_id, service_price = service_data
        else:
            service_id = service_data
            service_price = 0.0

        appointment_date = self.appointment_date.date().toString("yyyy-MM-dd")
        appointment_time = self.appointment_time.time().toString("HH:mm")
        duration = self.duration_input.value()
        problem = self.problem_input.toPlainText().strip()
        status = self.status_combo.currentText()

        price_text = self.price_input.text().strip()
        try:
            price = float(price_text) if price_text else service_price
        except ValueError:
            price = service_price

        notes = self.notes_text.toPlainText().strip()

        if not client_id or not car_id or not master_id or not service_id or not problem:
            QMessageBox.warning(self, "Ошибка", "Заполните все обязательные поля")
            return

        update_data = (
            master_id, car_id, service_id, appointment_date, appointment_time,
            duration, problem, status, price, notes
        )

        try:
            success = self.db.update_service_appointment(self.current_editing_appointment_id, update_data)
            if success:
                QMessageBox.information(self, "Успех", "Запись обновлена")
                self.load_service_appointments()
                self.clear_appointment_form()
                self.reset_appointment_form_buttons()
        except Error as e:
            print(f"Ошибка при обновлении записи: {e}")
            QMessageBox.critical(self, "Ошибка", "Не удалось обновить запись")

    def delete_appointment(self):
        if not self.current_editing_appointment_id:
            QMessageBox.warning(self, "Ошибка", "Сначала выберите запись из таблицы")
            return

        reply = QMessageBox.question(
            self, 'Подтверждение',
            'Вы уверены, что хотите удалить эту запись?',
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )

        if reply == QMessageBox.StandardButton.Yes:
            try:
                success = self.db.delete_service_appointment(self.current_editing_appointment_id)
                if success:
                    QMessageBox.information(self, "Успех", "Запись удалена")
                    self.load_service_appointments()
                    self.clear_appointment_form()
                    self.reset_appointment_form_buttons()
            except Error as e:
                print(f"Ошибка при удалении записи: {e}")
                QMessageBox.critical(self, "Ошибка", "Не удалось удалить запись")

    def on_appointment_table_click(self):
        selected = self.appointments_table.currentRow()
        if selected < 0:
            return

        appointment_id = int(self.appointments_table.item(selected, 0).text())
        self.current_editing_appointment_id = appointment_id

        try:
            appointments = self.db.get_all_service_appointments()
            selected_appointment = None
            for app in appointments:
                if app['id'] == appointment_id:
                    selected_appointment = app
                    break

            if selected_appointment:
                # Находим клиента
                for i in range(self.client_combo.count()):
                    if self.client_combo.itemData(i) == selected_appointment['client_id']:
                        self.client_combo.setCurrentIndex(i)
                        # Загружаем автомобили этого клиента
                        self.load_cars_for_client(selected_appointment['client_id'])
                        break

                # Находим автомобиль
                for i in range(self.car_combo.count()):
                    if self.car_combo.itemData(i) == selected_appointment['car_id']:
                        self.car_combo.setCurrentIndex(i)
                        break

                # Находим мастера
                for i in range(self.master_combo.count()):
                    if self.master_combo.itemData(i) == selected_appointment['master_id']:
                        self.master_combo.setCurrentIndex(i)
                        break

                # Находим услугу
                service_found = False
                for i in range(self.service_combo.count()):
                    service_data = self.service_combo.itemData(i)
                    if isinstance(service_data, tuple) and service_data[0] == selected_appointment['service_id']:
                        self.service_combo.setCurrentIndex(i)
                        service_found = True
                        break

                if not service_found:
                    QMessageBox.warning(self, "Внимание", "Услуга не найдена в списке")

                # Устанавливаем остальные поля
                if selected_appointment.get('appointment_date'):
                    try:
                        date_str = selected_appointment['appointment_date']
                        if isinstance(date_str, str):
                            date_parts = date_str.split('-')
                            if len(date_parts) == 3:
                                year, month, day = map(int, date_parts)
                                self.appointment_date.setDate(QDate(year, month, day))
                    except Exception as e:
                        print(f"Ошибка при установке даты: {e}")

                if selected_appointment.get('appointment_time'):
                    try:
                        time_str = selected_appointment['appointment_time']
                        if isinstance(time_str, str) and ':' in time_str:
                            time_parts = time_str.split(':')
                            if len(time_parts) >= 2:
                                hours = int(time_parts[0])
                                minutes = int(time_parts[1])
                                self.appointment_time.setTime(QTime(hours, minutes))
                    except Exception as e:
                        print(f"Ошибка при установке времени: {e}")

                self.duration_input.setValue(selected_appointment.get('duration_hours', 1))
                self.problem_input.setPlainText(selected_appointment.get('problem_description', ''))

                price = selected_appointment.get('total_price', 0)
                try:
                    price_float = float(price)
                except (ValueError, TypeError):
                    price_float = 0.0
                self.price_input.setText(f"{price_float:.2f}")

                status_text = selected_appointment.get('status', 'запланировано')
                index = self.status_combo.findText(status_text)
                if index >= 0:
                    self.status_combo.setCurrentIndex(index)

                self.notes_text.setPlainText(selected_appointment.get('notes', ''))

                # Активируем кнопки
                self.new_appointment_btn.setEnabled(False)
                self.update_appointment_btn.setEnabled(True)
                self.delete_appointment_btn.setEnabled(True)

        except Exception as e:
            print(f"Ошибка при загрузке данных записи: {e}")
            QMessageBox.critical(self, "Ошибка", f"Не удалось загрузить данные записи: {str(e)}")

    def clear_appointment_form(self):
        self.appointment_date.setDate(QDate.currentDate().addDays(1))
        self.appointment_time.setTime(QTime(9, 0))
        self.duration_input.setValue(1)
        self.price_input.clear()
        self.problem_input.clear()
        self.status_combo.setCurrentIndex(0)
        self.notes_text.clear()

    def reset_appointment_form_buttons(self):
        self.current_editing_appointment_id = None
        self.new_appointment_btn.setEnabled(True)
        self.update_appointment_btn.setEnabled(False)
        self.delete_appointment_btn.setEnabled(False)

    # Методы для работы с клиентами
    def load_clients(self):
        try:
            clients = self.db.get_all_clients()
            self.clients_table.setRowCount(len(clients))

            for row, client in enumerate(clients):
                self.clients_table.setItem(row, 0, QTableWidgetItem(str(client['id'])))
                self.clients_table.setItem(row, 1, QTableWidgetItem(client['full_name']))
                self.clients_table.setItem(row, 2, QTableWidgetItem(client.get('phone', '')))
                self.clients_table.setItem(row, 3, QTableWidgetItem(client.get('email', '')))
                self.clients_table.setItem(row, 4, QTableWidgetItem(client.get('driver_license', '')))

                birth_date = client.get('birth_date_str', '')
                if not birth_date and client.get('birth_date'):
                    birth_date = client['birth_date'].strftime('%Y-%m-%d')
                self.clients_table.setItem(row, 5, QTableWidgetItem(birth_date))
        except Error as e:
            print(f"Ошибка при загрузке клиентов: {e}")

    def register_new_client(self):
        full_name = self.new_client_name.text().strip()
        phone = self.new_client_phone.text().strip()
        email = self.new_client_email.text().strip() or None
        birth_date = self.new_client_birth_date.date().toString("yyyy-MM-dd")
        username = self.new_client_username.text().strip()
        password = self.new_client_password.text()
        driver_license = self.new_client_license.text().strip() or None
        license_expiry = self.new_client_license_expiry.date().toString("yyyy-MM-dd")
        preferences = self.new_client_preferences.toPlainText().strip() or None

        if not full_name or not phone or not username or not password:
            QMessageBox.warning(self, "Ошибка", "Заполните все обязательные поля")
            return

        user_data = (username, password, full_name, email, phone, birth_date)
        client_data = (driver_license, license_expiry, preferences)

        try:
            user_id = self.db.register_client(user_data, client_data)

            if user_id:
                QMessageBox.information(self, "Успех",
                                        f"Клиент успешно зарегистрирован!\n\nЛогин: {username}\nПароль: {password}")

                self.load_clients()
                self.load_clients_for_combo()
                self.clear_client_form()

        except Error as e:
            print(f"Ошибка при регистрации клиента: {e}")
            QMessageBox.critical(self, "Ошибка", "Не удалось зарегистрировать клиента")

    def clear_client_form(self):
        self.new_client_name.clear()
        self.new_client_phone.clear()
        self.new_client_email.clear()
        self.new_client_birth_date.setDate(QDate(1990, 1, 1))
        self.new_client_username.clear()
        self.new_client_password.clear()
        self.new_client_license.clear()
        self.new_client_license_expiry.setDate(QDate(2030, 1, 1))
        self.new_client_preferences.clear()

    # Методы для работы с мастерами
    def load_masters(self):
        try:
            masters = self.db.get_all_masters()
            self.masters_table.setRowCount(len(masters))

            for row, master in enumerate(masters):
                self.masters_table.setItem(row, 0, QTableWidgetItem(str(master['id'])))
                self.masters_table.setItem(row, 1, QTableWidgetItem(master['full_name']))
                self.masters_table.setItem(row, 2, QTableWidgetItem(master['specialization']))
                self.masters_table.setItem(row, 3, QTableWidgetItem(master.get('qualification', '')))
                self.masters_table.setItem(row, 4, QTableWidgetItem(master.get('phone', '')))

                rate = master.get('hourly_rate', 0)
                self.masters_table.setItem(row, 5, QTableWidgetItem(f"{rate:.2f}"))
        except Error as e:
            print(f"Ошибка при загрузке мастеров: {e}")

    def add_new_master(self):
        full_name = self.new_master_name.text().strip()
        specialization = self.new_master_specialization.text().strip()
        qualification = self.new_master_qualification.text().strip() or None
        phone = self.new_master_phone.text().strip()
        email = self.new_master_email.text().strip() or None
        experience = self.new_master_experience.value()

        try:
            rate = float(self.new_master_rate.text().strip() or "0")
        except ValueError:
            rate = 0.0

        schedule = self.new_master_schedule.text().strip() or None

        if not full_name or not specialization or not phone:
            QMessageBox.warning(self, "Ошибка", "Заполните все обязательные поля")
            return

        master_data = (full_name, specialization, qualification, phone, email,
                       experience, schedule, rate)

        try:
            master_id = self.db.add_master(master_data)

            if master_id:
                QMessageBox.information(self, "Успех", "Мастер успешно добавлен!")

                self.load_masters()
                self.load_masters_for_combo()
                self.load_filters_data()  # Обновляем фильтры
                self.clear_master_form()

        except Error as e:
            print(f"Ошибка при добавлении мастера: {e}")
            QMessageBox.critical(self, "Ошибка", "Не удалось добавить мастера")

    def clear_master_form(self):
        self.new_master_name.clear()
        self.new_master_specialization.clear()
        self.new_master_qualification.clear()
        self.new_master_phone.clear()
        self.new_master_email.clear()
        self.new_master_experience.setValue(0)
        self.new_master_rate.clear()
        self.new_master_schedule.clear()