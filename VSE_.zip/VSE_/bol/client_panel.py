from datetime import timedelta

from PyQt6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                             QTabWidget, QTableWidget, QTableWidgetItem, QPushButton,
                             QLabel, QLineEdit, QDateEdit, QComboBox, QTextEdit,
                             QGroupBox, QMessageBox, QHeaderView, QTimeEdit, QSpinBox, QGridLayout)
from PyQt6.QtCore import Qt, QDate, QTime
from PyQt6.QtGui import QFont, QColor
from pymysql import Error


class ClientPanel(QMainWindow):
    def __init__(self, db, user):
        super().__init__()
        self.db = db
        self.user = user
        self.patient = None

        self.setWindowTitle(f"Пациентский портал - {user['full_name']}")
        self.setGeometry(100, 100, 1200, 700)

        self.load_patient_data()
        self.setup_ui()

    def load_patient_data(self):
        self.patient = self.db.get_patient_by_user_id(self.user['id'])
        if not self.patient:
            QMessageBox.warning(self, "Внимание", "Профиль пациента не найден")

    def setup_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)

        self.tabs = QTabWidget()
        self.create_new_appointment_tab()
        self.create_my_appointments_tab()
        self.create_doctors_tab()

        main_layout.addWidget(self.tabs)

    def create_new_appointment_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        # ФОРМА ЗАПИСИ НА ПРИЕМ
        appointment_group = QGroupBox("Запись на прием к врачу")
        appointment_layout = QGridLayout()

        # Ряд 0: Выбор врача
        appointment_layout.addWidget(QLabel("Врач:"), 0, 0)
        self.client_doctor_combo = QComboBox()
        self.client_doctor_combo.setMinimumWidth(350)
        self.client_doctor_combo.currentIndexChanged.connect(self.on_client_doctor_changed)
        appointment_layout.addWidget(self.client_doctor_combo, 0, 1, 1, 3)

        # Ряд 1: Дата и время
        appointment_layout.addWidget(QLabel("Дата:"), 1, 0)
        self.client_appointment_date = QDateEdit()
        self.client_appointment_date.setDate(QDate.currentDate().addDays(1))
        self.client_appointment_date.setCalendarPopup(True)
        self.client_appointment_date.setMinimumDate(QDate.currentDate())
        self.client_appointment_date.setMaximumWidth(120)
        appointment_layout.addWidget(self.client_appointment_date, 1, 1)

        appointment_layout.addWidget(QLabel("Время:"), 1, 2)
        self.client_appointment_time = QTimeEdit()
        self.client_appointment_time.setTime(QTime(9, 0))
        self.client_appointment_time.setMaximumWidth(80)
        appointment_layout.addWidget(self.client_appointment_time, 1, 3)

        # Ряд 2: Стоимость
        appointment_layout.addWidget(QLabel("Стоимость:"), 2, 0)
        self.client_price_label = QLabel("0.00 руб.")
        self.client_price_label.setStyleSheet("font-weight: bold;")
        appointment_layout.addWidget(self.client_price_label, 2, 1)

        # Ряд 3: Причина обращения
        appointment_layout.addWidget(QLabel("Причина:"), 3, 0, Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignTop)
        self.client_reason_input = QTextEdit()
        self.client_reason_input.setMaximumHeight(70)
        appointment_layout.addWidget(self.client_reason_input, 3, 1, 1, 3)

        # Ряд 4: Симптомы
        appointment_layout.addWidget(QLabel("Симптомы:"), 4, 0, Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignTop)
        self.client_symptoms_input = QTextEdit()
        self.client_symptoms_input.setMaximumHeight(70)
        appointment_layout.addWidget(self.client_symptoms_input, 4, 1, 1, 3)

        # Ряд 5: Кнопка записи
        appointment_btn_layout = QHBoxLayout()
        new_appointment_btn = QPushButton("Записаться на прием")
        new_appointment_btn.clicked.connect(self.create_new_appointment)
        appointment_btn_layout.addStretch()
        appointment_btn_layout.addWidget(new_appointment_btn)
        appointment_btn_layout.addStretch()
        appointment_layout.addLayout(appointment_btn_layout, 5, 0, 1, 4)

        appointment_group.setLayout(appointment_layout)
        layout.addWidget(appointment_group)

        layout.addStretch()

        self.tabs.addTab(tab, "Новая запись")

        # Загружаем врачей
        self.load_client_doctors()

    def create_my_appointments_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        # Таблица моих записей
        self.client_appointments_table = QTableWidget()
        self.client_appointments_table.setColumnCount(7)
        self.client_appointments_table.setHorizontalHeaderLabels([
            "ID", "Врач", "Специализация", "Дата", "Время", "Причина", "Статус"
        ])

        header = self.client_appointments_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)

        layout.addWidget(self.client_appointments_table)

        self.tabs.addTab(tab, "Мои записи")

        # Загружаем записи пациента
        if self.patient:
            self.load_client_appointments()

    def create_doctors_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        # Таблица врачей
        self.client_doctors_table = QTableWidget()
        self.client_doctors_table.setColumnCount(6)
        self.client_doctors_table.setHorizontalHeaderLabels([
            "ID", "ФИО", "Специализация", "Квалификация", "Кабинет", "Стоимость приема"
        ])

        header = self.client_doctors_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)

        layout.addWidget(self.client_doctors_table)

        self.tabs.addTab(tab, "Наши врачи")

        # Загружаем врачей
        self.load_client_doctors_table()

    def load_client_doctors(self):
        try:
            doctors = self.db.get_all_doctors()
            self.client_doctor_combo.clear()
            for doctor in doctors:
                price = float(doctor.get('price_per_appointment', 0))
                # Сохраняем только ID врача
                self.client_doctor_combo.addItem(
                    f"{doctor['full_name']} ({doctor['specialization']}) - {price:.2f} руб.",
                    doctor['id']
                )
        except Error as e:
            print(f"Ошибка при загрузке врачей: {e}")

    def on_client_doctor_changed(self):
        """Обновляет цену при выборе врача для пациента"""
        doctor_id = self.client_doctor_combo.currentData()
        if not doctor_id:
            self.client_price_label.setText("0.00 руб.")
            return

        # Получаем цену врача из БД
        try:
            doctor = self.db.get_doctor_by_id(doctor_id)
            if doctor and doctor.get('price_per_appointment'):
                price = float(doctor['price_per_appointment'])
                self.client_price_label.setText(f"{price:.2f} руб.")
            else:
                self.client_price_label.setText("0.00 руб.")
        except Exception as e:
            print(f"Ошибка при получении цены врача: {e}")
            self.client_price_label.setText("0.00 руб.")
            
    def load_client_doctors_table(self):
        try:
            doctors = self.db.get_all_doctors()
            self.client_doctors_table.setRowCount(len(doctors))

            for row, doctor in enumerate(doctors):
                self.client_doctors_table.setItem(row, 0, QTableWidgetItem(str(doctor['id'])))
                self.client_doctors_table.setItem(row, 1, QTableWidgetItem(doctor['full_name']))
                self.client_doctors_table.setItem(row, 2, QTableWidgetItem(doctor['specialization']))
                self.client_doctors_table.setItem(row, 3, QTableWidgetItem(doctor.get('qualification', '')))
                self.client_doctors_table.setItem(row, 4, QTableWidgetItem(doctor.get('office_number', '')))

                price = float(doctor.get('price_per_appointment', 0))
                self.client_doctors_table.setItem(row, 5, QTableWidgetItem(f"{price:.2f} руб."))
        except Error as e:
            print(f"Ошибка при загрузке врачей в таблицу: {e}")

    def create_new_appointment(self):
        if not self.patient:
            QMessageBox.warning(self, "Ошибка", "Профиль пациента не найден")
            return

        doctor_data = self.client_doctor_combo.currentData()
        if not doctor_data:
            QMessageBox.warning(self, "Ошибка", "Выберите врача")
            return

        # Получаем ID врача и цену
        if isinstance(doctor_data, tuple) and len(doctor_data) >= 2:
            doctor_id, doctor_price = doctor_data
            doctor_id = doctor_data[0]
        else:
            doctor_id = doctor_data
            # Получаем цену из БД если не в комбобоксе
            try:
                doctor = self.db.get_doctor_by_id(doctor_id)
                doctor_price = float(doctor.get('price_per_appointment', 0)) if doctor else 0.0
            except:
                doctor_price = 0.0

        appointment_date = self.client_appointment_date.date().toString("yyyy-MM-dd")
        appointment_time = self.client_appointment_time.time().toString("HH:mm")
        reason = self.client_reason_input.toPlainText().strip()
        symptoms = self.client_symptoms_input.toPlainText().strip()

        if not doctor_id or not reason:
            QMessageBox.warning(self, "Ошибка", "Выберите врача и укажите причину обращения")
            return

        # Проверяем доступность времени
        is_available = self.db.check_time_availability(
            doctor_id, appointment_date, appointment_time, 30  # Стандартная длительность 30 минут
        )

        if not is_available:
            QMessageBox.warning(self, "Ошибка", "Выбранное время уже занято")
            return

        appointment_data = (
            self.patient['id'], doctor_id, appointment_date, appointment_time,
            30, reason, symptoms, 'scheduled', doctor_price, ""
        )

        try:
            appointment_id = self.db.create_appointment(appointment_data)
            if appointment_id:
                QMessageBox.information(self, "Успех",
                                        f"Вы успешно записаны на прием!\nНомер записи: {appointment_id}\nСтоимость: {doctor_price:.2f} руб.")
                self.load_client_appointments()
                self.clear_client_appointment_form()
        except Error as e:
            print(f"Ошибка при создании записи: {e}")
            QMessageBox.critical(self, "Ошибка", "Не удалось создать запись")

    def load_client_appointments(self):
        if not self.patient:
            return

        try:
            appointments = self.db.get_patient_appointments(self.patient['id'])
            self.client_appointments_table.setRowCount(len(appointments))

            for row, appointment in enumerate(appointments):
                self.client_appointments_table.setItem(row, 0, QTableWidgetItem(str(appointment.get('id', ''))))
                self.client_appointments_table.setItem(row, 1, QTableWidgetItem(appointment.get('doctor_name', '')))
                self.client_appointments_table.setItem(row, 2,
                                                       QTableWidgetItem(appointment.get('doctor_specialization', '')))

                # Исправлено: преобразуем дату в строку
                appointment_date = appointment.get('appointment_date', '')
                if appointment_date:
                    if not isinstance(appointment_date, str):
                        appointment_date = appointment_date.strftime('%Y-%m-%d')
                self.client_appointments_table.setItem(row, 3, QTableWidgetItem(appointment_date))

                appointment_time = appointment.get('appointment_time', '')
                if appointment_time:
                    if not isinstance(appointment_time, str):
                        if hasattr(appointment_time, 'strftime'):
                            appointment_time = appointment_time.strftime('%H:%M')
                        elif isinstance(appointment_time, timedelta):
                            total_seconds = int(appointment_time.total_seconds())
                            hours = total_seconds // 3600
                            minutes = (total_seconds % 3600) // 60
                            appointment_time = f"{hours:02d}:{minutes:02d}"
                self.client_appointments_table.setItem(row, 4, QTableWidgetItem(appointment_time))

                self.client_appointments_table.setItem(row, 5, QTableWidgetItem(appointment.get('reason', '')))

                status_item = QTableWidgetItem(appointment.get('status', ''))
                status_text = appointment.get('status', '')

                # Раскрашиваем статусы
                if status_text == 'completed':
                    status_item.setBackground(QColor(200, 255, 200))  # Зеленый
                elif status_text == 'cancelled':
                    status_item.setBackground(QColor(255, 200, 200))  # Красный
                elif status_text == 'no_show':
                    status_item.setBackground(QColor(255, 150, 150))  # Темно-красный
                elif status_text == 'scheduled':
                    status_item.setBackground(QColor(255, 255, 200))  # Желтый

                self.client_appointments_table.setItem(row, 6, status_item)
        except Error as e:
            print(f"Ошибка при загрузке записей пациента: {e}")


    def clear_client_appointment_form(self):
        self.client_appointment_date.setDate(QDate.currentDate().addDays(1))
        self.client_appointment_time.setTime(QTime(9, 0))
        self.client_reason_input.clear()
        self.client_symptoms_input.clear()