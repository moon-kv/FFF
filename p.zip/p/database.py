import pymysql
from pymysql import Error
from datetime import datetime, timedelta


class Database:
    def __init__(self):
        self.host = "localhost"
        self.user = "root"
        self.password = "dn260306"  # Измените на ваш пароль MySQL
        self.database = "hotel_management"
        self.charset = "utf8mb4"
        self.connection = None

    def connect(self):
        try:
            self.connection = pymysql.connect(
                host=self.host,
                user=self.user,
                password=self.password,
                database=self.database,
                charset=self.charset,
                cursorclass=pymysql.cursors.DictCursor
            )
            print("Успешное подключение к базе данных")
            return True
        except Error as e:
            print(f"Ошибка подключения к базе данных: {e}")
            return False

    def disconnect(self):
        if self.connection:
            self.connection.close()
            print("Отключение от базы данных")

    def authenticate_user(self, username, password):
        try:
            with self.connection.cursor() as cursor:
                sql = "SELECT * FROM users WHERE username = %s AND password = %s"
                cursor.execute(sql, (username, password))
                user = cursor.fetchone()
                return user
        except Error as e:
            print(f"Ошибка аутентификации: {e}")
            return None

    # Методы для администратора
    def get_bookings_by_period(self, start_date, end_date):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                SELECT b.*, g.full_name, g.passport_number, r.room_number, r.category, r.floor
                FROM bookings b
                JOIN guests g ON b.guest_id = g.id
                JOIN rooms r ON b.room_id = r.id
                WHERE (b.check_in_date BETWEEN %s AND %s)
                   OR (b.check_out_date BETWEEN %s AND %s)
                   OR (b.check_in_date <= %s AND (b.check_out_date IS NULL OR b.check_out_date >= %s))
                ORDER BY b.check_in_date
                """
                cursor.execute(sql, (start_date, end_date, start_date, end_date, start_date, end_date))
                bookings = cursor.fetchall()

                # Конвертируем даты в строки для удобства
                for booking in bookings:
                    if booking['check_in_date']:
                        booking['check_in_date'] = booking['check_in_date'].strftime('%Y-%m-%d')
                    if booking['check_out_date']:
                        booking['check_out_date'] = booking['check_out_date'].strftime('%Y-%m-%d')
                return bookings
        except Error as e:
            print(f"Ошибка при получении бронирований: {e}")
            return []

    def get_all_bookings(self):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                SELECT b.*, g.full_name, g.passport_number, r.room_number, r.category, r.floor
                FROM bookings b
                JOIN guests g ON b.guest_id = g.id
                JOIN rooms r ON b.room_id = r.id
                ORDER BY b.check_in_date DESC
                """
                cursor.execute(sql)
                bookings = cursor.fetchall()

                # Конвертируем даты в строки для удобства
                for booking in bookings:
                    if booking['check_in_date']:
                        booking['check_in_date'] = booking['check_in_date'].strftime('%Y-%m-%d')
                    if booking['check_out_date']:
                        booking['check_out_date'] = booking['check_out_date'].strftime('%Y-%m-%d')
                return bookings
        except Error as e:
            print(f"Ошибка при получении всех бронирований: {e}")
            return []

    def add_guest(self, guest_data):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                INSERT INTO guests (
                    passport_number, full_name, phone, email, birth_date,
                    passport_issued_by, passport_issue_date, passport_expiry
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                """
                cursor.execute(sql, guest_data)
                self.connection.commit()
                return cursor.lastrowid
        except Error as e:
            print(f"Ошибка при добавлении гостя: {e}")
            return None

    def create_booking(self, booking_data):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                INSERT INTO bookings (
                    guest_id, room_id, check_in_date, check_out_date,
                    purpose_of_visit, claim_level, special_requests, status
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                """
                cursor.execute(sql, booking_data)
                self.connection.commit()
                return cursor.lastrowid
        except Error as e:
            print(f"Ошибка при создании бронирования: {e}")
            return None

    def update_booking(self, booking_id, update_data):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                UPDATE bookings SET 
                    room_id = %s,
                    check_in_date = %s,
                    check_out_date = %s,
                    purpose_of_visit = %s,
                    claim_level = %s,
                    special_requests = %s,
                    status = %s
                WHERE id = %s
                """
                cursor.execute(sql, (*update_data, booking_id))
                self.connection.commit()
                return cursor.rowcount > 0
        except Error as e:
            print(f"Ошибка при обновлении бронирования: {e}")
            return False

    def update_cleaning_scheduled_rooms(self):
        try:
            with self.connection.cursor() as cursor:
                sql = "UPDATE rooms SET status = 'clean' WHERE status = 'cleaning_scheduled'"
                cursor.execute(sql)
                self.connection.commit()
                return cursor.rowcount
        except Error as e:
            print(f"Ошибка при обновлении статуса уборки: {e}")
            return 0

    def get_all_rooms(self):
        try:
            with self.connection.cursor() as cursor:
                sql = "SELECT * FROM rooms ORDER BY floor, room_number"
                cursor.execute(sql)
                return cursor.fetchall()
        except Error as e:
            print(f"Ошибка при получении номеров: {e}")
            return []

    def update_room_status(self, room_number, new_status):
        try:
            with self.connection.cursor() as cursor:
                sql = "UPDATE rooms SET status = %s WHERE room_number = %s"
                cursor.execute(sql, (new_status, room_number))
                self.connection.commit()
                return cursor.rowcount > 0
        except Error as e:
            print(f"Ошибка при обновлении статуса номера: {e}")
            return False

    def get_available_rooms(self, start_date, end_date):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                SELECT r.* 
                FROM rooms r
                WHERE r.status = 'clean'
                AND r.id NOT IN (
                    SELECT room_id 
                    FROM bookings 
                    WHERE status IN ('reserved', 'checked_in')
                    AND (
                        (check_in_date <= %s AND (check_out_date IS NULL OR check_out_date >= %s))
                        OR (check_in_date BETWEEN %s AND %s)
                    )
                )
                ORDER BY r.floor, r.room_number
                """
                cursor.execute(sql, (end_date, start_date, start_date, end_date))
                return cursor.fetchall()
        except Error as e:
            print(f"Ошибка при получении доступных номеров: {e}")
            return []

    def get_all_guests(self):
        try:
            with self.connection.cursor() as cursor:
                sql = "SELECT * FROM guests ORDER BY full_name"
                cursor.execute(sql)
                guests = cursor.fetchall()

                # Конвертируем даты в строки для удобства
                for guest in guests:
                    for date_field in ['birth_date', 'passport_issue_date', 'passport_expiry']:
                        if guest[date_field]:
                            guest[date_field] = guest[date_field].strftime('%Y-%m-%d')
                return guests
        except Error as e:
            print(f"Ошибка при получении гостей: {e}")
            return []

    def get_services(self):
        try:
            with self.connection.cursor() as cursor:
                sql = "SELECT * FROM services ORDER BY service_name"
                cursor.execute(sql)
                return cursor.fetchall()
        except Error as e:
            print(f"Ошибка при получении услуг: {e}")
            return []



    def get_guest_by_user_id(self, user_id):
        try:
            with self.connection.cursor() as cursor:
                sql = "SELECT * FROM guests WHERE user_id = %s"
                cursor.execute(sql, (user_id,))
                guest = cursor.fetchone()

                if guest:
                    # Конвертируем даты в строки для удобства
                    for date_field in ['birth_date', 'passport_issue_date', 'passport_expiry']:
                        if guest[date_field]:
                            guest[date_field] = guest[date_field].strftime('%Y-%m-%d')
                return guest
        except Error as e:
            print(f"Ошибка при получении гостя: {e}")
            return None

    def get_booking_status(self, guest_id):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                SELECT b.*, r.room_number, r.category, r.floor
                FROM bookings b
                JOIN rooms r ON b.room_id = r.id
                WHERE b.guest_id = %s
                ORDER BY b.booking_date DESC
                """
                cursor.execute(sql, (guest_id,))
                bookings = cursor.fetchall()

                # Конвертируем даты в строки для удобства
                for booking in bookings:
                    for date_field in ['check_in_date', 'check_out_date', 'booking_date']:
                        if booking[date_field]:
                            booking[date_field] = booking[date_field].strftime('%Y-%m-%d')
                return bookings
        except Error as e:
            print(f"Ошибка при получении статуса бронирования: {e}")
            return []