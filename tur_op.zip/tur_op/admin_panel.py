from PyQt6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                             QTabWidget, QTableWidget, QTableWidgetItem, QPushButton,
                             QLabel, QLineEdit, QDateEdit, QComboBox, QTextEdit,
                             QGroupBox, QMessageBox, QHeaderView, QFormLayout,
                             QSpinBox, QDoubleSpinBox, QGridLayout)
from PyQt6.QtCore import Qt, QDate
from PyQt6.QtGui import QFont, QColor
from pymysql import Error
from datetime import datetime, timedelta


class AdminPanel(QMainWindow):
    def __init__(self, db, user):
        super().__init__()
        self.db = db
        self.user = user
        self.current_editing_booking_id = None

        self.setWindowTitle(f"Панель администратора - {user['full_name']}")
        self.setGeometry(100, 100, 1400, 800)

        self.setup_ui()
        self.load_initial_data()

    def setup_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        self.tabs = QTabWidget()
        self.create_bookings_tab()
        self.create_clients_tab()
        self.create_tours_tab()
        main_layout.addWidget(self.tabs)

    def create_bookings_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        # ФОРМА СОЗДАНИЯ/РЕДАКТИРОВАНИЯ ЗАЯВКИ
        self.booking_form_group = QGroupBox("Создание новой заявки")
        booking_form_layout = QVBoxLayout()

        # Выбор клиента и тура
        first_row = QHBoxLayout()
        first_row.addWidget(QLabel("Клиент:"))
        self.client_combo = QComboBox()
        self.client_combo.setMinimumWidth(300)
        first_row.addWidget(self.client_combo)
        first_row.addWidget(QLabel("Тур:"))
        self.tour_combo = QComboBox()
        self.tour_combo.setMinimumWidth(300)
        self.tour_combo.currentIndexChanged.connect(self.update_tour_info)
        first_row.addWidget(self.tour_combo)
        first_row.addStretch()
        booking_form_layout.addLayout(first_row)

        # Информация о туре
        info_row = QHBoxLayout()
        info_row.addWidget(QLabel("Страна:"))
        self.country_label = QLabel("")
        info_row.addWidget(self.country_label)
        info_row.addWidget(QLabel("Даты:"))
        self.dates_label = QLabel("")
        info_row.addWidget(self.dates_label)
        info_row.addWidget(QLabel("Длительность:"))
        self.duration_label = QLabel("")
        info_row.addWidget(self.duration_label)
        info_row.addWidget(QLabel("Свободных мест:"))
        self.available_seats_label = QLabel("")
        info_row.addWidget(self.available_seats_label)
        info_row.addStretch()
        booking_form_layout.addLayout(info_row)

        # Данные заявки
        third_row = QHBoxLayout()
        third_row.addWidget(QLabel("Дата заявки:"))
        self.booking_date = QDateEdit()
        self.booking_date.setDate(QDate.currentDate())
        self.booking_date.setCalendarPopup(True)
        third_row.addWidget(self.booking_date)
        third_row.addWidget(QLabel("Кол-во человек:"))
        self.persons_count = QSpinBox()
        self.persons_count.setMinimum(1)
        self.persons_count.setMaximum(10)
        self.persons_count.valueChanged.connect(self.calculate_total_price)
        third_row.addWidget(self.persons_count)
        third_row.addWidget(QLabel("Общая стоимость:"))
        self.total_price_input = QLineEdit()
        self.total_price_input.setReadOnly(True)
        third_row.addWidget(self.total_price_input)
        third_row.addStretch()
        booking_form_layout.addLayout(third_row)

        # Статус и примечания
        fourth_row = QHBoxLayout()
        fourth_row.addWidget(QLabel("Статус:"))
        self.status_combo = QComboBox()
        self.status_combo.addItems(['pending', 'confirmed', 'cancelled', 'completed'])
        fourth_row.addWidget(self.status_combo)
        fourth_row.addWidget(QLabel("Примечания:"))
        self.notes_text = QTextEdit()
        self.notes_text.setMaximumHeight(60)
        fourth_row.addWidget(self.notes_text)
        booking_form_layout.addLayout(fourth_row)

        # Кнопки управления
        buttons_row = QHBoxLayout()
        self.new_booking_btn = QPushButton("Создать новую заявку")
        self.new_booking_btn.clicked.connect(self.create_booking_from_form)
        buttons_row.addWidget(self.new_booking_btn)

        self.update_booking_btn = QPushButton("Обновить заявку")
        self.update_booking_btn.clicked.connect(self.update_booking_from_form)
        self.update_booking_btn.setEnabled(False)
        buttons_row.addWidget(self.update_booking_btn)

        self.delete_booking_btn = QPushButton("Удалить заявку")
        self.delete_booking_btn.clicked.connect(self.delete_booking)
        self.delete_booking_btn.setEnabled(False)
        buttons_row.addWidget(self.delete_booking_btn)

        self.cancel_edit_btn = QPushButton("Отменить редактирование")
        self.cancel_edit_btn.clicked.connect(self.cancel_editing)
        self.cancel_edit_btn.setEnabled(False)
        buttons_row.addWidget(self.cancel_edit_btn)

        buttons_row.addStretch()
        booking_form_layout.addLayout(buttons_row)

        self.booking_form_group.setLayout(booking_form_layout)
        layout.addWidget(self.booking_form_group)

        # ФИЛЬТРЫ
        filter_group = QGroupBox("Фильтр заявок")
        filter_layout = QVBoxLayout()

        # Фильтр по дате
        date_filter_layout = QHBoxLayout()
        date_filter_layout.addWidget(QLabel("Период с:"))
        self.start_date_filter = QDateEdit()
        self.start_date_filter.setDate(QDate.currentDate().addMonths(-1))
        self.start_date_filter.setCalendarPopup(True)
        date_filter_layout.addWidget(self.start_date_filter)
        date_filter_layout.addWidget(QLabel("по:"))
        self.end_date_filter = QDateEdit()
        self.end_date_filter.setDate(QDate.currentDate())
        self.end_date_filter.setCalendarPopup(True)
        date_filter_layout.addWidget(self.end_date_filter)
        filter_date_btn = QPushButton("Фильтровать по дате")
        filter_date_btn.clicked.connect(self.filter_bookings_by_date)
        date_filter_layout.addWidget(filter_date_btn)
        date_filter_layout.addStretch()
        filter_layout.addLayout(date_filter_layout)

        # Фильтр по стране
        country_filter_layout = QHBoxLayout()
        country_filter_layout.addWidget(QLabel("Страна:"))
        self.country_filter_combo = QComboBox()
        self.country_filter_combo.addItem("Все страны", None)
        country_filter_layout.addWidget(self.country_filter_combo)
        filter_country_btn = QPushButton("Фильтровать по стране")
        filter_country_btn.clicked.connect(self.filter_bookings_by_country)
        country_filter_layout.addWidget(filter_country_btn)
        show_all_btn = QPushButton("Показать все")
        show_all_btn.clicked.connect(self.show_all_bookings)
        country_filter_layout.addWidget(show_all_btn)
        country_filter_layout.addStretch()
        filter_layout.addLayout(country_filter_layout)

        filter_group.setLayout(filter_layout)
        layout.addWidget(filter_group)

        # ТАБЛИЦА ЗАЯВОК
        self.bookings_table = QTableWidget()
        self.bookings_table.setColumnCount(10)
        self.bookings_table.setHorizontalHeaderLabels([
            "ID", "Клиент", "Телефон", "Тур", "Страна",
            "Дата заявки", "Кол-во", "Стоимость", "Статус", "Туроператор"
        ])
        header = self.bookings_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        self.bookings_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.bookings_table.clicked.connect(self.on_booking_table_click)
        layout.addWidget(self.bookings_table)
        self.tabs.addTab(tab, "Заявки")
        self.load_clients_for_combo()
        self.load_tours_for_combo()
        self.load_countries_for_filter()

    def create_clients_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        # ФОРМА РЕГИСТРАЦИИ КЛИЕНТА
        client_form_group = QGroupBox("Регистрация нового клиента")
        client_form_layout = QGridLayout()

        client_form_layout.addWidget(QLabel("ФИО:"), 0, 0)
        self.new_client_name = QLineEdit()
        self.new_client_name.setPlaceholderText("Иванов Иван Иванович")
        client_form_layout.addWidget(self.new_client_name, 0, 1)

        client_form_layout.addWidget(QLabel("Телефон:"), 0, 2)
        self.new_client_phone = QLineEdit()
        self.new_client_phone.setPlaceholderText("+79991234567")
        client_form_layout.addWidget(self.new_client_phone, 0, 3)

        client_form_layout.addWidget(QLabel("Email:"), 1, 0)
        self.new_client_email = QLineEdit()
        self.new_client_email.setPlaceholderText("client@mail.ru")
        client_form_layout.addWidget(self.new_client_email, 1, 1)

        client_form_layout.addWidget(QLabel("Дата рождения:"), 1, 2)
        self.new_client_birth_date = QDateEdit()
        self.new_client_birth_date.setCalendarPopup(True)
        self.new_client_birth_date.setDate(QDate(1990, 1, 1))
        client_form_layout.addWidget(self.new_client_birth_date, 1, 3)

        client_form_layout.addWidget(QLabel("Логин:"), 2, 0)
        self.new_client_username = QLineEdit()
        self.new_client_username.setPlaceholderText("Логин для входа")
        client_form_layout.addWidget(self.new_client_username, 2, 1)

        client_form_layout.addWidget(QLabel("Пароль:"), 2, 2)
        self.new_client_password = QLineEdit()
        self.new_client_password.setPlaceholderText("Пароль для входа")
        client_form_layout.addWidget(self.new_client_password, 2, 3)

        client_form_layout.addWidget(QLabel("Роль:"), 3, 0)
        self.new_client_role = QComboBox()
        self.new_client_role.addItems(['client', 'admin'])
        client_form_layout.addWidget(self.new_client_role, 3, 1)

        # Кнопки
        client_buttons_layout = QHBoxLayout()
        register_client_btn = QPushButton("Зарегистрировать пользователя")
        register_client_btn.clicked.connect(self.register_new_client)
        client_buttons_layout.addWidget(register_client_btn)
        clear_client_btn = QPushButton("Очистить форму")
        clear_client_btn.clicked.connect(self.clear_client_form)
        client_buttons_layout.addWidget(clear_client_btn)
        client_buttons_layout.addStretch()
        client_form_layout.addLayout(client_buttons_layout, 4, 0, 1, 4)

        client_form_group.setLayout(client_form_layout)
        layout.addWidget(client_form_group)

        # ТАБЛИЦА КЛИЕНТОВ
        self.clients_table = QTableWidget()
        self.clients_table.setColumnCount(7)
        self.clients_table.setHorizontalHeaderLabels([
            "ID", "ФИО", "Роль", "Телефон", "Email", "Дата рождения", "Дата регистрации"
        ])
        header = self.clients_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        layout.addWidget(self.clients_table)
        self.tabs.addTab(tab, "Клиенты")

    def create_tours_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        # ФОРМА ДОБАВЛЕНИЯ ТУРА
        tour_form_group = QGroupBox("Добавление нового тура")
        tour_form_layout = QGridLayout()

        tour_form_layout.addWidget(QLabel("Название тура:"), 0, 0)
        self.new_tour_name = QLineEdit()
        self.new_tour_name.setPlaceholderText("Отдых в Турции")
        tour_form_layout.addWidget(self.new_tour_name, 0, 1, 1, 3)

        tour_form_layout.addWidget(QLabel("Описание:"), 1, 0)
        self.new_tour_description = QTextEdit()
        self.new_tour_description.setMaximumHeight(80)
        tour_form_layout.addWidget(self.new_tour_description, 1, 1, 1, 3)

        tour_form_layout.addWidget(QLabel("Страна:"), 2, 0)
        self.new_tour_country = QLineEdit()
        self.new_tour_country.setPlaceholderText("Турция")
        tour_form_layout.addWidget(self.new_tour_country, 2, 1)

        tour_form_layout.addWidget(QLabel("Город:"), 2, 2)
        self.new_tour_city = QLineEdit()
        self.new_tour_city.setPlaceholderText("Анталия")
        tour_form_layout.addWidget(self.new_tour_city, 2, 3)

        tour_form_layout.addWidget(QLabel("Туроператор:"), 3, 0)
        self.new_tour_operator = QLineEdit()
        self.new_tour_operator.setPlaceholderText("Coral Travel")
        tour_form_layout.addWidget(self.new_tour_operator, 3, 1)

        tour_form_layout.addWidget(QLabel("Тип тура:"), 3, 2)
        self.new_tour_type = QComboBox()
        self.new_tour_type.addItems(['экскурсионный', 'пляжный', 'горнолыжный', 'лечебный', 'круиз'])
        tour_form_layout.addWidget(self.new_tour_type, 3, 3)

        tour_form_layout.addWidget(QLabel("Дата начала:"), 4, 0)
        self.new_tour_start_date = QDateEdit()
        self.new_tour_start_date.setDate(QDate.currentDate().addMonths(1))
        self.new_tour_start_date.setCalendarPopup(True)
        tour_form_layout.addWidget(self.new_tour_start_date, 4, 1)

        tour_form_layout.addWidget(QLabel("Дата окончания:"), 4, 2)
        self.new_tour_end_date = QDateEdit()
        self.new_tour_end_date.setDate(QDate.currentDate().addMonths(1).addDays(7))
        self.new_tour_end_date.setCalendarPopup(True)
        tour_form_layout.addWidget(self.new_tour_end_date, 4, 3)

        tour_form_layout.addWidget(QLabel("Длительность (дней):"), 5, 0)
        self.new_tour_duration = QSpinBox()
        self.new_tour_duration.setMinimum(1)
        self.new_tour_duration.setMaximum(365)
        self.new_tour_duration.setValue(7)
        tour_form_layout.addWidget(self.new_tour_duration, 5, 1)

        tour_form_layout.addWidget(QLabel("Стоимость (руб.):"), 5, 2)
        self.new_tour_price = QDoubleSpinBox()
        self.new_tour_price.setMinimum(0)
        self.new_tour_price.setMaximum(1000000)
        self.new_tour_price.setValue(50000)
        tour_form_layout.addWidget(self.new_tour_price, 5, 3)

        tour_form_layout.addWidget(QLabel("Макс. человек:"), 6, 0)
        self.new_tour_max_persons = QSpinBox()
        self.new_tour_max_persons.setMinimum(1)
        self.new_tour_max_persons.setMaximum(100)
        self.new_tour_max_persons.setValue(20)
        tour_form_layout.addWidget(self.new_tour_max_persons, 6, 1)

        # Кнопки
        tour_buttons_layout = QHBoxLayout()
        add_tour_btn = QPushButton("Добавить тур")
        add_tour_btn.clicked.connect(self.add_new_tour)
        tour_buttons_layout.addWidget(add_tour_btn)
        clear_tour_btn = QPushButton("Очистить форму")
        clear_tour_btn.clicked.connect(self.clear_tour_form)
        tour_buttons_layout.addWidget(clear_tour_btn)
        tour_buttons_layout.addStretch()
        tour_form_layout.addLayout(tour_buttons_layout, 7, 0, 1, 4)

        tour_form_group.setLayout(tour_form_layout)
        layout.addWidget(tour_form_group)

        # ТАБЛИЦА ТУРОВ
        self.tours_table = QTableWidget()
        self.tours_table.setColumnCount(9)
        self.tours_table.setHorizontalHeaderLabels([
            "ID", "Название", "Страна", "Город", "Туроператор",
            "Дата начала", "Дата окончания", "Стоимость", "Свободных мест"
        ])
        header = self.tours_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        layout.addWidget(self.tours_table)
        self.tabs.addTab(tab, "Туры")

    def load_initial_data(self):
        self.show_all_bookings()
        self.load_clients()
        self.load_tours()

    def load_clients_for_combo(self):
        try:
            users = self.db.get_all_users()
            self.client_combo.clear()
            for user in users:
                if user['role'] == 'client':
                    self.client_combo.addItem(
                        f"{user['full_name']} (тел: {user.get('phone', '')})",
                        user['id']
                    )
        except Error as e:
            print(f"Ошибка при загрузке клиентов: {e}")

    def load_tours_for_combo(self):
        try:
            tours = self.db.get_all_tours()
            self.tour_combo.clear()
            for tour in tours:
                self.tour_combo.addItem(
                    f"{tour['tour_name']} ({tour['country']}, {tour['price']} руб.)",
                    tour['id']
                )
        except Error as e:
            print(f"Ошибка при загрузке туров: {e}")

    def load_countries_for_filter(self):
        try:
            countries = self.db.get_all_countries()
            self.country_filter_combo.clear()
            self.country_filter_combo.addItem("Все страны", None)
            for country in countries:
                self.country_filter_combo.addItem(country, country)
        except Error as e:
            print(f"Ошибка при загрузке стран: {e}")

    def update_tour_info(self):
        tour_id = self.tour_combo.currentData()
        if not tour_id:
            return

        try:
            tour = self.db.get_tour_by_id(tour_id)
            if tour:
                self.country_label.setText(tour['country'])
                self.dates_label.setText(f"{tour['start_date']} - {tour['end_date']}")
                self.duration_label.setText(f"{tour['duration_days']} дней")
                self.available_seats_label.setText(str(tour['available_seats']))
                self.calculate_total_price()
        except Error as e:
            print(f"Ошибка при обновлении информации о туре: {e}")

    def calculate_total_price(self):
        tour_id = self.tour_combo.currentData()
        if not tour_id:
            return

        try:
            tour = self.db.get_tour_by_id(tour_id)
            if tour:
                persons = self.persons_count.value()
                total = float(tour['price']) * persons
                self.total_price_input.setText(f"{total:.2f}")
        except Error as e:
            print(f"Ошибка при расчете стоимости: {e}")

    def show_all_bookings(self):
        bookings = self.db.get_all_bookings()
        self.update_bookings_table(bookings)

    def filter_bookings_by_date(self):
        start_date = self.start_date_filter.date().toString("yyyy-MM-dd")
        end_date = self.end_date_filter.date().toString("yyyy-MM-dd")
        bookings = self.db.get_bookings_by_period(start_date, end_date)
        self.update_bookings_table(bookings)

    def filter_bookings_by_country(self):
        country = self.country_filter_combo.currentData()
        if not country:
            self.show_all_bookings()
        else:
            bookings = self.db.get_bookings_by_country(country)
            self.update_bookings_table(bookings)

    def update_bookings_table(self, bookings):
        self.bookings_table.setRowCount(len(bookings))
        for row, booking in enumerate(bookings):
            self.bookings_table.setItem(row, 0, QTableWidgetItem(str(booking.get('id', ''))))
            self.bookings_table.setItem(row, 1, QTableWidgetItem(booking.get('client_name', '')))
            self.bookings_table.setItem(row, 2, QTableWidgetItem(booking.get('client_phone', '')))
            self.bookings_table.setItem(row, 3, QTableWidgetItem(booking.get('tour_name', '')))
            self.bookings_table.setItem(row, 4, QTableWidgetItem(booking.get('country', '')))
            self.bookings_table.setItem(row, 5, QTableWidgetItem(booking.get('booking_date', '')))
            self.bookings_table.setItem(row, 6, QTableWidgetItem(str(booking.get('persons_count', ''))))
            self.bookings_table.setItem(row, 7, QTableWidgetItem(f"{float(booking.get('total_price', 0)):.2f} руб."))

            status_item = QTableWidgetItem(booking.get('status', ''))
            status_text = booking.get('status', '')
            if status_text == 'confirmed':
                status_item.setBackground(QColor(200, 255, 200))
            elif status_text == 'cancelled':
                status_item.setBackground(QColor(255, 200, 200))
            elif status_text == 'completed':
                status_item.setBackground(QColor(150, 200, 255))
            elif status_text == 'pending':
                status_item.setBackground(QColor(255, 255, 200))
            self.bookings_table.setItem(row, 8, status_item)

            self.bookings_table.setItem(row, 9, QTableWidgetItem(booking.get('tour_operator', '')))

    def load_clients(self):
        users = self.db.get_all_users()
        self.clients_table.setRowCount(len(users))
        for row, user in enumerate(users):
            self.clients_table.setItem(row, 0, QTableWidgetItem(str(user['id'])))
            self.clients_table.setItem(row, 1, QTableWidgetItem(user['full_name']))
            self.clients_table.setItem(row, 2, QTableWidgetItem(user['role']))
            self.clients_table.setItem(row, 3, QTableWidgetItem(user.get('phone', '')))
            self.clients_table.setItem(row, 4, QTableWidgetItem(user.get('email', '')))
            self.clients_table.setItem(row, 5, QTableWidgetItem(user.get('birth_date', '')))
            self.clients_table.setItem(row, 6, QTableWidgetItem(user.get('registration_date', '')))

    def load_tours(self):
        tours = self.db.get_all_tours()
        self.tours_table.setRowCount(len(tours))
        for row, tour in enumerate(tours):
            self.tours_table.setItem(row, 0, QTableWidgetItem(str(tour['id'])))
            self.tours_table.setItem(row, 1, QTableWidgetItem(tour['tour_name']))
            self.tours_table.setItem(row, 2, QTableWidgetItem(tour['country']))
            self.tours_table.setItem(row, 3, QTableWidgetItem(tour.get('city', '')))
            self.tours_table.setItem(row, 4, QTableWidgetItem(tour['tour_operator']))
            self.tours_table.setItem(row, 5, QTableWidgetItem(tour.get('start_date', '')))
            self.tours_table.setItem(row, 6, QTableWidgetItem(tour.get('end_date', '')))
            self.tours_table.setItem(row, 7, QTableWidgetItem(f"{float(tour['price']):.2f} руб."))
            self.tours_table.setItem(row, 8, QTableWidgetItem(str(tour.get('available_seats', ''))))

    def create_booking_from_form(self):
        client_id = self.client_combo.currentData()
        tour_id = self.tour_combo.currentData()
        booking_date = self.booking_date.date().toString("yyyy-MM-dd")
        persons_count = self.persons_count.value()
        status = self.status_combo.currentText()
        notes = self.notes_text.toPlainText()
        total_price_text = self.total_price_input.text()

        if not client_id or not tour_id or not total_price_text:
            QMessageBox.warning(self, "Ошибка", "Заполните все обязательные поля")
            return

        try:
            total_price = float(total_price_text)
            booking_data = (client_id, tour_id, booking_date, persons_count, total_price, status, notes)

            booking_id, error = self.db.create_booking(booking_data)
            if booking_id:
                QMessageBox.information(self, "Успех", f"Заявка создана. ID: {booking_id}")
                self.show_all_bookings()
                self.clear_booking_form()
            else:
                QMessageBox.warning(self, "Ошибка", f"Не удалось создать заявку: {error}")
        except ValueError:
            QMessageBox.warning(self, "Ошибка", "Некорректная стоимость")
        except Error as e:
            print(f"Ошибка при создании заявки: {e}")
            QMessageBox.critical(self, "Ошибка", "Не удалось создать заявку")

    def delete_booking(self):
        if not self.current_editing_booking_id:
            QMessageBox.warning(self, "Ошибка", "Сначала выберите заявку из таблицы")
            return

        reply = QMessageBox.question(
            self, 'Подтверждение удаления',
            'Вы уверены, что хотите полностью удалить эту заявку?\n\n' +
            'Примечание: Места в туре будут возвращены.',
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )

        if reply == QMessageBox.StandardButton.Yes:
            try:
                # Используем метод полного удаления
                success, error = self.db.delete_booking(self.current_editing_booking_id)
                if success:
                    QMessageBox.information(self, "Успех", "Заявка успешно удалена из базы данных!")

                    # Обновляем таблицу
                    self.show_all_bookings()

                    # Очищаем форму
                    self.clear_booking_form()
                else:
                    QMessageBox.warning(self, "Ошибка", f"Не удалось удалить заявку: {error}")
            except Error as e:
                print(f"Ошибка при удалении заявки: {e}")
                QMessageBox.critical(self, "Ошибка", "Не удалось удалить заявку")

    def update_booking_from_form(self):
        if not self.current_editing_booking_id:
            QMessageBox.warning(self, "Ошибка", "Сначала выберите заявку из таблицы")
            return

        # Получаем новые данные из формы
        client_id = self.client_combo.currentData()
        tour_id = self.tour_combo.currentData()
        booking_date = self.booking_date.date().toString("yyyy-MM-dd")
        persons_count = self.persons_count.value()
        status = self.status_combo.currentText()
        notes = self.notes_text.toPlainText()  # Сохраняем примечания
        total_price_text = self.total_price_input.text()

        if not client_id or not tour_id or not total_price_text:
            QMessageBox.warning(self, "Ошибка", "Заполните все обязательные поля")
            return

        try:
            total_price = float(total_price_text)
            booking_data = (client_id, tour_id, booking_date, persons_count, total_price, status, notes)

            # Используем метод update_booking
            success, error = self.db.update_booking(self.current_editing_booking_id, booking_data)

            if success:
                QMessageBox.information(self, "Успех", "Заявка успешно обновлена!")
                self.show_all_bookings()
                self.clear_booking_form()
            else:
                QMessageBox.warning(self, "Ошибка", f"Не удалось обновить заявку: {error}")

        except ValueError:
            QMessageBox.warning(self, "Ошибка", "Некорректная стоимость")
        except Error as e:
            print(f"Ошибка при обновлении заявки: {e}")
            QMessageBox.critical(self, "Ошибка", "Не удалось обновить заявку")

    def on_booking_table_click(self):
        selected = self.bookings_table.currentRow()
        if selected < 0:
            return

        try:
            booking_id = int(self.bookings_table.item(selected, 0).text())
            client_name = self.bookings_table.item(selected, 1).text()
            tour_name = self.bookings_table.item(selected, 3).text()
            country = self.bookings_table.item(selected, 4).text()
            booking_date = self.bookings_table.item(selected, 5).text()
            persons_count = int(self.bookings_table.item(selected, 6).text())
            total_price = self.bookings_table.item(selected, 7).text().replace(" руб.", "")
            status = self.bookings_table.item(selected, 8).text()

            # Получаем полные данные заявки из базы для примечаний
            all_bookings = self.db.get_all_bookings()
            current_booking = None
            for booking in all_bookings:
                if booking['id'] == booking_id:
                    current_booking = booking
                    break

            # Сохраняем ID редактируемой заявки
            self.current_editing_booking_id = booking_id

            # Заполняем форму данными заявки

            # 1. Находим и выбираем клиента в комбобоксе
            client_selected = False
            for i in range(self.client_combo.count()):
                item_text = self.client_combo.itemText(i)
                if client_name in item_text:
                    self.client_combo.setCurrentIndex(i)
                    client_selected = True
                    break

            if not client_selected and self.client_combo.count() > 0:
                self.client_combo.setCurrentIndex(0)

            # 2. Находим и выбираем тур в комбобоксе
            tour_selected = False
            for i in range(self.tour_combo.count()):
                item_text = self.tour_combo.itemText(i)
                if tour_name in item_text:
                    self.tour_combo.setCurrentIndex(i)
                    tour_selected = True
                    break

            if not tour_selected and self.tour_combo.count() > 0:
                self.tour_combo.setCurrentIndex(0)

            # 3. Устанавливаем дату
            if booking_date:
                try:
                    self.booking_date.setDate(QDate.fromString(booking_date, 'yyyy-MM-dd'))
                except:
                    self.booking_date.setDate(QDate.currentDate())

            # 4. Устанавливаем количество человек
            self.persons_count.setValue(persons_count)

            # 5. Устанавливаем статус
            status_index = self.status_combo.findText(status)
            if status_index >= 0:
                self.status_combo.setCurrentIndex(status_index)
            else:
                self.status_combo.setCurrentIndex(0)

            # 6. Устанавливаем стоимость
            try:
                price_value = float(total_price)
                self.total_price_input.setText(f"{price_value:.2f}")
            except:
                self.total_price_input.setText("0.00")

            # 7. Устанавливаем примечания (если есть)
            if current_booking and current_booking.get('notes'):
                self.notes_text.setPlainText(current_booking['notes'])
            else:
                self.notes_text.clear()

            # Активируем кнопки редактирования и удаления
            self.new_booking_btn.setEnabled(False)
            self.update_booking_btn.setEnabled(True)
            self.delete_booking_btn.setEnabled(True)
            self.cancel_edit_btn.setEnabled(True)

            # Меняем заголовок группы
            self.booking_form_group.setTitle(f"Редактирование заявки #{booking_id}")

        except Exception as e:
            print(f"Ошибка при загрузке данных заявки: {e}")
            QMessageBox.warning(self, "Ошибка", f"Не удалось загрузить данные заявки: {str(e)}")

    def cancel_editing(self):
        """Отмена редактирования и возврат к созданию новой заявки"""
        self.clear_booking_form()

    def clear_booking_form(self):
        """Очистка формы и возврат к режиму создания новой заявки"""
        self.booking_date.setDate(QDate.currentDate())
        self.persons_count.setValue(1)
        self.status_combo.setCurrentIndex(0)
        self.notes_text.clear()
        self.total_price_input.clear()

        # Сбрасываем информацию о туре
        self.country_label.setText("")
        self.dates_label.setText("")
        self.duration_label.setText("")
        self.available_seats_label.setText("")

        # Сбрасываем режим редактирования
        self.current_editing_booking_id = None

        # Активируем кнопку создания, деактивируем остальные
        self.new_booking_btn.setEnabled(True)
        self.update_booking_btn.setEnabled(False)
        self.delete_booking_btn.setEnabled(False)
        self.cancel_edit_btn.setEnabled(False)

        # Возвращаем заголовок группы
        self.booking_form_group.setTitle("Создание новой заявки")

        # Сбрасываем комбобоксы к первому элементу
        if self.client_combo.count() > 0:
            self.client_combo.setCurrentIndex(0)
        if self.tour_combo.count() > 0:
            self.tour_combo.setCurrentIndex(0)

    def register_new_client(self):
        full_name = self.new_client_name.text().strip()
        phone = self.new_client_phone.text().strip()
        email = self.new_client_email.text().strip() or None
        birth_date = self.new_client_birth_date.date().toString("yyyy-MM-dd")
        username = self.new_client_username.text().strip()
        password = self.new_client_password.text()
        role = self.new_client_role.currentText()

        if not full_name or not phone or not username or not password:
            QMessageBox.warning(self, "Ошибка", "Заполните все обязательные поля")
            return

        try:
            user_data = (username, password, full_name, role, phone, email, birth_date)
            user_id = self.db.create_user(user_data)
            if user_id:
                QMessageBox.information(self, "Успех",
                                        f"Пользователь успешно зарегистрирован!\n\nЛогин: {username}\nПароль: {password}")
                self.load_clients()
                self.load_clients_for_combo()
                self.clear_client_form()
        except Error as e:
            print(f"Ошибка при регистрации пользователя: {e}")
            QMessageBox.critical(self, "Ошибка", "Не удалось зарегистрировать пользователя")

    def clear_client_form(self):
        self.new_client_name.clear()
        self.new_client_phone.clear()
        self.new_client_email.clear()
        self.new_client_birth_date.setDate(QDate(1990, 1, 1))
        self.new_client_username.clear()
        self.new_client_password.clear()
        self.new_client_role.setCurrentIndex(0)

    def add_new_tour(self):
        tour_name = self.new_tour_name.text().strip()
        description = self.new_tour_description.toPlainText().strip()
        country = self.new_tour_country.text().strip()
        city = self.new_tour_city.text().strip()
        tour_operator = self.new_tour_operator.text().strip()
        tour_type = self.new_tour_type.currentText()
        start_date = self.new_tour_start_date.date().toString("yyyy-MM-dd")
        end_date = self.new_tour_end_date.date().toString("yyyy-MM-dd")
        duration_days = self.new_tour_duration.value()
        price = self.new_tour_price.value()
        max_persons = self.new_tour_max_persons.value()

        if not tour_name or not country or not tour_operator:
            QMessageBox.warning(self, "Ошибка", "Заполните все обязательные поля")
            return

        try:
            tour_data = (tour_name, description, country, city, tour_operator,
                         tour_type, start_date, end_date, duration_days,
                         price, max_persons, max_persons)
            tour_id = self.db.create_tour(tour_data)
            if tour_id:
                QMessageBox.information(self, "Успех", f"Тур успешно добавлен! ID: {tour_id}")
                self.load_tours()
                self.load_tours_for_combo()
                self.load_countries_for_filter()
                self.clear_tour_form()
        except Error as e:
            print(f"Ошибка при добавлении тура: {e}")
            QMessageBox.critical(self, "Ошибка", "Не удалось добавить тур")

    def clear_tour_form(self):
        self.new_tour_name.clear()
        self.new_tour_description.clear()
        self.new_tour_country.clear()
        self.new_tour_city.clear()
        self.new_tour_operator.clear()
        self.new_tour_type.setCurrentIndex(0)
        self.new_tour_start_date.setDate(QDate.currentDate().addMonths(1))
        self.new_tour_end_date.setDate(QDate.currentDate().addMonths(1).addDays(7))
        self.new_tour_duration.setValue(7)
        self.new_tour_price.setValue(50000)
        self.new_tour_max_persons.setValue(20)