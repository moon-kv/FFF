from PyQt6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                             QLabel, QLineEdit, QPushButton, QMessageBox)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont


class AuthWindow(QMainWindow):
    def __init__(self, db, on_auth_success):
        super().__init__()
        self.db = db
        self.on_auth_success = on_auth_success

        self.setWindowTitle("Вход в систему")
        self.setFixedSize(300, 200)

        self.setup_ui()

    def setup_ui(self):
        # Центральный виджет
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        # Основной layout
        layout = QVBoxLayout(central_widget)

        # Заголовок
        title_label = QLabel("Больница")
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title_font = QFont()
        title_font.setBold(True)
        title_font.setPointSize(12)
        title_label.setFont(title_font)
        layout.addWidget(title_label)

        # Разделитель
        layout.addWidget(QLabel(""))

        # Поле логина
        login_layout = QHBoxLayout()
        login_label = QLabel("Логин:")
        self.username_input = QLineEdit()
        login_layout.addWidget(login_label)
        login_layout.addWidget(self.username_input)
        layout.addLayout(login_layout)

        # Поле пароля
        password_layout = QHBoxLayout()
        password_label = QLabel("Пароль:")
        self.password_input = QLineEdit()
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)
        password_layout.addWidget(password_label)
        password_layout.addWidget(self.password_input)
        layout.addLayout(password_layout)

        # Кнопка входа
        login_button = QPushButton("Войти")
        login_button.clicked.connect(self.login)
        layout.addWidget(login_button)

        # Добавляем растягивающийся элемент для выравнивания
        layout.addStretch()

    def login(self):
        username = self.username_input.text().strip()
        password = self.password_input.text().strip()

        if not username or not password:
            QMessageBox.warning(self, "Ошибка", "Введите логин и пароль")
            return

        user = self.db.authenticate_user(username, password)

        if user:
            self.hide()
            self.on_auth_success(user)
        else:
            QMessageBox.critical(self, "Ошибка", "Неверный логин или пароль")
            self.password_input.clear()
            self.password_input.setFocus()