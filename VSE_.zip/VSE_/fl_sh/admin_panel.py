from PyQt6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                             QTabWidget, QTableWidget, QTableWidgetItem, QPushButton,
                             QLabel, QLineEdit, QDateEdit, QComboBox, QTextEdit,
                             QGroupBox, QMessageBox, QHeaderView, QFormLayout,
                             QTimeEdit, QGridLayout, QSpinBox)
from PyQt6.QtCore import Qt, QDate, QTime
from PyQt6.QtGui import QColor
from pymysql import Error
from datetime import datetime


class AdminPanel(QMainWindow):
    def __init__(self, db, user):
        super().__init__()
        self.db = db
        self.user = user
        self.current_editing_order_id = None

        self.setWindowTitle(f"Панель администратора - {user['full_name']}")
        self.setGeometry(100, 100, 1400, 800)

        self.setup_ui()
        self.load_initial_data()

    def setup_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)

        self.tabs = QTabWidget()
        self.create_orders_tab()
        self.create_clients_tab()
        self.create_florists_tab()

        main_layout.addWidget(self.tabs)

    def create_orders_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        order_form_group = QGroupBox("Управление заказом")
        order_form_layout = QVBoxLayout()

        first_row = QHBoxLayout()
        first_row.addWidget(QLabel("Клиент:"))
        self.client_combo = QComboBox()
        self.client_combo.setMinimumWidth(300)
        first_row.addWidget(self.client_combo)

        first_row.addWidget(QLabel("Букет:"))
        self.bouquet_combo = QComboBox()
        self.bouquet_combo.setMinimumWidth(250)
        self.bouquet_combo.currentIndexChanged.connect(self.update_bouquet_info)
        first_row.addWidget(self.bouquet_combo)

        first_row.addStretch()
        order_form_layout.addLayout(first_row)

        second_row = QHBoxLayout()
        second_row.addWidget(QLabel("Флорист:"))
        self.florist_combo = QComboBox()
        self.florist_combo.setMinimumWidth(250)
        second_row.addWidget(self.florist_combo)

        second_row.addWidget(QLabel("Дата доставки:"))
        self.delivery_date = QDateEdit()
        self.delivery_date.setDate(QDate.currentDate().addDays(1))
        self.delivery_date.setCalendarPopup(True)
        self.delivery_date.setMinimumDate(QDate.currentDate())
        second_row.addWidget(self.delivery_date)

        second_row.addStretch()
        order_form_layout.addLayout(second_row)

        third_row = QHBoxLayout()
        third_row.addWidget(QLabel("Время доставки:"))
        self.delivery_time = QTimeEdit()
        self.delivery_time.setTime(QTime(14, 0))
        third_row.addWidget(self.delivery_time)

        third_row.addWidget(QLabel("Количество:"))
        self.quantity_spin = QSpinBox()
        self.quantity_spin.setMinimum(1)
        self.quantity_spin.setMaximum(100)
        self.quantity_spin.setValue(1)
        self.quantity_spin.valueChanged.connect(self.update_total_price_admin)
        third_row.addWidget(self.quantity_spin)

        third_row.addWidget(QLabel("Цена:"))
        self.price_input = QLineEdit()
        self.price_input.setReadOnly(True)
        self.price_input.setMaximumWidth(100)
        third_row.addWidget(self.price_input)

        third_row.addStretch()
        order_form_layout.addLayout(third_row)

        fourth_row = QHBoxLayout()
        fourth_row.addWidget(QLabel("Адрес доставки:"))
        self.delivery_address = QLineEdit()
        fourth_row.addWidget(self.delivery_address)
        order_form_layout.addLayout(fourth_row)

        fifth_row = QHBoxLayout()
        fifth_row.addWidget(QLabel("Статус заказа:"))
        self.status_combo = QComboBox()
        self.status_combo.addItems(['pending', 'processing', 'ready', 'delivered', 'cancelled'])
        fifth_row.addWidget(self.status_combo)

        fifth_row.addWidget(QLabel("Способ оплаты:"))
        self.payment_method_combo = QComboBox()
        self.payment_method_combo.addItems(['cash', 'card', 'online'])
        fifth_row.addWidget(self.payment_method_combo)

        fifth_row.addWidget(QLabel("Статус оплаты:"))
        self.payment_status_combo = QComboBox()
        self.payment_status_combo.addItems(['paid', 'unpaid', 'partially_paid'])
        fifth_row.addWidget(self.payment_status_combo)

        order_form_layout.addLayout(fifth_row)

        sixth_row = QHBoxLayout()
        sixth_row.addWidget(QLabel("Примечания:"))
        self.notes_text = QTextEdit()
        self.notes_text.setMaximumHeight(60)
        sixth_row.addWidget(self.notes_text)
        order_form_layout.addLayout(sixth_row)

        buttons_row = QHBoxLayout()
        self.new_order_btn = QPushButton("Создать заказ")
        self.new_order_btn.clicked.connect(self.create_order_from_form)
        buttons_row.addWidget(self.new_order_btn)

        self.update_order_btn = QPushButton("Обновить заказ")
        self.update_order_btn.clicked.connect(self.update_order_from_form)
        self.update_order_btn.setEnabled(False)
        buttons_row.addWidget(self.update_order_btn)

        self.delete_order_btn = QPushButton("Удалить заказ")
        self.delete_order_btn.clicked.connect(self.delete_order)
        self.delete_order_btn.setEnabled(False)
        buttons_row.addWidget(self.delete_order_btn)

        clear_btn = QPushButton("Очистить форму")
        clear_btn.clicked.connect(self.clear_order_form)
        buttons_row.addWidget(clear_btn)

        buttons_row.addStretch()
        order_form_layout.addLayout(buttons_row)

        order_form_group.setLayout(order_form_layout)
        layout.addWidget(order_form_group)

        filter_group = QGroupBox("Фильтр заказов")
        filter_layout = QVBoxLayout()

        date_filter_layout = QHBoxLayout()
        date_filter_layout.addWidget(QLabel("Период с:"))
        self.start_date_filter = QDateEdit()
        self.start_date_filter.setDate(QDate.currentDate().addDays(-7))
        self.start_date_filter.setCalendarPopup(True)
        date_filter_layout.addWidget(self.start_date_filter)

        date_filter_layout.addWidget(QLabel("по:"))
        self.end_date_filter = QDateEdit()
        self.end_date_filter.setDate(QDate.currentDate().addDays(30))
        self.end_date_filter.setCalendarPopup(True)
        date_filter_layout.addWidget(self.end_date_filter)

        filter_date_button = QPushButton("Фильтровать по дате")
        filter_date_button.clicked.connect(self.filter_orders_by_date)
        date_filter_layout.addWidget(filter_date_button)

        date_filter_layout.addStretch()
        filter_layout.addLayout(date_filter_layout)

        status_filter_layout = QHBoxLayout()
        status_filter_layout.addWidget(QLabel("Статус заказа:"))
        self.status_filter_combo = QComboBox()
        self.status_filter_combo.addItem("Все статусы", "")
        self.status_filter_combo.addItem("Ожидает", "pending")
        self.status_filter_combo.addItem("В работе", "processing")
        self.status_filter_combo.addItem("Готов", "ready")
        self.status_filter_combo.addItem("Доставлен", "delivered")
        self.status_filter_combo.addItem("Отменен", "cancelled")
        status_filter_layout.addWidget(self.status_filter_combo)

        filter_status_button = QPushButton("Фильтровать по статусу")
        filter_status_button.clicked.connect(self.filter_orders_by_status)
        status_filter_layout.addWidget(filter_status_button)

        show_all_button = QPushButton("Показать все заказы")
        show_all_button.clicked.connect(self.show_all_orders)
        status_filter_layout.addWidget(show_all_button)

        status_filter_layout.addStretch()
        filter_layout.addLayout(status_filter_layout)

        filter_group.setLayout(filter_layout)
        layout.addWidget(filter_group)

        self.orders_table = QTableWidget()
        self.orders_table.setColumnCount(11)
        self.orders_table.setHorizontalHeaderLabels([
            "ID", "Клиент", "Телефон", "Букет", "Флорист",
            "Дата заказа", "Дата доставки", "Время", "Кол-во", "Стоимость", "Статус"
        ])

        header = self.orders_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)

        self.orders_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.orders_table.clicked.connect(self.on_order_table_click)

        layout.addWidget(self.orders_table)

        self.tabs.addTab(tab, "Заказы")
        self.load_clients_for_combo()
        self.load_florists_for_combo()
        self.load_bouquets_for_combo()

    def create_clients_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        client_form_group = QGroupBox("Регистрация нового клиента")
        client_form_layout = QGridLayout()

        client_form_layout.addWidget(QLabel("ФИО:"), 0, 0)
        self.new_client_name = QLineEdit()
        client_form_layout.addWidget(self.new_client_name, 0, 1)

        client_form_layout.addWidget(QLabel("Телефон:"), 0, 2)
        self.new_client_phone = QLineEdit()
        client_form_layout.addWidget(self.new_client_phone, 0, 3)

        client_form_layout.addWidget(QLabel("Email:"), 1, 0)
        self.new_client_email = QLineEdit()
        client_form_layout.addWidget(self.new_client_email, 1, 1)

        client_form_layout.addWidget(QLabel("Адрес:"), 1, 2)
        self.new_client_address = QLineEdit()
        client_form_layout.addWidget(self.new_client_address, 1, 3)

        client_form_layout.addWidget(QLabel("Логин:"), 2, 0)
        self.new_client_username = QLineEdit()
        client_form_layout.addWidget(self.new_client_username, 2, 1)

        client_form_layout.addWidget(QLabel("Пароль:"), 2, 2)
        self.new_client_password = QLineEdit()
        client_form_layout.addWidget(self.new_client_password, 2, 3)

        client_form_layout.addWidget(QLabel("Примечания:"), 3, 0)
        self.new_client_notes = QTextEdit()
        self.new_client_notes.setMaximumHeight(50)
        client_form_layout.addWidget(self.new_client_notes, 3, 1, 1, 3)

        client_buttons_layout = QHBoxLayout()
        register_client_btn = QPushButton("Зарегистрировать клиента")
        register_client_btn.clicked.connect(self.register_new_client)
        client_buttons_layout.addWidget(register_client_btn)

        clear_client_btn = QPushButton("Очистить форму")
        clear_client_btn.clicked.connect(self.clear_client_form)
        client_buttons_layout.addWidget(clear_client_btn)

        client_buttons_layout.addStretch()
        client_form_layout.addLayout(client_buttons_layout, 4, 0, 1, 4)

        client_form_group.setLayout(client_form_layout)
        layout.addWidget(client_form_group)

        self.clients_table = QTableWidget()
        self.clients_table.setColumnCount(6)
        self.clients_table.setHorizontalHeaderLabels([
            "ID", "ФИО", "Телефон", "Email", "Адрес", "Дата регистрации"
        ])

        header = self.clients_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(4, QHeaderView.ResizeMode.Stretch)

        layout.addWidget(self.clients_table)

        self.tabs.addTab(tab, "Клиенты")

    def create_florists_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        florist_form_group = QGroupBox("Добавление нового флориста")
        florist_form_layout = QGridLayout()

        florist_form_layout.addWidget(QLabel("ФИО:"), 0, 0)
        self.new_florist_name = QLineEdit()
        florist_form_layout.addWidget(self.new_florist_name, 0, 1)

        florist_form_layout.addWidget(QLabel("Специализация:"), 0, 2)
        self.new_florist_specialization = QComboBox()
        self.new_florist_specialization.addItems([
            "Свадебные букеты", "Праздничные композиции", "Траурные букеты",
            "Экзотические цветы", "Комнатные растения", "Общая флористика"
        ])
        florist_form_layout.addWidget(self.new_florist_specialization, 0, 3)

        florist_form_layout.addWidget(QLabel("Телефон:"), 1, 0)
        self.new_florist_phone = QLineEdit()
        florist_form_layout.addWidget(self.new_florist_phone, 1, 1)

        florist_form_layout.addWidget(QLabel("Email:"), 1, 2)
        self.new_florist_email = QLineEdit()
        florist_form_layout.addWidget(self.new_florist_email, 1, 3)

        florist_form_layout.addWidget(QLabel("Опыт (лет):"), 2, 0)
        self.new_florist_experience = QLineEdit()
        florist_form_layout.addWidget(self.new_florist_experience, 2, 1)

        florist_form_layout.addWidget(QLabel("График работы:"), 2, 2)
        self.new_florist_schedule = QLineEdit()
        florist_form_layout.addWidget(self.new_florist_schedule, 2, 3)

        florist_form_layout.addWidget(QLabel("Логин:"), 3, 0)
        self.new_florist_username = QLineEdit()
        florist_form_layout.addWidget(self.new_florist_username, 3, 1)

        florist_form_layout.addWidget(QLabel("Пароль:"), 3, 2)
        self.new_florist_password = QLineEdit()
        florist_form_layout.addWidget(self.new_florist_password, 3, 3)

        florist_buttons_layout = QHBoxLayout()
        add_florist_btn = QPushButton("Добавить флориста")
        add_florist_btn.clicked.connect(self.add_new_florist)
        florist_buttons_layout.addWidget(add_florist_btn)

        clear_florist_btn = QPushButton("Очистить форму")
        clear_florist_btn.clicked.connect(self.clear_florist_form)
        florist_buttons_layout.addWidget(clear_florist_btn)

        florist_buttons_layout.addStretch()
        florist_form_layout.addLayout(florist_buttons_layout, 4, 0, 1, 4)

        florist_form_group.setLayout(florist_form_layout)
        layout.addWidget(florist_form_group)

        self.florists_table = QTableWidget()
        self.florists_table.setColumnCount(7)
        self.florists_table.setHorizontalHeaderLabels([
            "ID", "ФИО", "Специализация", "Телефон", "Email", "Опыт (лет)", "График работы"
        ])

        header = self.florists_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)

        layout.addWidget(self.florists_table)

        self.tabs.addTab(tab, "Флористы")

    def load_initial_data(self):
        self.show_all_orders()
        self.load_clients()
        self.load_florists()

    def register_new_client(self):
        full_name = self.new_client_name.text().strip()
        phone = self.new_client_phone.text().strip()
        email = self.new_client_email.text().strip() or None
        address = self.new_client_address.text().strip() or None
        username = self.new_client_username.text().strip()
        password = self.new_client_password.text()
        notes = self.new_client_notes.toPlainText().strip() or None

        if not full_name or not phone or not username or not password:
            QMessageBox.warning(self, "Ошибка", "Заполните все обязательные поля")
            return

        existing_user = self.db.get_user_by_username(username)
        if existing_user:
            QMessageBox.warning(self, "Ошибка", "Пользователь с таким логином уже существует")
            return

        try:
            user_data = (username, password, full_name, 'client', phone, email, True)
            user_id = self.db.create_user(user_data)

            if not user_id:
                raise Error("Не удалось создать пользователя")

            client_data = (user_id, full_name, phone, email, address,
                           datetime.now().strftime('%Y-%m-%d'), True, notes)
            client_id = self.db.create_client(client_data)

            if client_id:
                QMessageBox.information(self, "Успех",
                                        f"Клиент успешно зарегистрирован!\n"
                                        f"Логин: {username}\n"
                                        f"Пароль: {password}")

                self.load_clients()
                self.load_clients_for_combo()
                self.clear_client_form()

        except Error as e:
            print(f"Ошибка при регистрации клиента: {e}")
            QMessageBox.critical(self, "Ошибка", f"Не удалось зарегистрировать клиента")

    def clear_client_form(self):
        self.new_client_name.clear()
        self.new_client_phone.clear()
        self.new_client_email.clear()
        self.new_client_address.clear()
        self.new_client_username.clear()
        self.new_client_password.clear()
        self.new_client_notes.clear()

    def add_new_florist(self):
        full_name = self.new_florist_name.text().strip()
        specialization = self.new_florist_specialization.currentText()
        phone = self.new_florist_phone.text().strip()
        email = self.new_florist_email.text().strip() or None
        experience = self.new_florist_experience.text().strip()
        schedule = self.new_florist_schedule.text().strip()
        username = self.new_florist_username.text().strip()
        password = self.new_florist_password.text()

        if not full_name or not phone or not username or not password:
            QMessageBox.warning(self, "Ошибка", "Заполните все обязательные поля")
            return

        existing_user = self.db.get_user_by_username(username)
        if existing_user:
            QMessageBox.warning(self, "Ошибка", "Пользователь с таким логином уже существует")
            return

        try:
            try:
                experience_years = int(experience) if experience else 0
            except ValueError:
                experience_years = 0

            user_data = (username, password, full_name, 'florist', phone, email, True)
            user_id = self.db.create_user(user_data)

            if not user_id:
                raise Error("Не удалось создать пользователя")

            florist_data = (full_name, specialization, phone, email, experience_years, schedule, True)
            florist_id = self.db.create_florist(florist_data)

            if florist_id:
                QMessageBox.information(self, "Успех",
                                        f"Флорист успешно добавлен!\n"
                                        f"Логин: {username}\n"
                                        f"Пароль: {password}")

                self.load_florists()
                self.load_florists_for_combo()
                self.clear_florist_form()

        except Error as e:
            print(f"Ошибка при добавлении флориста: {e}")
            QMessageBox.critical(self, "Ошибка", f"Не удалось добавить флориста")

    def clear_florist_form(self):
        self.new_florist_name.clear()
        self.new_florist_specialization.setCurrentIndex(0)
        self.new_florist_phone.clear()
        self.new_florist_email.clear()
        self.new_florist_experience.clear()
        self.new_florist_schedule.clear()
        self.new_florist_username.clear()
        self.new_florist_password.clear()

    def load_clients_for_combo(self):
        try:
            clients = self.db.get_all_clients()
            self.client_combo.clear()
            for client in clients:
                self.client_combo.addItem(
                    f"{client['full_name']} (тел: {client.get('phone', '')})",
                    client['id']
                )
        except Error as e:
            print(f"Ошибка при загрузке клиентов для комбобокса: {e}")

    def load_florists_for_combo(self):
        try:
            florists = self.db.get_all_florists()
            self.florist_combo.clear()
            for florist in florists:
                self.florist_combo.addItem(
                    f"{florist['full_name']} ({florist['specialization']})",
                    florist['id']
                )
        except Error as e:
            print(f"Ошибка при загрузке флористов для комбобокса: {e}")

    def load_bouquets_for_combo(self):
        try:
            bouquets = self.db.get_all_bouquets()
            self.bouquet_combo.clear()
            for bouquet in bouquets:
                self.bouquet_combo.addItem(
                    f"{bouquet['name']} - {float(bouquet['price']):.2f} руб.",
                    (bouquet['id'], bouquet['price'])
                )
        except Error as e:
            print(f"Ошибка при загрузке букетов для комбобокса: {e}")

    def update_bouquet_info(self):
        current_data = self.bouquet_combo.currentData()
        if current_data:
            bouquet_id, price = current_data
            self.price_input.setText(f"{float(price):.2f}")
            self.update_total_price_admin()

    def update_total_price_admin(self):
        current_data = self.bouquet_combo.currentData()
        if current_data:
            bouquet_id, price = current_data
            quantity = self.quantity_spin.value()
            total = float(price) * quantity

    def show_all_orders(self):
        orders = self.db.get_all_orders()
        self.update_orders_table(orders)

    def filter_orders_by_date(self):
        start_date = self.start_date_filter.date().toString("yyyy-MM-dd")
        end_date = self.end_date_filter.date().toString("yyyy-MM-dd")

        orders = self.db.get_orders_by_period(start_date, end_date)
        self.update_orders_table(orders)

    def filter_orders_by_status(self):
        status = self.status_filter_combo.currentData()
        if not status:
            self.show_all_orders()
            return

        orders = self.db.get_orders_by_status(status)
        self.update_orders_table(orders)

    def update_orders_table(self, orders):
        self.orders_table.setRowCount(len(orders))

        status_names = {
            'pending': 'Ожидает',
            'processing': 'В работе',
            'ready': 'Готов',
            'delivered': 'Доставлен',
            'cancelled': 'Отменен'
        }

        for row, order in enumerate(orders):
            self.orders_table.setItem(row, 0, QTableWidgetItem(str(order.get('id', ''))))
            self.orders_table.setItem(row, 1, QTableWidgetItem(order.get('client_name', '')))
            self.orders_table.setItem(row, 2, QTableWidgetItem(order.get('client_phone', '')))
            self.orders_table.setItem(row, 3, QTableWidgetItem(order.get('bouquet_name', '')))
            self.orders_table.setItem(row, 4, QTableWidgetItem(order.get('florist_name', 'Не назначен')))
            self.orders_table.setItem(row, 5, QTableWidgetItem(str(order.get('order_date', ''))))
            self.orders_table.setItem(row, 6, QTableWidgetItem(str(order.get('delivery_date', ''))))
            self.orders_table.setItem(row, 7, QTableWidgetItem(str(order.get('delivery_time', ''))))
            self.orders_table.setItem(row, 8, QTableWidgetItem(str(order.get('quantity', ''))))
            self.orders_table.setItem(row, 9,
                                      QTableWidgetItem(f"{float(order.get('total_price', 0)):.2f} руб."))

            status_text = order.get('status', '')
            status_display = status_names.get(status_text, status_text)
            self.orders_table.setItem(row, 10, QTableWidgetItem(status_display))

    def load_clients(self):
        clients = self.db.get_all_clients()
        self.clients_table.setRowCount(len(clients))

        for row, client in enumerate(clients):
            self.clients_table.setItem(row, 0, QTableWidgetItem(str(client['id'])))
            self.clients_table.setItem(row, 1, QTableWidgetItem(client['full_name']))
            self.clients_table.setItem(row, 2, QTableWidgetItem(client.get('phone', '')))
            self.clients_table.setItem(row, 3, QTableWidgetItem(client.get('email', '')))
            self.clients_table.setItem(row, 4, QTableWidgetItem(client.get('address', '')))
            self.clients_table.setItem(row, 5, QTableWidgetItem(str(client.get('registration_date', ''))))

    def load_florists(self):
        florists = self.db.get_all_florists()
        self.florists_table.setRowCount(len(florists))

        for row, florist in enumerate(florists):
            self.florists_table.setItem(row, 0, QTableWidgetItem(str(florist['id'])))
            self.florists_table.setItem(row, 1, QTableWidgetItem(florist['full_name']))
            self.florists_table.setItem(row, 2, QTableWidgetItem(florist['specialization']))
            self.florists_table.setItem(row, 3, QTableWidgetItem(florist.get('phone', '')))
            self.florists_table.setItem(row, 4, QTableWidgetItem(florist.get('email', '')))
            self.florists_table.setItem(row, 5, QTableWidgetItem(str(florist.get('experience_years', ''))))
            self.florists_table.setItem(row, 6, QTableWidgetItem(florist.get('work_schedule', '')))

    def create_order_from_form(self):
        client_id = self.client_combo.currentData()
        bouquet_data = self.bouquet_combo.currentData()
        florist_id = self.florist_combo.currentData()

        if not client_id or not bouquet_data:
            QMessageBox.warning(self, "Ошибка", "Выберите клиента и букет")
            return

        bouquet_id, price = bouquet_data
        delivery_date = self.delivery_date.date().toString("yyyy-MM-dd")
        delivery_time = self.delivery_time.time().toString("HH:mm")
        delivery_address = self.delivery_address.text().strip()
        quantity = self.quantity_spin.value()
        status = self.status_combo.currentText()
        payment_method = self.payment_method_combo.currentText()
        payment_status = self.payment_status_combo.currentText()
        notes = self.notes_text.toPlainText()

        if not delivery_address:
            QMessageBox.warning(self, "Ошибка", "Введите адрес доставки")
            return

        total_price = float(price) * quantity

        order_data = (
            client_id, bouquet_id, florist_id,
            datetime.now().strftime('%Y-%m-%d'),
            delivery_date, delivery_time, delivery_address,
            quantity, total_price, status, payment_method, payment_status, notes
        )

        try:
            order_id = self.db.create_order(order_data)
            if order_id:
                QMessageBox.information(self, "Успех",
                                        f"Заказ создан успешно! Номер заказа: {order_id}")
                self.show_all_orders()
                self.clear_order_form()
        except Error as e:
            print(f"Ошибка при создании заказа: {e}")
            QMessageBox.critical(self, "Ошибка", "Не удалось создать заказ")

    def update_order_from_form(self):
        if not self.current_editing_order_id:
            QMessageBox.warning(self, "Ошибка", "Сначала выберите заказ из таблицы")
            return

        client_id = self.client_combo.currentData()
        bouquet_data = self.bouquet_combo.currentData()
        florist_id = self.florist_combo.currentData()

        if not client_id or not bouquet_data:
            QMessageBox.warning(self, "Ошибка", "Выберите клиента и букет")
            return

        bouquet_id, price = bouquet_data
        delivery_date = self.delivery_date.date().toString("yyyy-MM-dd")
        delivery_time = self.delivery_time.time().toString("HH:mm")
        delivery_address = self.delivery_address.text().strip()
        quantity = self.quantity_spin.value()
        status = self.status_combo.currentText()
        payment_method = self.payment_method_combo.currentText()
        payment_status = self.payment_status_combo.currentText()
        notes = self.notes_text.toPlainText()

        if not delivery_address:
            QMessageBox.warning(self, "Ошибка", "Введите адрес доставки")
            return

        total_price = float(price) * quantity

        update_data = (
            bouquet_id, florist_id,
            delivery_date, delivery_time, delivery_address,
            quantity, total_price, status, payment_method, payment_status, notes
        )

        try:
            success = self.db.update_order(self.current_editing_order_id, update_data)
            if success:
                QMessageBox.information(self, "Успех", "Заказ обновлен")
                self.show_all_orders()
                self.clear_order_form()
                self.current_editing_order_id = None
                self.new_order_btn.setEnabled(True)
                self.update_order_btn.setEnabled(False)
                self.delete_order_btn.setEnabled(False)
        except Error as e:
            print(f"Ошибка при обновлении заказа: {e}")
            QMessageBox.critical(self, "Ошибка", "Не удалось обновить заказ")

    def delete_order(self):
        if not self.current_editing_order_id:
            QMessageBox.warning(self, "Ошибка", "Сначала выберите заказ из таблицы")
            return

        reply = QMessageBox.question(
            self, 'Подтверждение',
            'Вы уверены, что хотите удалить этот заказ?',
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )

        if reply == QMessageBox.StandardButton.Yes:
            try:
                success = self.db.delete_order(self.current_editing_order_id)
                if success:
                    QMessageBox.information(self, "Успех", "Заказ удален")
                    self.show_all_orders()
                    self.clear_order_form()
                    self.current_editing_order_id = None
                    self.new_order_btn.setEnabled(True)
                    self.update_order_btn.setEnabled(False)
                    self.delete_order_btn.setEnabled(False)
            except Error as e:
                print(f"Ошибка при удалении заказа: {e}")
                QMessageBox.critical(self, "Ошибка", "Не удалось удалить заказ")

    def on_order_table_click(self):
        selected = self.orders_table.currentRow()
        if selected < 0:
            return

        order_id = int(self.orders_table.item(selected, 0).text())
        self.current_editing_order_id = order_id

        try:
            orders = self.db.get_all_orders()
            selected_order = None
            for order in orders:
                if order['id'] == order_id:
                    selected_order = order
                    break

            if selected_order:
                for i in range(self.client_combo.count()):
                    if self.client_combo.itemData(i) == selected_order['client_id']:
                        self.client_combo.setCurrentIndex(i)
                        break

                self.load_bouquets_for_combo()
                for i in range(self.bouquet_combo.count()):
                    data = self.bouquet_combo.itemData(i)
                    if data and data[0] == selected_order['bouquet_id']:
                        self.bouquet_combo.setCurrentIndex(i)
                        break

                florist_id = selected_order.get('florist_id')
                if florist_id:
                    for i in range(self.florist_combo.count()):
                        if self.florist_combo.itemData(i) == florist_id:
                            self.florist_combo.setCurrentIndex(i)
                            break
                else:
                    self.florist_combo.setCurrentIndex(0)

                if selected_order.get('delivery_date'):
                    self.delivery_date.setDate(
                        QDate.fromString(selected_order['delivery_date'], 'yyyy-MM-dd'))

                if selected_order.get('delivery_time'):
                    time_str = selected_order['delivery_time']
                    if ':' in time_str:
                        time_parts = time_str.split(':')
                        hours = int(time_parts[0])
                        minutes = int(time_parts[1]) if len(time_parts) > 1 else 0
                        self.delivery_time.setTime(QTime(hours, minutes))

                self.quantity_spin.setValue(selected_order.get('quantity', 1))
                self.delivery_address.setText(selected_order.get('delivery_address', ''))

                status_text = selected_order.get('status', 'pending')
                index = self.status_combo.findText(status_text)
                if index >= 0:
                    self.status_combo.setCurrentIndex(index)

                payment_method = selected_order.get('payment_method', 'cash')
                index = self.payment_method_combo.findText(payment_method)
                if index >= 0:
                    self.payment_method_combo.setCurrentIndex(index)

                payment_status = selected_order.get('payment_status', 'unpaid')
                index = self.payment_status_combo.findText(payment_status)
                if index >= 0:
                    self.payment_status_combo.setCurrentIndex(index)

                self.notes_text.setPlainText(selected_order.get('notes', ''))

                self.new_order_btn.setEnabled(False)
                self.update_order_btn.setEnabled(True)
                self.delete_order_btn.setEnabled(True)

        except Error as e:
            print(f"Ошибка при загрузке данных заказа: {e}")
            QMessageBox.critical(self, "Ошибка", "Не удалось загрузить данные заказа")

    def clear_order_form(self):
        self.delivery_date.setDate(QDate.currentDate().addDays(1))
        self.delivery_time.setTime(QTime(14, 0))
        self.quantity_spin.setValue(1)
        self.delivery_address.clear()
        self.notes_text.clear()
        self.price_input.clear()

        self.new_order_btn.setEnabled(True)
        self.update_order_btn.setEnabled(False)
        self.delete_order_btn.setEnabled(False)
        self.current_editing_order_id = None