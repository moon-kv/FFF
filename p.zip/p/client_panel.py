from PyQt6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                             QTabWidget, QTableWidget, QTableWidgetItem, QPushButton,
                             QLabel, QLineEdit, QDateEdit, QComboBox, QTextEdit,
                             QGroupBox, QMessageBox, QHeaderView, QDialog, QFormLayout,
                             QDialogButtonBox)
from PyQt6.QtCore import Qt, QDate
from PyQt6.QtGui import QFont
from pymysql import Error


class ClientPanel(QMainWindow):
    def __init__(self, db, user):
        super().__init__()
        self.db = db
        self.user = user
        self.guest = None

        self.setWindowTitle(f"Клиентский портал - {user['full_name']}")
        self.setGeometry(100, 100, 1200, 700)

        self.load_guest_data()
        self.setup_ui()

    def load_guest_data(self):
        try:
            with self.db.connection.cursor() as cursor:
                sql = "SELECT * FROM guests WHERE user_id = %s"
                cursor.execute(sql, (self.user['id'],))
                guest = cursor.fetchone()

                if guest:
                    # Конвертируем даты в строки для удобства
                    for date_field in ['birth_date', 'passport_issue_date', 'passport_expiry']:
                        if guest[date_field]:
                            guest[date_field] = guest[date_field].strftime('%Y-%m-%d')
                self.guest = guest
        except Error as e:
            print(f"Ошибка при получении гостя: {e}")
            self.guest = None

    def setup_ui(self):
        # Центральный виджет
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        # Основной layout
        main_layout = QVBoxLayout(central_widget)

        # Вкладки
        self.tabs = QTabWidget()

        # Создаем вкладки (оставляем только 2 вкладки)
        self.create_bookings_tab()
        self.create_rooms_tab()

        main_layout.addWidget(self.tabs)

    def create_bookings_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        # ФОРМА БРОНИРОВАНИЯ (вместо отдельного окна)
        booking_group = QGroupBox("Новое бронирование")
        booking_layout = QVBoxLayout()

        # Период
        period_layout = QHBoxLayout()
        period_layout.addWidget(QLabel("Дата заезда:"))
        self.client_start_date = QDateEdit()
        self.client_start_date.setDate(QDate.currentDate().addDays(1))
        self.client_start_date.setCalendarPopup(True)
        period_layout.addWidget(self.client_start_date)

        period_layout.addWidget(QLabel("Дата выезда:"))
        self.client_end_date = QDateEdit()
        self.client_end_date.setDate(QDate.currentDate().addDays(3))
        self.client_end_date.setCalendarPopup(True)
        period_layout.addWidget(self.client_end_date)

        period_layout.addStretch()
        booking_layout.addLayout(period_layout)

        # Дополнительная информация
        info_layout = QFormLayout()

        self.client_purpose_combo = QComboBox()
        self.client_purpose_combo.addItems(['Бизнес', 'Отдых', 'Лечение', 'Другое'])
        info_layout.addRow("Цель визита:", self.client_purpose_combo)

        self.client_claim_combo = QComboBox()
        self.client_claim_combo.addItems(['Низкий', 'Средний', 'Высокий'])
        info_layout.addRow("Уровень притязаний:", self.client_claim_combo)

        self.client_requests_text = QTextEdit()
        self.client_requests_text.setMaximumHeight(80)
        info_layout.addRow("Пожелания:", self.client_requests_text)

        # Выбор номера
        self.client_room_combo = QComboBox()
        info_layout.addRow("Выберите номер:", self.client_room_combo)

        # Обновляем список номеров при изменении дат
        self.client_start_date.dateChanged.connect(self.update_client_available_rooms)
        self.client_end_date.dateChanged.connect(self.update_client_available_rooms)

        booking_layout.addLayout(info_layout)

        # Кнопки
        button_layout = QHBoxLayout()

        new_booking_btn = QPushButton("Забронировать")
        new_booking_btn.clicked.connect(self.create_new_booking)
        button_layout.addWidget(new_booking_btn)

        button_layout.addStretch()
        booking_layout.addLayout(button_layout)
        booking_group.setLayout(booking_layout)

        # Статус текущих бронирований
        status_group = QGroupBox("Мои бронирования")
        status_layout = QVBoxLayout()

        self.bookings_table = QTableWidget()
        self.bookings_table.setColumnCount(7)
        self.bookings_table.setHorizontalHeaderLabels([
            "ID", "Номер", "Этаж", "Категория", "Заезд", "Выезд", "Статус"
        ])

        header = self.bookings_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)  # Категория

        status_layout.addWidget(self.bookings_table)
        status_group.setLayout(status_layout)

        layout.addWidget(booking_group)
        layout.addWidget(status_group)

        self.tabs.addTab(tab, "Бронирования")

        # Загружаем текущие бронирования
        self.update_booking_status()
        self.update_client_available_rooms()

    def create_rooms_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        # Поиск свободных номеров
        search_group = QGroupBox("Поиск свободных номеров")
        search_layout = QHBoxLayout()

        search_layout.addWidget(QLabel("Период с:"))
        self.room_search_start = QDateEdit()
        self.room_search_start.setDate(QDate.currentDate())
        self.room_search_start.setCalendarPopup(True)
        self.room_search_start.dateChanged.connect(self.search_available_rooms)
        search_layout.addWidget(self.room_search_start)

        search_layout.addWidget(QLabel("по:"))
        self.room_search_end = QDateEdit()
        self.room_search_end.setDate(QDate.currentDate().addDays(7))
        self.room_search_end.setCalendarPopup(True)
        self.room_search_end.dateChanged.connect(self.search_available_rooms)
        search_layout.addWidget(self.room_search_end)

        search_layout.addStretch()
        search_group.setLayout(search_layout)

        # Таблица доступных номеров
        self.available_rooms_table = QTableWidget()
        self.available_rooms_table.setColumnCount(5)
        self.available_rooms_table.setHorizontalHeaderLabels([
            "Номер", "Этаж", "Категория", "Мест", "Цена/ночь"
        ])

        header = self.available_rooms_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)  # Категория

        layout.addWidget(search_group)
        layout.addWidget(self.available_rooms_table)

        self.tabs.addTab(tab, "Поиск номеров")

        # Загружаем начальные данные
        self.search_available_rooms()

    def update_booking_status(self):
        if not self.guest:
            QMessageBox.warning(self, "Ошибка", "Профиль гостя не найден")
            return

        bookings = self.get_booking_status(self.guest['id'])
        self.bookings_table.setRowCount(len(bookings))

        for row, booking in enumerate(bookings):
            self.bookings_table.setItem(row, 0, QTableWidgetItem(str(booking.get('id', ''))))
            self.bookings_table.setItem(row, 1, QTableWidgetItem(booking.get('room_number', '')))
            self.bookings_table.setItem(row, 2, QTableWidgetItem(booking.get('floor', '')))
            self.bookings_table.setItem(row, 3, QTableWidgetItem(booking.get('category', '')))
            self.bookings_table.setItem(row, 4, QTableWidgetItem(booking.get('check_in_date', '')))
            self.bookings_table.setItem(row, 5, QTableWidgetItem(booking.get('check_out_date', '')))
            self.bookings_table.setItem(row, 6, QTableWidgetItem(booking.get('status', '')))

    def get_booking_status(self, guest_id):
        try:
            with self.db.connection.cursor() as cursor:
                sql = """
                SELECT b.*, r.room_number, r.category, r.floor
                FROM bookings b
                JOIN rooms r ON b.room_id = r.id
                WHERE b.guest_id = %s
                ORDER BY b.booking_date DESC
                """
                cursor.execute(sql, (guest_id,))
                bookings = cursor.fetchall()

                # Конвертируем даты в строки для удобства
                for booking in bookings:
                    for date_field in ['check_in_date', 'check_out_date', 'booking_date']:
                        if booking[date_field]:
                            booking[date_field] = booking[date_field].strftime('%Y-%m-%d')
                return bookings
        except Error as e:
            print(f"Ошибка при получении статуса бронирования: {e}")
            return []

    def update_client_available_rooms(self):
        start_date = self.client_start_date.date().toString("yyyy-MM-dd")
        end_date = self.client_end_date.date().toString("yyyy-MM-dd")

        available_rooms = self.get_available_rooms(start_date, end_date)

        self.client_room_combo.clear()
        for room in available_rooms:
            self.client_room_combo.addItem(
                f"{room['room_number']} ({room['floor']}) - {room['category']} - {float(room['price_per_night']):.2f} руб.",
                room['id']
            )

    def get_available_rooms(self, start_date, end_date):
        try:
            with self.db.connection.cursor() as cursor:
                sql = """
                SELECT r.* 
                FROM rooms r
                WHERE r.status = 'clean'
                AND r.id NOT IN (
                    SELECT room_id 
                    FROM bookings 
                    WHERE status IN ('reserved', 'checked_in')
                    AND (
                        (check_in_date <= %s AND (check_out_date IS NULL OR check_out_date >= %s))
                        OR (check_in_date BETWEEN %s AND %s)
                    )
                )
                ORDER BY r.floor, r.room_number
                """
                cursor.execute(sql, (end_date, start_date, start_date, end_date))
                return cursor.fetchall()
        except Error as e:
            print(f"Ошибка при получении доступных номеров: {e}")
            return []

    def create_new_booking(self):
        if not self.guest:
            QMessageBox.warning(self, "Ошибка", "Профиль гостя не найден")
            return

        start_date = self.client_start_date.date().toString("yyyy-MM-dd")
        end_date = self.client_end_date.date().toString("yyyy-MM-dd")
        room_id = self.client_room_combo.currentData()

        if not room_id:
            QMessageBox.warning(self, "Ошибка", "Выберите номер из списка")
            return

        # Проверяем доступность номера
        available_rooms = self.get_available_rooms(start_date, end_date)
        room_available = any(room['id'] == room_id for room in available_rooms)

        if not room_available:
            QMessageBox.warning(self, "Нет свободных номеров",
                                "Выбранный номер больше не доступен на указанные даты.")
            self.update_client_available_rooms()
            return

        # Подготавливаем данные для бронирования
        purpose = self.client_purpose_combo.currentText()

        # Конвертируем уровень притязаний
        claim_level_map = {
            'Низкий': 'low',
            'Средний': 'medium',
            'Высокий': 'high'
        }
        claim_level = claim_level_map.get(self.client_claim_combo.currentText(), 'medium')

        requests = self.client_requests_text.toPlainText()

        # Создаем бронирование
        booking_data = (
            self.guest['id'],
            room_id,
            start_date,
            end_date,
            purpose,
            claim_level,
            requests,
            'reserved'
        )

        try:
            with self.db.connection.cursor() as cursor:
                sql = """
                INSERT INTO bookings (
                    guest_id, room_id, check_in_date, check_out_date,
                    purpose_of_visit, claim_level, special_requests, status
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                """
                cursor.execute(sql, booking_data)
                self.db.connection.commit()
                booking_id = cursor.lastrowid

                QMessageBox.information(self, "Успех",
                                        f"Бронирование создано. Номер бронирования: {booking_id}")
                self.update_booking_status()
                self.clear_booking_form()
        except Error as e:
            print(f"Ошибка при создании бронирования: {e}")
            QMessageBox.critical(self, "Ошибка", "Не удалось создать бронирование")

    def clear_booking_form(self):
        self.client_start_date.setDate(QDate.currentDate().addDays(1))
        self.client_end_date.setDate(QDate.currentDate().addDays(3))
        self.client_purpose_combo.setCurrentIndex(0)
        self.client_claim_combo.setCurrentIndex(1)
        self.client_requests_text.clear()
        self.update_client_available_rooms()

    def search_available_rooms(self):
        start_date = self.room_search_start.date().toString("yyyy-MM-dd")
        end_date = self.room_search_end.date().toString("yyyy-MM-dd")

        available_rooms = self.get_available_rooms(start_date, end_date)
        self.available_rooms_table.setRowCount(len(available_rooms))

        for row, room in enumerate(available_rooms):
            self.available_rooms_table.setItem(row, 0, QTableWidgetItem(room['room_number']))
            self.available_rooms_table.setItem(row, 1, QTableWidgetItem(room['floor']))
            self.available_rooms_table.setItem(row, 2, QTableWidgetItem(room['category']))
            self.available_rooms_table.setItem(row, 3, QTableWidgetItem(str(room['beds_count'])))
            self.available_rooms_table.setItem(row, 4, QTableWidgetItem(f"{float(room['price_per_night']):.2f} руб."))