import pymysql
from pymysql import Error
from datetime import datetime, timedelta


class Database:
    def __init__(self):
        self.host = "localhost"
        self.user = "root"
        self.password = "dn260306"  # Измените на ваш пароль MySQL
        self.database = "travel_agency"
        self.charset = "utf8mb4"
        self.connection = None

    def connect(self):
        try:
            self.connection = pymysql.connect(
                host=self.host,
                user=self.user,
                password=self.password,
                database=self.database,
                charset=self.charset,
                cursorclass=pymysql.cursors.DictCursor
            )
            print("Успешное подключение к базе данных")
            return True
        except Error as e:
            print(f"Ошибка подключения к базе данных: {e}")
            return False

    def disconnect(self):
        if self.connection:
            self.connection.close()
            print("Отключение от базы данных")

    # Аутентификация пользователя
    def authenticate_user(self, username, password):
        try:
            with self.connection.cursor() as cursor:
                sql = "SELECT * FROM users WHERE username = %s AND password = %s AND is_active = TRUE"
                cursor.execute(sql, (username, password))
                user = cursor.fetchone()
                return user
        except Error as e:
            print(f"Ошибка аутентификации: {e}")
            return None

    # Методы для работы с пользователями
    def get_client_by_user_id(self, user_id):
        try:
            with self.connection.cursor() as cursor:
                sql = "SELECT * FROM users WHERE id = %s"
                cursor.execute(sql, (user_id,))
                user = cursor.fetchone()
                return user
        except Error as e:
            print(f"Ошибка при получении клиента: {e}")
            return None

    def get_all_users(self):
        try:
            with self.connection.cursor() as cursor:
                sql = "SELECT * FROM users ORDER BY role, full_name"
                cursor.execute(sql)
                users = cursor.fetchall()

                for user in users:
                    if user.get('birth_date'):
                        user['birth_date'] = user['birth_date'].strftime('%Y-%m-%d')
                    if user.get('registration_date'):
                        user['registration_date'] = user['registration_date'].strftime('%Y-%m-%d')
                return users
        except Error as e:
            print(f"Ошибка при получении пользователей: {e}")
            return []

    # Методы для работы с турами
    def get_all_tours(self):
        try:
            with self.connection.cursor() as cursor:
                sql = "SELECT * FROM tours WHERE is_active = TRUE ORDER BY start_date"
                cursor.execute(sql)
                tours = cursor.fetchall()

                for tour in tours:
                    if tour.get('start_date'):
                        tour['start_date'] = tour['start_date'].strftime('%Y-%m-%d')
                    if tour.get('end_date'):
                        tour['end_date'] = tour['end_date'].strftime('%Y-%m-%d')
                return tours
        except Error as e:
            print(f"Ошибка при получении туров: {e}")
            return []

    def get_tour_by_id(self, tour_id):
        try:
            with self.connection.cursor() as cursor:
                sql = "SELECT * FROM tours WHERE id = %s"
                cursor.execute(sql, (tour_id,))
                tour = cursor.fetchone()

                if tour:
                    if tour.get('start_date'):
                        tour['start_date'] = tour['start_date'].strftime('%Y-%m-%d')
                    if tour.get('end_date'):
                        tour['end_date'] = tour['end_date'].strftime('%Y-%m-%d')
                return tour
        except Error as e:
            print(f"Ошибка при получении тура: {e}")
            return None

    # Методы для работы с заявками (бронированиями)
    def get_client_bookings(self, user_id):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                SELECT b.*, 
                       t.tour_name,
                       t.country,
                       t.city,
                       t.start_date as tour_start,
                       t.end_date as tour_end,
                       t.price as tour_price,
                       t.tour_operator
                FROM bookings b
                JOIN tours t ON b.tour_id = t.id
                WHERE b.user_id = %s
                ORDER BY b.booking_date DESC
                """
                cursor.execute(sql, (user_id,))
                bookings = cursor.fetchall()

                for booking in bookings:
                    if booking.get('booking_date'):
                        booking['booking_date'] = booking['booking_date'].strftime('%Y-%m-%d')
                return bookings
        except Error as e:
            print(f"Ошибка при получении заявок клиента: {e}")
            return []

    def get_all_bookings(self):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                SELECT b.*, 
                       u.full_name as client_name,
                       u.phone as client_phone,
                       t.tour_name,
                       t.country,
                       t.city,
                       t.tour_operator
                FROM bookings b
                JOIN users u ON b.user_id = u.id
                JOIN tours t ON b.tour_id = t.id
                ORDER BY b.booking_date DESC, b.created_at DESC
                """
                cursor.execute(sql)
                bookings = cursor.fetchall()

                for booking in bookings:
                    if booking.get('booking_date'):
                        booking['booking_date'] = booking['booking_date'].strftime('%Y-%m-%d')
                return bookings
        except Error as e:
            print(f"Ошибка при получении всех заявок: {e}")
            return []

    # Фильтрация заявок
    def get_bookings_by_period(self, start_date, end_date):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                SELECT b.*, 
                       u.full_name as client_name,
                       u.phone as client_phone,
                       t.tour_name,
                       t.country,
                       t.city,
                       t.tour_operator
                FROM bookings b
                JOIN users u ON b.user_id = u.id
                JOIN tours t ON b.tour_id = t.id
                WHERE b.booking_date BETWEEN %s AND %s
                ORDER BY b.booking_date
                """
                cursor.execute(sql, (start_date, end_date))
                bookings = cursor.fetchall()

                for booking in bookings:
                    if booking.get('booking_date'):
                        booking['booking_date'] = booking['booking_date'].strftime('%Y-%m-%d')
                return bookings
        except Error as e:
            print(f"Ошибка при фильтрации заявок по дате: {e}")
            return []

    def get_bookings_by_country(self, country):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                SELECT b.*, 
                       u.full_name as client_name,
                       u.phone as client_phone,
                       t.tour_name,
                       t.country,
                       t.city,
                       t.tour_operator
                FROM bookings b
                JOIN users u ON b.user_id = u.id
                JOIN tours t ON b.tour_id = t.id
                WHERE t.country = %s
                ORDER BY b.booking_date DESC
                """
                cursor.execute(sql, (country,))
                bookings = cursor.fetchall()

                for booking in bookings:
                    if booking.get('booking_date'):
                        booking['booking_date'] = booking['booking_date'].strftime('%Y-%m-%d')
                return bookings
        except Error as e:
            print(f"Ошибка при фильтрации заявок по стране: {e}")
            return []

    # Создание новой заявки
    def create_booking(self, booking_data):
        try:
            with self.connection.cursor() as cursor:
                # Преобразуем persons_count в int
                persons_count = int(booking_data[3]) if isinstance(booking_data[3], str) else booking_data[3]

                # Проверяем доступность мест
                check_sql = "SELECT available_seats FROM tours WHERE id = %s"
                cursor.execute(check_sql, (booking_data[1],))
                tour = cursor.fetchone()

                if not tour:
                    return None, "Тур не найден"

                if tour['available_seats'] < persons_count:
                    return None, f"Недостаточно свободных мест. Доступно: {tour['available_seats']}"

                # Создаем заявку
                sql = """
                INSERT INTO bookings (
                    user_id, tour_id, booking_date, persons_count, 
                    total_price, status, notes
                ) VALUES (%s, %s, %s, %s, %s, %s, %s)
                """
                cursor.execute(sql, booking_data)
                booking_id = cursor.lastrowid

                # Обновляем количество свободных мест
                update_sql = "UPDATE tours SET available_seats = available_seats - %s WHERE id = %s"
                cursor.execute(update_sql, (persons_count, booking_data[1]))

                self.connection.commit()
                return booking_id, None
        except Error as e:
            print(f"Ошибка при создании заявки: {e}")
            return None, str(e)

    # Регистрация нового пользователя
    def create_user(self, user_data):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                INSERT INTO users (
                    username, password, full_name, role, phone, 
                    email, birth_date, registration_date, is_active
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, CURDATE(), TRUE)
                """
                cursor.execute(sql, user_data)
                user_id = cursor.lastrowid
                self.connection.commit()
                return user_id
        except Error as e:
            print(f"Ошибка при создании пользователя: {e}")
            return None

    # Добавление нового тура
    def create_tour(self, tour_data):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                INSERT INTO tours (
                    tour_name, description, country, city, tour_operator, 
                    tour_type, start_date, end_date, duration_days, 
                    price, max_persons, available_seats, is_active
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, TRUE)
                """
                cursor.execute(sql, tour_data)
                tour_id = cursor.lastrowid
                self.connection.commit()
                return tour_id
        except Error as e:
            print(f"Ошибка при создании тура: {e}")
            return None

    # Обновление статуса заявки
    def update_booking_status(self, booking_id, status):
        try:
            with self.connection.cursor() as cursor:
                # Если отменяем заявку, возвращаем места
                if status == 'cancelled':
                    # Получаем информацию о заявке
                    get_sql = "SELECT tour_id, persons_count FROM bookings WHERE id = %s"
                    cursor.execute(get_sql, (booking_id,))
                    booking = cursor.fetchone()

                    if booking:
                        # Возвращаем места
                        return_sql = "UPDATE tours SET available_seats = available_seats + %s WHERE id = %s"
                        cursor.execute(return_sql, (booking['persons_count'], booking['tour_id']))

                sql = "UPDATE bookings SET status = %s WHERE id = %s"
                cursor.execute(sql, (status, booking_id))
                self.connection.commit()
                return cursor.rowcount > 0
        except Error as e:
            print(f"Ошибка при обновлении статуса заявки: {e}")
            return False

    # Получение списка стран из туров
    def get_all_countries(self):
        try:
            with self.connection.cursor() as cursor:
                sql = "SELECT DISTINCT country FROM tours ORDER BY country"
                cursor.execute(sql)
                return [row['country'] for row in cursor.fetchall()]
        except Error as e:
            print(f"Ошибка при получении списка стран: {e}")
            return []

    def update_booking(self, booking_id, booking_data):
        """Обновление существующей заявки"""
        try:
            with self.connection.cursor() as cursor:
                # Получаем старую заявку
                get_sql = "SELECT * FROM bookings WHERE id = %s"
                cursor.execute(get_sql, (booking_id,))
                old_booking = cursor.fetchone()

                if not old_booking:
                    return False, "Заявка не найдена"

                old_tour_id = old_booking['tour_id']
                old_persons = old_booking['persons_count']
                old_status = old_booking['status']

                new_tour_id = booking_data[1]
                new_persons = booking_data[3]

                # Если изменился тур или количество человек
                if old_tour_id != new_tour_id or old_persons != new_persons:
                    # Возвращаем места из старого тура (если заявка была активна)
                    if old_status in ['pending', 'confirmed']:
                        return_sql = "UPDATE tours SET available_seats = available_seats + %s WHERE id = %s"
                        cursor.execute(return_sql, (old_persons, old_tour_id))

                    # Проверяем доступность мест в новом туре
                    check_sql = "SELECT available_seats FROM tours WHERE id = %s"
                    cursor.execute(check_sql, (new_tour_id,))
                    tour = cursor.fetchone()

                    if not tour:
                        return False, "Новый тур не найден"

                    if tour['available_seats'] < new_persons:
                        return False, f"Недостаточно свободных мест. Доступно: {tour['available_seats']}"

                    # Забираем места в новом туре (если новая заявка активна)
                    new_status = booking_data[5]
                    if new_status in ['pending', 'confirmed']:
                        take_sql = "UPDATE tours SET available_seats = available_seats - %s WHERE id = %s"
                        cursor.execute(take_sql, (new_persons, new_tour_id))

                # Обновляем заявку
                update_sql = """
                UPDATE bookings SET 
                    user_id = %s,
                    tour_id = %s,
                    booking_date = %s,
                    persons_count = %s,
                    total_price = %s,
                    status = %s,
                    notes = %s
                WHERE id = %s
                """
                cursor.execute(update_sql, (*booking_data, booking_id))

                self.connection.commit()
                return True, None

        except Error as e:
            print(f"Ошибка при обновлении заявки: {e}")
            return False, str(e)

    def get_booking_by_id(self, booking_id):
        """Получение заявки по ID"""
        try:
            with self.connection.cursor() as cursor:
                sql = """
                SELECT b.*, 
                       u.full_name as client_name,
                       u.phone as client_phone,
                       t.tour_name,
                       t.country,
                       t.city,
                       t.tour_operator,
                       t.price as tour_price
                FROM bookings b
                JOIN users u ON b.user_id = u.id
                JOIN tours t ON b.tour_id = t.id
                WHERE b.id = %s
                """
                cursor.execute(sql, (booking_id,))
                booking = cursor.fetchone()

                if booking and booking.get('booking_date'):
                    booking['booking_date'] = booking['booking_date'].strftime('%Y-%m-%d')
                return booking
        except Error as e:
            print(f"Ошибка при получении заявки: {e}")
            return None

    def delete_booking(self, booking_id):
        """Полное удаление заявки из базы данных"""
        try:
            with self.connection.cursor() as cursor:
                # Получаем информацию о заявке для возврата мест
                get_sql = "SELECT tour_id, persons_count, status FROM bookings WHERE id = %s"
                cursor.execute(get_sql, (booking_id,))
                booking = cursor.fetchone()

                if booking and booking['status'] != 'cancelled':
                    # Возвращаем места если заявка не была отменена
                    return_sql = "UPDATE tours SET available_seats = available_seats + %s WHERE id = %s"
                    cursor.execute(return_sql, (booking['persons_count'], booking['tour_id']))

                # Удаляем заявку
                delete_sql = "DELETE FROM bookings WHERE id = %s"
                cursor.execute(delete_sql, (booking_id,))

                self.connection.commit()
                return True, None
        except Error as e:
            print(f"Ошибка при удалении заявки: {e}")
            return False, str(e)