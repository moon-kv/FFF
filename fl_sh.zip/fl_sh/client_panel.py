from PyQt6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                             QTabWidget, QTableWidget, QTableWidgetItem, QPushButton,
                             QLabel, QLineEdit, QDateEdit, QComboBox, QTextEdit,
                             QGroupBox, QMessageBox, QHeaderView, QTimeEdit, QSpinBox,
                             QFrame)
from PyQt6.QtCore import Qt, QDate, QTime
from PyQt6.QtGui import QColor
from pymysql import Error


class ClientPanel(QMainWindow):
    def __init__(self, db, user):
        super().__init__()
        self.db = db
        self.user = user
        self.client = None

        self.setWindowTitle(f"Клиентский портал - {user['full_name']}")
        self.setGeometry(100, 100, 1200, 700)

        self.load_client_data()
        self.setup_ui()

    def load_client_data(self):
        self.client = self.db.get_client_by_user_id(self.user['id'])
        if not self.client:
            QMessageBox.warning(self, "Внимание", "Профиль клиента не найден")

    def setup_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)

        self.tabs = QTabWidget()
        self.create_new_order_tab()
        self.create_my_orders_tab()
        self.create_bouquets_tab()

        main_layout.addWidget(self.tabs)

    def create_new_order_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        # Основной контейнер с двумя колонками
        main_container = QHBoxLayout()

        # Левая колонка - форма заказа в GroupBox
        left_column = QVBoxLayout()

        order_group = QGroupBox("Новый заказ букета")

        order_form_layout = QVBoxLayout()

        # Выбор букета
        bouquet_layout = QHBoxLayout()
        bouquet_layout.addWidget(QLabel("Букет:"))
        self.bouquet_combo = QComboBox()
        self.bouquet_combo.setMinimumWidth(200)
        self.bouquet_combo.currentIndexChanged.connect(self.update_bouquet_info)
        bouquet_layout.addWidget(self.bouquet_combo)
        order_form_layout.addLayout(bouquet_layout)

        # Информация о букете
        info_frame = QFrame()
        info_frame.setFrameStyle(QFrame.Shape.StyledPanel)
        info_layout = QVBoxLayout(info_frame)

        info_layout.addWidget(QLabel("Описание:"))
        self.description_label = QLabel("")
        self.description_label.setWordWrap(True)
        info_layout.addWidget(self.description_label)

        info_layout.addWidget(QLabel("Состав:"))
        self.composition_label = QLabel("")
        self.composition_label.setWordWrap(True)
        info_layout.addWidget(self.composition_label)

        price_layout = QHBoxLayout()
        price_layout.addWidget(QLabel("Цена за шт:"))
        self.price_label = QLabel("0.00 руб.")
        price_layout.addWidget(self.price_label)
        price_layout.addStretch()
        info_layout.addLayout(price_layout)

        order_form_layout.addWidget(info_frame)

        # Дата и время доставки
        datetime_group = QGroupBox("Доставка")
        datetime_layout = QVBoxLayout()

        date_layout = QHBoxLayout()
        date_layout.addWidget(QLabel("Дата:"))
        self.delivery_date = QDateEdit()
        self.delivery_date.setDate(QDate.currentDate().addDays(1))
        self.delivery_date.setCalendarPopup(True)
        self.delivery_date.setMinimumDate(QDate.currentDate())
        date_layout.addWidget(self.delivery_date)
        date_layout.addStretch()
        datetime_layout.addLayout(date_layout)

        time_quantity_layout = QHBoxLayout()
        time_quantity_layout.addWidget(QLabel("Время:"))
        self.delivery_time = QTimeEdit()
        self.delivery_time.setTime(QTime(14, 0))
        time_quantity_layout.addWidget(self.delivery_time)

        time_quantity_layout.addWidget(QLabel("Количество:"))
        self.quantity_spin = QSpinBox()
        self.quantity_spin.setMinimum(1)
        self.quantity_spin.setMaximum(100)
        self.quantity_spin.setValue(1)
        self.quantity_spin.valueChanged.connect(self.update_total_price)
        time_quantity_layout.addWidget(self.quantity_spin)
        time_quantity_layout.addStretch()
        datetime_layout.addLayout(time_quantity_layout)

        datetime_group.setLayout(datetime_layout)
        order_form_layout.addWidget(datetime_group)

        # Адрес доставки
        address_group = QGroupBox("Адрес доставки")
        address_layout = QVBoxLayout()
        self.address_input = QLineEdit()
        if self.client and self.client.get('address'):
            self.address_input.setText(self.client['address'])
        address_layout.addWidget(self.address_input)
        address_group.setLayout(address_layout)
        order_form_layout.addWidget(address_group)

        # Способ оплаты и стоимость
        payment_group = QGroupBox("Оплата")
        payment_layout = QVBoxLayout()

        method_layout = QHBoxLayout()
        method_layout.addWidget(QLabel("Способ оплаты:"))
        self.payment_combo = QComboBox()
        self.payment_combo.addItems(['Наличными', 'Банковская карта', 'Онлайн оплата'])
        method_layout.addWidget(self.payment_combo)
        method_layout.addStretch()
        payment_layout.addLayout(method_layout)

        total_layout = QHBoxLayout()
        total_layout.addWidget(QLabel("Общая стоимость:"))
        self.total_price_label = QLabel("0.00 руб.")
        self.total_price_label.setStyleSheet("font-size: 14px; font-weight: bold;")
        total_layout.addWidget(self.total_price_label)
        total_layout.addStretch()
        payment_layout.addLayout(total_layout)

        payment_group.setLayout(payment_layout)
        order_form_layout.addWidget(payment_group)

        # Примечания
        notes_group = QGroupBox("Примечания")
        notes_layout = QVBoxLayout()
        self.notes_text = QTextEdit()
        self.notes_text.setMaximumHeight(60)
        notes_layout.addWidget(self.notes_text)
        notes_group.setLayout(notes_layout)
        order_form_layout.addWidget(notes_group)

        # Кнопки
        button_layout = QHBoxLayout()
        new_order_btn = QPushButton("Оформить заказ")
        new_order_btn.clicked.connect(self.create_new_order)
        button_layout.addWidget(new_order_btn)

        clear_btn = QPushButton("Очистить форму")
        clear_btn.clicked.connect(self.clear_order_form)
        button_layout.addWidget(clear_btn)

        button_layout.addStretch()
        order_form_layout.addLayout(button_layout)

        order_group.setLayout(order_form_layout)
        left_column.addWidget(order_group)
        left_column.addStretch()

        # Правая колонка - пустое пространство или будущие элементы
        right_column = QVBoxLayout()
        right_column.addStretch()

        main_container.addLayout(left_column)
        main_container.addLayout(right_column)

        layout.addLayout(main_container)

        self.tabs.addTab(tab, "Новый заказ")
        self.load_bouquets()

    def create_my_orders_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        self.client_orders_table = QTableWidget()
        self.client_orders_table.setColumnCount(9)
        self.client_orders_table.setHorizontalHeaderLabels([
            "ID", "Букет", "Дата заказа", "Дата доставки", "Время",
            "Адрес", "Кол-во", "Стоимость", "Статус"
        ])

        header = self.client_orders_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(5, QHeaderView.ResizeMode.Stretch)

        layout.addWidget(self.client_orders_table)
        self.tabs.addTab(tab, "Мои заказы")

        if self.client:
            self.load_client_orders()

    def create_bouquets_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        self.bouquets_table = QTableWidget()
        self.bouquets_table.setColumnCount(6)
        self.bouquets_table.setHorizontalHeaderLabels([
            "ID", "Название", "Описание", "Состав", "Категория", "Цена"
        ])

        header = self.bouquets_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)

        layout.addWidget(self.bouquets_table)
        self.tabs.addTab(tab, "Каталог букетов")

        self.load_bouquets_table()

    def load_bouquets(self):
        try:
            bouquets = self.db.get_all_bouquets()
            self.bouquet_combo.clear()
            for bouquet in bouquets:
                self.bouquet_combo.addItem(
                    f"{bouquet['name']} - {float(bouquet['price']):.2f} руб.",
                    (bouquet['id'], bouquet['price'], bouquet.get('description', ''), bouquet.get('composition', ''))
                )
        except Error as e:
            print(f"Ошибка при загрузке букетов: {e}")

    def load_bouquets_table(self):
        try:
            bouquets = self.db.get_all_bouquets()
            self.bouquets_table.setRowCount(len(bouquets))

            for row, bouquet in enumerate(bouquets):
                self.bouquets_table.setItem(row, 0, QTableWidgetItem(str(bouquet['id'])))
                self.bouquets_table.setItem(row, 1, QTableWidgetItem(bouquet['name']))
                self.bouquets_table.setItem(row, 2, QTableWidgetItem(bouquet.get('description', '')))
                self.bouquets_table.setItem(row, 3, QTableWidgetItem(bouquet.get('composition', '')))
                self.bouquets_table.setItem(row, 4, QTableWidgetItem(bouquet.get('category', '')))
                self.bouquets_table.setItem(row, 5,
                                            QTableWidgetItem(f"{float(bouquet['price']):.2f} руб."))
        except Error as e:
            print(f"Ошибка при загрузке букетов в таблицу: {e}")

    def update_bouquet_info(self):
        current_data = self.bouquet_combo.currentData()
        if current_data:
            bouquet_id, price, description, composition = current_data
            self.description_label.setText(description)
            self.composition_label.setText(composition)
            self.price_label.setText(f"{float(price):.2f} руб.")
            self.update_total_price()
        else:
            self.description_label.setText("")
            self.composition_label.setText("")
            self.price_label.setText("0.00 руб.")
            self.total_price_label.setText("0.00 руб.")

    def update_total_price(self):
        current_data = self.bouquet_combo.currentData()
        if current_data:
            bouquet_id, price, description, composition = current_data
            quantity = self.quantity_spin.value()
            total = float(price) * quantity
            self.total_price_label.setText(f"{total:.2f} руб.")
        else:
            self.total_price_label.setText("0.00 руб.")

    def create_new_order(self):
        if not self.client:
            QMessageBox.warning(self, "Ошибка", "Профиль клиента не найден")
            return

        bouquet_data = self.bouquet_combo.currentData()
        if not bouquet_data:
            QMessageBox.warning(self, "Ошибка", "Выберите букет")
            return

        bouquet_id, price, description, composition = bouquet_data
        delivery_date = self.delivery_date.date().toString("yyyy-MM-dd")
        delivery_time = self.delivery_time.time().toString("HH:mm")
        address = self.address_input.text().strip()
        quantity = self.quantity_spin.value()

        payment_text = self.payment_combo.currentText()
        payment_method_map = {
            'Наличными': 'cash',
            'Банковская карта': 'card',
            'Онлайн оплата': 'online'
        }
        payment_method = payment_method_map.get(payment_text, 'cash')

        notes = self.notes_text.toPlainText()

        if not address:
            QMessageBox.warning(self, "Ошибка", "Введите адрес доставки")
            return

        total_price = float(price) * quantity

        if QDate.fromString(delivery_date, "yyyy-MM-dd") <= QDate.currentDate():
            QMessageBox.warning(self, "Внимание", "Дата доставки должна быть не ранее завтрашнего дня")
            return

        order_data = (
            self.client['id'], bouquet_id, None,
            QDate.currentDate().toString("yyyy-MM-dd"),
            delivery_date, delivery_time, address,
            quantity, total_price, 'pending', payment_method, 'unpaid', notes
        )

        try:
            order_id = self.db.create_order(order_data)
            if order_id:
                QMessageBox.information(self, "Успех",
                                        f"Заказ успешно оформлен!\n\n"
                                        f"Номер заказа: {order_id}\n"
                                        f"Количество: {quantity}\n"
                                        f"Дата доставки: {delivery_date}\n"
                                        f"Время: {delivery_time}\n"
                                        f"Общая стоимость: {total_price:.2f} руб.")
                self.load_client_orders()
                self.clear_order_form()
        except Error as e:
            print(f"Ошибка при создании заказа: {e}")
            QMessageBox.critical(self, "Ошибка", "Не удалось создать заказ")

    def load_client_orders(self):
        if not self.client:
            return

        try:
            orders = self.db.get_client_orders(self.client['id'])
            self.client_orders_table.setRowCount(len(orders))

            status_names = {
                'pending': 'Ожидает',
                'processing': 'В работе',
                'ready': 'Готов',
                'delivered': 'Доставлен',
                'cancelled': 'Отменен'
            }

            for row, order in enumerate(orders):
                self.client_orders_table.setItem(row, 0, QTableWidgetItem(str(order.get('id', ''))))
                self.client_orders_table.setItem(row, 1, QTableWidgetItem(order.get('bouquet_name', '')))
                self.client_orders_table.setItem(row, 2, QTableWidgetItem(str(order.get('order_date', ''))))
                self.client_orders_table.setItem(row, 3, QTableWidgetItem(str(order.get('delivery_date', ''))))
                self.client_orders_table.setItem(row, 4, QTableWidgetItem(str(order.get('delivery_time', ''))))
                self.client_orders_table.setItem(row, 5, QTableWidgetItem(order.get('delivery_address', '')))
                self.client_orders_table.setItem(row, 6, QTableWidgetItem(str(order.get('quantity', ''))))
                self.client_orders_table.setItem(row, 7,
                                                 QTableWidgetItem(f"{float(order.get('total_price', 0)):.2f} руб."))

                status_text = order.get('status', '')
                status_display = status_names.get(status_text, status_text)
                self.client_orders_table.setItem(row, 8, QTableWidgetItem(status_display))

        except Error as e:
            print(f"Ошибка при загрузке заказов клиента: {e}")

    def clear_order_form(self):
        self.delivery_date.setDate(QDate.currentDate().addDays(1))
        self.delivery_time.setTime(QTime(14, 0))
        self.quantity_spin.setValue(1)
        self.notes_text.clear()
        self.total_price_label.setText("0.00 руб.")
        self.description_label.setText("")
        self.composition_label.setText("")
        self.price_label.setText("0.00 руб.")
        if self.client and self.client.get('address'):
            self.address_input.setText(self.client['address'])
        else:
            self.address_input.clear()