from PyQt6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                             QTabWidget, QTableWidget, QTableWidgetItem, QPushButton,
                             QLabel, QLineEdit, QDateEdit, QComboBox, QTextEdit,
                             QGroupBox, QMessageBox, QHeaderView, QFormLayout)
from PyQt6.QtCore import Qt, QDate
from PyQt6.QtGui import QFont, QColor
from pymysql import Error


class AdminPanel(QMainWindow):
    def __init__(self, db, user):
        super().__init__()
        self.db = db
        self.user = user
        self.current_editing_booking_id = None  # ID бронирования, которое редактируется

        self.setWindowTitle(f"Панель администратора - {user['full_name']}")
        self.setGeometry(100, 100, 1400, 800)

        self.setup_ui()
        self.load_initial_data()

    def setup_ui(self):
        # Центральный виджет
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        # Основной layout
        main_layout = QVBoxLayout(central_widget)

        # Вкладки
        self.tabs = QTabWidget()

        # Создаем вкладки
        self.create_bookings_tab()
        self.create_rooms_tab()
        self.create_guests_tab()

        main_layout.addWidget(self.tabs)

    def create_bookings_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        # ФОРМА БРОНИРОВАНИЯ (вместо отдельного окна)
        booking_form_group = QGroupBox("Форма бронирования")
        booking_form_layout = QVBoxLayout()

        # Первый ряд: Выбор гостя и номера
        first_row = QHBoxLayout()

        first_row.addWidget(QLabel("Гость:"))
        self.guest_combo = QComboBox()
        self.guest_combo.setMinimumWidth(300)
        first_row.addWidget(self.guest_combo)

        first_row.addWidget(QLabel("Номер:"))
        self.room_combo = QComboBox()
        self.room_combo.setMinimumWidth(200)
        first_row.addWidget(self.room_combo)

        first_row.addStretch()
        booking_form_layout.addLayout(first_row)

        # Второй ряд: Даты
        second_row = QHBoxLayout()

        second_row.addWidget(QLabel("Заезд:"))
        self.check_in_date = QDateEdit()
        self.check_in_date.setDate(QDate.currentDate())
        self.check_in_date.setCalendarPopup(True)
        self.check_in_date.dateChanged.connect(self.update_available_rooms_combo)
        second_row.addWidget(self.check_in_date)

        second_row.addWidget(QLabel("Выезд:"))
        self.check_out_date = QDateEdit()
        self.check_out_date.setDate(QDate.currentDate().addDays(1))
        self.check_out_date.setCalendarPopup(True)
        self.check_out_date.dateChanged.connect(self.update_available_rooms_combo)
        second_row.addWidget(self.check_out_date)

        second_row.addStretch()
        booking_form_layout.addLayout(second_row)

        # Третий ряд: Статус и цель
        third_row = QHBoxLayout()

        third_row.addWidget(QLabel("Статус:"))
        self.status_combo = QComboBox()
        self.status_combo.addItems(['reserved', 'checked_in', 'checked_out', 'cancelled'])
        third_row.addWidget(self.status_combo)

        third_row.addWidget(QLabel("Цель визита:"))
        self.purpose_combo = QComboBox()
        self.purpose_combo.addItems(['Бизнес', 'Отдых', 'Лечение', 'Другое'])
        third_row.addWidget(self.purpose_combo)

        third_row.addWidget(QLabel("Уровень притязаний:"))
        self.claim_combo = QComboBox()
        self.claim_combo.addItems(['low', 'medium', 'high'])
        third_row.addWidget(self.claim_combo)

        third_row.addStretch()
        booking_form_layout.addLayout(third_row)

        # Четвертый ряд: Пожелания
        fourth_row = QHBoxLayout()
        fourth_row.addWidget(QLabel("Пожелания:"))
        self.requests_text = QTextEdit()
        self.requests_text.setMaximumHeight(60)
        fourth_row.addWidget(self.requests_text)
        booking_form_layout.addLayout(fourth_row)

        # Кнопки управления формой бронирования
        booking_buttons_layout = QHBoxLayout()

        self.new_booking_btn = QPushButton("Создать бронирование")
        self.new_booking_btn.clicked.connect(self.create_booking_from_form)
        booking_buttons_layout.addWidget(self.new_booking_btn)

        self.update_booking_btn = QPushButton("Обновить бронирование")
        self.update_booking_btn.clicked.connect(self.update_booking_from_form)
        self.update_booking_btn.setEnabled(False)
        booking_buttons_layout.addWidget(self.update_booking_btn)

        booking_buttons_layout.addStretch()
        booking_form_layout.addLayout(booking_buttons_layout)

        booking_form_group.setLayout(booking_form_layout)
        layout.addWidget(booking_form_group)

        # Группа фильтров
        filter_group = QGroupBox("Фильтр бронирований")
        filter_layout = QVBoxLayout()

        # Первая строка фильтров: даты
        date_filter_layout = QHBoxLayout()
        date_filter_layout.addWidget(QLabel("Период с:"))
        self.start_date_filter = QDateEdit()
        self.start_date_filter.setDate(QDate.currentDate().addDays(-30))
        self.start_date_filter.setCalendarPopup(True)
        date_filter_layout.addWidget(self.start_date_filter)

        date_filter_layout.addWidget(QLabel("по:"))
        self.end_date_filter = QDateEdit()
        self.end_date_filter.setDate(QDate.currentDate().addDays(30))
        self.end_date_filter.setCalendarPopup(True)
        date_filter_layout.addWidget(self.end_date_filter)

        date_filter_layout.addStretch()
        filter_layout.addLayout(date_filter_layout)

        # Вторая строка фильтров: уровень притязаний
        claim_filter_layout = QHBoxLayout()
        claim_filter_layout.addWidget(QLabel("Уровень притязаний:"))

        self.claim_filter_combo = QComboBox()
        self.claim_filter_combo.addItem("Все уровни", "")
        self.claim_filter_combo.addItem("Низкий", "low")
        self.claim_filter_combo.addItem("Средний", "medium")
        self.claim_filter_combo.addItem("Высокий", "high")
        claim_filter_layout.addWidget(self.claim_filter_combo)

        claim_filter_button = QPushButton("Фильтровать по притязаниям")
        claim_filter_button.clicked.connect(self.filter_by_claim_level)
        claim_filter_layout.addWidget(claim_filter_button)

        claim_filter_layout.addStretch()
        filter_layout.addLayout(claim_filter_layout)

        # Кнопки общего фильтра
        filter_buttons_layout = QHBoxLayout()

        filter_button = QPushButton("Фильтровать по датам")
        filter_button.clicked.connect(self.filter_bookings)
        filter_buttons_layout.addWidget(filter_button)

        show_all_button = QPushButton("Показать все")
        show_all_button.clicked.connect(self.show_all_bookings)
        filter_buttons_layout.addWidget(show_all_button)

        filter_buttons_layout.addStretch()
        filter_layout.addLayout(filter_buttons_layout)

        filter_group.setLayout(filter_layout)
        layout.addWidget(filter_group)

        # Таблица бронирований
        self.bookings_table = QTableWidget()
        self.bookings_table.setColumnCount(11)  # Добавили колонку для уровня притязаний
        self.bookings_table.setHorizontalHeaderLabels([
            "ID", "Гость", "Паспорт", "Номер", "Этаж", "Категория",
            "Заезд", "Выезд", "Статус", "Цель визита", "Уровень притязаний"
        ])

        # Настройка таблицы
        header = self.bookings_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)  # Гость
        header.setSectionResizeMode(5, QHeaderView.ResizeMode.Stretch)  # Категория
        header.setSectionResizeMode(10, QHeaderView.ResizeMode.Stretch)  # Уровень притязаний

        self.bookings_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.bookings_table.clicked.connect(self.on_booking_table_click)

        layout.addWidget(self.bookings_table)

        self.tabs.addTab(tab, "Бронирования")

        # Загружаем данные для формы
        self.load_guests_for_combo()
        self.update_available_rooms_combo()

    def create_rooms_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        # Кнопки управления
        button_layout = QHBoxLayout()

        update_cleaning_btn = QPushButton("Обновить статус уборки")
        update_cleaning_btn.clicked.connect(self.update_cleaning_status)
        button_layout.addWidget(update_cleaning_btn)

        refresh_btn = QPushButton("Обновить список")
        refresh_btn.clicked.connect(self.load_rooms)
        button_layout.addWidget(refresh_btn)

        button_layout.addStretch()
        layout.addLayout(button_layout)

        # Таблица номеров
        self.rooms_table = QTableWidget()
        self.rooms_table.setColumnCount(6)
        self.rooms_table.setHorizontalHeaderLabels([
            "Номер", "Этаж", "Категория", "Мест", "Статус", "Цена/ночь"
        ])

        # Настройка таблицы
        header = self.rooms_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)  # Категория

        layout.addWidget(self.rooms_table)

        self.tabs.addTab(tab, "Номера")

    def create_guests_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        # Форма регистрации гостя (остается на месте)
        form_group = QGroupBox("Регистрация нового гостя")
        form_layout = QFormLayout()

        self.guest_passport = QLineEdit()
        self.guest_name = QLineEdit()
        self.guest_phone = QLineEdit()
        self.guest_email = QLineEdit()
        self.guest_birth_date = QDateEdit()
        self.guest_birth_date.setCalendarPopup(True)
        self.guest_birth_date.setDate(QDate(1990, 1, 1))
        self.guest_issued_by = QLineEdit()
        self.guest_issue_date = QDateEdit()
        self.guest_issue_date.setCalendarPopup(True)
        self.guest_issue_date.setDate(QDate.currentDate())
        self.guest_expiry_date = QDateEdit()
        self.guest_expiry_date.setCalendarPopup(True)
        self.guest_expiry_date.setDate(QDate.currentDate().addYears(10))

        form_layout.addRow("Паспорт:", self.guest_passport)
        form_layout.addRow("ФИО:", self.guest_name)
        form_layout.addRow("Телефон:", self.guest_phone)
        form_layout.addRow("Email:", self.guest_email)
        form_layout.addRow("Дата рождения:", self.guest_birth_date)
        form_layout.addRow("Кем выдан:", self.guest_issued_by)
        form_layout.addRow("Дата выдачи:", self.guest_issue_date)
        form_layout.addRow("Срок действия:", self.guest_expiry_date)

        register_btn = QPushButton("Зарегистрировать гостя")
        register_btn.clicked.connect(self.register_guest)
        form_layout.addRow("", register_btn)

        form_group.setLayout(form_layout)
        layout.addWidget(form_group)

        # Таблица гостей
        self.guests_table = QTableWidget()
        self.guests_table.setColumnCount(5)
        self.guests_table.setHorizontalHeaderLabels([
            "ID", "ФИО", "Паспорт", "Телефон", "Email"
        ])

        layout.addWidget(self.guests_table)

        self.tabs.addTab(tab, "Гости")

    def load_initial_data(self):
        self.show_all_bookings()
        self.load_rooms()
        self.load_guests()

    def show_all_bookings(self):
        bookings = self.get_all_bookings()
        self.update_bookings_table(bookings)

    def filter_bookings(self):
        start_date = self.start_date_filter.date().toString("yyyy-MM-dd")
        end_date = self.end_date_filter.date().toString("yyyy-MM-dd")

        bookings = self.get_bookings_by_period(start_date, end_date)
        self.update_bookings_table(bookings)

    def filter_by_claim_level(self):
        claim_level = self.claim_filter_combo.currentData()

        if not claim_level:
            # Если выбрано "Все уровни", показываем все бронирования
            self.show_all_bookings()
            return

        bookings = self.get_bookings_by_claim_level(claim_level)
        self.update_bookings_table(bookings)

    # МЕТОДЫ БАЗЫ ДАННЫХ (интегрированные)
    def get_bookings_by_period(self, start_date, end_date):
        try:
            with self.db.connection.cursor() as cursor:
                sql = """
                SELECT b.*, g.full_name, g.passport_number, r.room_number, r.category, r.floor
                FROM bookings b
                JOIN guests g ON b.guest_id = g.id
                JOIN rooms r ON b.room_id = r.id
                WHERE (b.check_in_date BETWEEN %s AND %s)
                   OR (b.check_out_date BETWEEN %s AND %s)
                   OR (b.check_in_date <= %s AND (b.check_out_date IS NULL OR b.check_out_date >= %s))
                ORDER BY b.check_in_date
                """
                cursor.execute(sql, (start_date, end_date, start_date, end_date, start_date, end_date))
                bookings = cursor.fetchall()

                # Конвертируем даты в строки для удобства
                for booking in bookings:
                    if booking['check_in_date']:
                        booking['check_in_date'] = booking['check_in_date'].strftime('%Y-%m-%d')
                    if booking['check_out_date']:
                        booking['check_out_date'] = booking['check_out_date'].strftime('%Y-%m-%d')
                return bookings
        except Error as e:
            print(f"Ошибка при получении бронирований: {e}")
            return []

    def get_bookings_by_claim_level(self, claim_level):
        try:
            with self.db.connection.cursor() as cursor:
                sql = """
                SELECT b.*, g.full_name, g.passport_number, r.room_number, r.category, r.floor
                FROM bookings b
                JOIN guests g ON b.guest_id = g.id
                JOIN rooms r ON b.room_id = r.id
                WHERE b.claim_level = %s
                ORDER BY b.check_in_date DESC
                """
                cursor.execute(sql, (claim_level,))
                bookings = cursor.fetchall()

                # Конвертируем даты в строки для удобства
                for booking in bookings:
                    if booking['check_in_date']:
                        booking['check_in_date'] = booking['check_in_date'].strftime('%Y-%m-%d')
                    if booking['check_out_date']:
                        booking['check_out_date'] = booking['check_out_date'].strftime('%Y-%m-%d')
                return bookings
        except Error as e:
            print(f"Ошибка при получении бронирований по уровню притязаний: {e}")
            return []

    def get_all_bookings(self):
        try:
            with self.db.connection.cursor() as cursor:
                sql = """
                SELECT b.*, g.full_name, g.passport_number, r.room_number, r.category, r.floor
                FROM bookings b
                JOIN guests g ON b.guest_id = g.id
                JOIN rooms r ON b.room_id = r.id
                ORDER BY b.check_in_date DESC
                """
                cursor.execute(sql)
                bookings = cursor.fetchall()

                # Конвертируем даты в строки для удобства
                for booking in bookings:
                    if booking['check_in_date']:
                        booking['check_in_date'] = booking['check_in_date'].strftime('%Y-%m-%d')
                    if booking['check_out_date']:
                        booking['check_out_date'] = booking['check_out_date'].strftime('%Y-%m-%d')
                return bookings
        except Error as e:
            print(f"Ошибка при получении всех бронирований: {e}")
            return []

    def update_bookings_table(self, bookings):
        self.bookings_table.setRowCount(len(bookings))

        for row, booking in enumerate(bookings):
            self.bookings_table.setItem(row, 0, QTableWidgetItem(str(booking.get('id', ''))))
            self.bookings_table.setItem(row, 1, QTableWidgetItem(booking.get('full_name', '')))
            self.bookings_table.setItem(row, 2, QTableWidgetItem(booking.get('passport_number', '')))
            self.bookings_table.setItem(row, 3, QTableWidgetItem(booking.get('room_number', '')))
            self.bookings_table.setItem(row, 4, QTableWidgetItem(booking.get('floor', '')))
            self.bookings_table.setItem(row, 5, QTableWidgetItem(booking.get('category', '')))
            self.bookings_table.setItem(row, 6, QTableWidgetItem(booking.get('check_in_date', '')))
            self.bookings_table.setItem(row, 7, QTableWidgetItem(booking.get('check_out_date', '')))
            self.bookings_table.setItem(row, 8, QTableWidgetItem(booking.get('status', '')))
            self.bookings_table.setItem(row, 9, QTableWidgetItem(booking.get('purpose_of_visit', '')))

            # Добавляем уровень притязаний в таблицу
            claim_level = booking.get('claim_level', '')
            # Преобразуем английские значения в русские для отображения
            claim_display = {
                'low': 'Низкий',
                'medium': 'Средний',
                'high': 'Высокий'
            }.get(claim_level, claim_level)

            self.bookings_table.setItem(row, 10, QTableWidgetItem(claim_display))

    def load_rooms(self):
        rooms = self.get_all_rooms()
        self.rooms_table.setRowCount(len(rooms))

        for row, room in enumerate(rooms):
            self.rooms_table.setItem(row, 0, QTableWidgetItem(room['room_number']))
            self.rooms_table.setItem(row, 1, QTableWidgetItem(room['floor']))
            self.rooms_table.setItem(row, 2, QTableWidgetItem(room['category']))
            self.rooms_table.setItem(row, 3, QTableWidgetItem(str(room['beds_count'])))

            status_item = QTableWidgetItem(room['status'])
            # Раскрашиваем статусы
            if room['status'] == 'cleaning_scheduled':
                status_item.setBackground(QColor(255, 255, 200))  # Желтый
            elif room['status'] == 'dirty':
                status_item.setBackground(QColor(255, 200, 200))  # Красный
            elif room['status'] == 'clean':
                status_item.setBackground(QColor(200, 255, 200))  # Зеленый

            self.rooms_table.setItem(row, 4, status_item)
            self.rooms_table.setItem(row, 5, QTableWidgetItem(f"{float(room['price_per_night']):.2f} руб."))

    def get_all_rooms(self):
        try:
            with self.db.connection.cursor() as cursor:
                sql = "SELECT * FROM rooms ORDER BY floor, room_number"
                cursor.execute(sql)
                return cursor.fetchall()
        except Error as e:
            print(f"Ошибка при получении номеров: {e}")
            return []

    def get_available_rooms(self, start_date, end_date):
        try:
            with self.db.connection.cursor() as cursor:
                sql = """
                SELECT r.* 
                FROM rooms r
                WHERE r.status = 'clean'
                AND r.id NOT IN (
                    SELECT room_id 
                    FROM bookings 
                    WHERE status IN ('reserved', 'checked_in')
                    AND (
                        (check_in_date <= %s AND (check_out_date IS NULL OR check_out_date >= %s))
                        OR (check_in_date BETWEEN %s AND %s)
                    )
                )
                ORDER BY r.floor, r.room_number
                """
                cursor.execute(sql, (end_date, start_date, start_date, end_date))
                return cursor.fetchall()
        except Error as e:
            print(f"Ошибка при получении доступных номеров: {e}")
            return []

    def load_guests(self):
        guests = self.get_all_guests()
        self.guests_table.setRowCount(len(guests))

        for row, guest in enumerate(guests):
            self.guests_table.setItem(row, 0, QTableWidgetItem(str(guest['id'])))
            self.guests_table.setItem(row, 1, QTableWidgetItem(guest['full_name']))
            self.guests_table.setItem(row, 2, QTableWidgetItem(guest.get('passport_number', '')))
            self.guests_table.setItem(row, 3, QTableWidgetItem(guest.get('phone', '')))
            self.guests_table.setItem(row, 4, QTableWidgetItem(guest.get('email', '')))

    def get_all_guests(self):
        try:
            with self.db.connection.cursor() as cursor:
                sql = "SELECT * FROM guests ORDER BY full_name"
                cursor.execute(sql)
                guests = cursor.fetchall()

                # Конвертируем даты в строки для удобства
                for guest in guests:
                    for date_field in ['birth_date', 'passport_issue_date', 'passport_expiry']:
                        if guest[date_field]:
                            guest[date_field] = guest[date_field].strftime('%Y-%m-%d')
                return guests
        except Error as e:
            print(f"Ошибка при получении гостей: {e}")
            return []

    def load_guests_for_combo(self):
        try:
            with self.db.connection.cursor() as cursor:
                sql = "SELECT id, full_name, passport_number FROM guests ORDER BY full_name"
                cursor.execute(sql)
                guests = cursor.fetchall()

                self.guest_combo.clear()
                for guest in guests:
                    self.guest_combo.addItem(
                        f"{guest['full_name']} (паспорт: {guest.get('passport_number', '')})",
                        guest['id']
                    )
        except Error as e:
            print(f"Ошибка при загрузке гостей для комбобокса: {e}")

    def update_cleaning_status(self):
        try:
            with self.db.connection.cursor() as cursor:
                sql = "UPDATE rooms SET status = 'clean' WHERE status = 'cleaning_scheduled'"
                cursor.execute(sql)
                self.db.connection.commit()
                count = cursor.rowcount
                QMessageBox.information(self, "Успех", f"Обновлено {count} номеров со статусом 'Назначен к уборке'")
                self.load_rooms()
        except Error as e:
            print(f"Ошибка при обновлении статуса уборки: {e}")
            QMessageBox.critical(self, "Ошибка", "Не удалось обновить статус уборки")

    def update_available_rooms_combo(self):
        start_date = self.check_in_date.date().toString("yyyy-MM-dd")
        end_date = self.check_out_date.date().toString("yyyy-MM-dd")

        available_rooms = self.get_available_rooms(start_date, end_date)

        self.room_combo.clear()
        for room in available_rooms:
            self.room_combo.addItem(
                f"{room['room_number']} ({room['floor']}) - {room['category']} - {float(room['price_per_night']):.2f} руб.",
                room['id']
            )

    def create_booking_from_form(self):
        guest_id = self.guest_combo.currentData()
        room_id = self.room_combo.currentData()
        check_in = self.check_in_date.date().toString("yyyy-MM-dd")
        check_out = self.check_out_date.date().toString("yyyy-MM-dd")
        status = self.status_combo.currentText()
        purpose = self.purpose_combo.currentText()
        claim_level = self.claim_combo.currentText()
        requests = self.requests_text.toPlainText()

        if not guest_id or not room_id:
            QMessageBox.warning(self, "Ошибка", "Выберите гостя и номер")
            return

        booking_data = (guest_id, room_id, check_in, check_out, purpose, claim_level, requests, status)

        try:
            with self.db.connection.cursor() as cursor:
                sql = """
                INSERT INTO bookings (
                    guest_id, room_id, check_in_date, check_out_date,
                    purpose_of_visit, claim_level, special_requests, status
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                """
                cursor.execute(sql, booking_data)
                self.db.connection.commit()

                QMessageBox.information(self, "Успех", "Бронирование создано")
                self.show_all_bookings()
                self.clear_booking_form()
                # Сбрасываем режим редактирования
                self.current_editing_booking_id = None
                self.new_booking_btn.setEnabled(True)
                self.update_booking_btn.setEnabled(False)
        except Error as e:
            print(f"Ошибка при создании бронирования: {e}")
            QMessageBox.critical(self, "Ошибка", "Не удалось создать бронирование")

    def update_booking_from_form(self):
        if not self.current_editing_booking_id:
            QMessageBox.warning(self, "Ошибка", "Сначала выберите бронирование из таблицы для редактирования")
            return

        guest_id = self.guest_combo.currentData()
        room_id = self.room_combo.currentData()
        check_in = self.check_in_date.date().toString("yyyy-MM-dd")
        check_out = self.check_out_date.date().toString("yyyy-MM-dd")
        status = self.status_combo.currentText()
        purpose = self.purpose_combo.currentText()
        claim_level = self.claim_combo.currentText()
        requests = self.requests_text.toPlainText()

        if not guest_id or not room_id:
            QMessageBox.warning(self, "Ошибка", "Выберите гостя и номер")
            return

        booking_data = (
            room_id, check_in, check_out, purpose, claim_level, requests, status, self.current_editing_booking_id)

        try:
            with self.db.connection.cursor() as cursor:
                sql = """
                UPDATE bookings SET 
                    room_id = %s,
                    check_in_date = %s,
                    check_out_date = %s,
                    purpose_of_visit = %s,
                    claim_level = %s,
                    special_requests = %s,
                    status = %s
                WHERE id = %s
                """
                cursor.execute(sql, booking_data)
                self.db.connection.commit()

                QMessageBox.information(self, "Успех", "Бронирование обновлено")
                self.show_all_bookings()
                self.clear_booking_form()
                # Сбрасываем режим редактирования
                self.current_editing_booking_id = None
                self.new_booking_btn.setEnabled(True)
                self.update_booking_btn.setEnabled(False)
        except Error as e:
            print(f"Ошибка при обновлении бронирования: {e}")
            QMessageBox.critical(self, "Ошибка", "Не удалось обновлить бронирование")

    def on_booking_table_click(self):
        selected = self.bookings_table.currentRow()
        if selected < 0:
            return

        booking_id = int(self.bookings_table.item(selected, 0).text())
        self.current_editing_booking_id = booking_id

        # Получаем данные выбранного бронирования
        try:
            with self.db.connection.cursor() as cursor:
                sql = """
                SELECT b.*, g.full_name, g.passport_number, r.room_number
                FROM bookings b
                JOIN guests g ON b.guest_id = g.id
                JOIN rooms r ON b.room_id = r.id
                WHERE b.id = %s
                """
                cursor.execute(sql, (booking_id,))
                booking = cursor.fetchone()

                if booking:
                    # Заполняем форму данными бронирования
                    # Находим гостя в комбобоксе
                    for i in range(self.guest_combo.count()):
                        if self.guest_combo.itemData(i) == booking['guest_id']:
                            self.guest_combo.setCurrentIndex(i)
                            break

                    # Устанавливаем даты
                    if booking['check_in_date']:
                        self.check_in_date.setDate(
                            QDate.fromString(booking['check_in_date'].strftime('%Y-%m-%d'), 'yyyy-MM-dd'))
                    if booking['check_out_date']:
                        self.check_out_date.setDate(
                            QDate.fromString(booking['check_out_date'].strftime('%Y-%m-%d'), 'yyyy-MM-dd'))

                    # Обновляем список комнат и выбираем текущую
                    self.update_available_rooms_combo()
                    for i in range(self.room_combo.count()):
                        if self.room_combo.itemData(i) == booking['room_id']:
                            self.room_combo.setCurrentIndex(i)
                            break

                    # Устанавливаем статус
                    status_text = booking['status']
                    index = self.status_combo.findText(status_text)
                    if index >= 0:
                        self.status_combo.setCurrentIndex(index)

                    # Устанавливаем цель визита
                    purpose_text = booking['purpose_of_visit']
                    index = self.purpose_combo.findText(purpose_text)
                    if index >= 0:
                        self.purpose_combo.setCurrentIndex(index)

                    # Устанавливаем уровень притязаний
                    claim_text = booking['claim_level']
                    index = self.claim_combo.findText(claim_text)
                    if index >= 0:
                        self.claim_combo.setCurrentIndex(index)

                    # Устанавливаем пожелания
                    self.requests_text.setPlainText(booking.get('special_requests', ''))

                    # Активируем кнопку обновления
                    self.new_booking_btn.setEnabled(False)
                    self.update_booking_btn.setEnabled(True)

        except Error as e:
            print(f"Ошибка при загрузке данных бронирования: {e}")
            QMessageBox.critical(self, "Ошибка", "Не удалось загрузить данные бронирования")

    def clear_booking_form(self):
        self.check_in_date.setDate(QDate.currentDate())
        self.check_out_date.setDate(QDate.currentDate().addDays(1))
        self.status_combo.setCurrentIndex(0)
        self.purpose_combo.setCurrentIndex(0)
        self.claim_combo.setCurrentIndex(1)
        self.requests_text.clear()
        self.update_available_rooms_combo()

    def register_guest(self):
        passport = self.guest_passport.text().strip()
        name = self.guest_name.text().strip()
        phone = self.guest_phone.text().strip()
        email = self.guest_email.text().strip()
        birth_date = self.guest_birth_date.date().toString("yyyy-MM-dd")
        issued_by = self.guest_issued_by.text().strip()
        issue_date = self.guest_issue_date.date().toString("yyyy-MM-dd")
        expiry_date = self.guest_expiry_date.date().toString("yyyy-MM-dd")

        if not passport or not name:
            QMessageBox.warning(self, "Ошибка", "Заполните обязательные поля: Паспорт и ФИО")
            return

        guest_data = (passport, name, phone, email, birth_date, issued_by, issue_date, expiry_date)

        try:
            with self.db.connection.cursor() as cursor:
                sql = """
                INSERT INTO guests (
                    passport_number, full_name, phone, email, birth_date,
                    passport_issued_by, passport_issue_date, passport_expiry
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                """
                cursor.execute(sql, guest_data)
                self.db.connection.commit()
                guest_id = cursor.lastrowid

                QMessageBox.information(self, "Успех", f"Гость зарегистрирован. ID: {guest_id}")
                self.load_guests()
                self.load_guests_for_combo()
                self.clear_guest_form()
        except Error as e:
            print(f"Ошибка при добавлении гостя: {e}")
            QMessageBox.critical(self, "Ошибка", "Не удалось зарегистрировать гостя")

    def clear_guest_form(self):
        self.guest_passport.clear()
        self.guest_name.clear()
        self.guest_phone.clear()
        self.guest_email.clear()
        self.guest_birth_date.setDate(QDate(1990, 1, 1))
        self.guest_issued_by.clear()
        self.guest_issue_date.setDate(QDate.currentDate())
        self.guest_expiry_date.setDate(QDate.currentDate().addYears(10))