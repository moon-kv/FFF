from PyQt6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                             QTabWidget, QTableWidget, QTableWidgetItem, QPushButton,
                             QLabel, QLineEdit, QDateEdit, QComboBox, QTextEdit,
                             QGroupBox, QMessageBox, QHeaderView, QSpinBox, QGridLayout)
from PyQt6.QtCore import Qt, QDate
from PyQt6.QtGui import QFont, QColor
from pymysql import Error


class ClientPanel(QMainWindow):
    def __init__(self, db, user):
        super().__init__()
        self.db = db
        self.user = user

        self.setWindowTitle(f"Клиентский портал - {user['full_name']}")
        self.setGeometry(100, 100, 1200, 700)

        self.setup_ui()
        self.load_initial_data()

    def setup_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        self.tabs = QTabWidget()
        self.create_book_tour_tab()
        self.create_my_bookings_tab()
        self.create_tours_tab()
        main_layout.addWidget(self.tabs)

    def create_book_tour_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        # ФОРМА БРОНИРОВАНИЯ ТУРА
        booking_group = QGroupBox("Бронирование тура")
        booking_layout = QVBoxLayout()

        # Выбор тура
        tour_selection_layout = QHBoxLayout()
        tour_selection_layout.addWidget(QLabel("Выберите тур:"))
        self.client_tour_combo = QComboBox()
        self.client_tour_combo.setMinimumWidth(400)
        self.client_tour_combo.currentIndexChanged.connect(self.update_client_tour_info)
        tour_selection_layout.addWidget(self.client_tour_combo)
        tour_selection_layout.addStretch()
        booking_layout.addLayout(tour_selection_layout)

        # Информация о туре - используем QLineEdit для полей, которые не должны изменяться
        info_layout = QGridLayout()

        # Страна - QLineEdit только для чтения
        info_layout.addWidget(QLabel("Страна:"), 0, 0)
        self.client_country_input = QLineEdit()
        self.client_country_input.setReadOnly(True)
        self.client_country_input.setMinimumWidth(150)
        self.client_country_input.setStyleSheet("background-color: #f0f0f0;")
        info_layout.addWidget(self.client_country_input, 0, 1)

        # Город - QLineEdit только для чтения
        info_layout.addWidget(QLabel("Город:"), 0, 2)
        self.client_city_input = QLineEdit()
        self.client_city_input.setReadOnly(True)
        self.client_city_input.setMinimumWidth(150)
        self.client_city_input.setStyleSheet("background-color: #f0f0f0;")
        info_layout.addWidget(self.client_city_input, 0, 3)

        # Туроператор - QLineEdit только для чтения
        info_layout.addWidget(QLabel("Туроператор:"), 1, 0)
        self.client_operator_input = QLineEdit()
        self.client_operator_input.setReadOnly(True)
        self.client_operator_input.setMinimumWidth(150)
        self.client_operator_input.setStyleSheet("background-color: #f0f0f0;")
        info_layout.addWidget(self.client_operator_input, 1, 1)

        # Тип тура - QLineEdit только для чтения
        info_layout.addWidget(QLabel("Тип тура:"), 1, 2)
        self.client_type_input = QLineEdit()
        self.client_type_input.setReadOnly(True)
        self.client_type_input.setMinimumWidth(150)
        self.client_type_input.setStyleSheet("background-color: #f0f0f0;")
        info_layout.addWidget(self.client_type_input, 1, 3)

        # Даты - QLineEdit только для чтения
        info_layout.addWidget(QLabel("Даты:"), 2, 0)
        self.client_dates_input = QLineEdit()
        self.client_dates_input.setReadOnly(True)
        self.client_dates_input.setMinimumWidth(200)
        self.client_dates_input.setStyleSheet("background-color: #f0f0f0;")
        info_layout.addWidget(self.client_dates_input, 2, 1)

        # Длительность - QLineEdit только для чтения
        info_layout.addWidget(QLabel("Длительность:"), 2, 2)
        self.client_duration_input = QLineEdit()
        self.client_duration_input.setReadOnly(True)
        self.client_duration_input.setMinimumWidth(100)
        self.client_duration_input.setStyleSheet("background-color: #f0f0f0;")
        info_layout.addWidget(self.client_duration_input, 2, 3)

        # Стоимость (за одного человека) - QLineEdit только для чтения
        info_layout.addWidget(QLabel("Стоимость (за 1 чел.):"), 3, 0)
        self.client_price_input = QLineEdit()
        self.client_price_input.setReadOnly(True)
        self.client_price_input.setMinimumWidth(150)
        self.client_price_input.setStyleSheet("background-color: #f0f0f0;")
        info_layout.addWidget(self.client_price_input, 3, 1)

        # Свободных мест - QLineEdit только для чтения
        info_layout.addWidget(QLabel("Свободных мест:"), 3, 2)
        self.client_seats_input = QLineEdit()
        self.client_seats_input.setReadOnly(True)
        self.client_seats_input.setMinimumWidth(80)
        self.client_seats_input.setStyleSheet("background-color: #f0f0f0;")
        info_layout.addWidget(self.client_seats_input, 3, 3)

        booking_layout.addLayout(info_layout)

        # Данные бронирования
        booking_data_layout = QHBoxLayout()
        booking_data_layout.addWidget(QLabel("Количество человек:"))
        self.client_persons_count = QSpinBox()
        self.client_persons_count.setMinimum(1)
        self.client_persons_count.setMaximum(10)
        self.client_persons_count.valueChanged.connect(self.calculate_client_total_price)
        booking_data_layout.addWidget(self.client_persons_count)

        booking_data_layout.addWidget(QLabel("Общая стоимость:"))
        self.client_total_price_input = QLineEdit()
        self.client_total_price_input.setReadOnly(True)
        self.client_total_price_input.setMinimumWidth(150)
        self.client_total_price_input.setStyleSheet("background-color: #f0f0f0; font-weight: bold;")
        self.client_total_price_input.setText("0.00 руб.")
        booking_data_layout.addWidget(self.client_total_price_input)
        booking_data_layout.addStretch()
        booking_layout.addLayout(booking_data_layout)

        # Примечания - TextEdit для ввода клиентом
        notes_layout = QHBoxLayout()
        notes_layout.addWidget(QLabel("Ваши пожелания:"))
        self.client_booking_notes = QTextEdit()
        self.client_booking_notes.setPlaceholderText("Введите ваши пожелания или особые требования...")
        self.client_booking_notes.setMaximumHeight(80)
        notes_layout.addWidget(self.client_booking_notes)
        booking_layout.addLayout(notes_layout)

        # Кнопка бронирования
        button_layout = QHBoxLayout()
        book_button = QPushButton("Забронировать тур")
        book_button.clicked.connect(self.create_client_booking)
        book_button.setStyleSheet("font-weight: bold; padding: 8px;")
        button_layout.addWidget(book_button)
        button_layout.addStretch()
        booking_layout.addLayout(button_layout)

        booking_group.setLayout(booking_layout)
        layout.addWidget(booking_group)
        self.tabs.addTab(tab, "Бронирование тура")

    def create_my_bookings_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        # Группа с информацией
        info_group = QGroupBox("Мои заявки")
        info_layout = QVBoxLayout()

        info_label = QLabel("Здесь отображаются все ваши заявки на туры. Статус заявки можно отслеживать по цвету:")
        info_label.setWordWrap(True)
        info_layout.addWidget(info_label)

        # Легенда статусов
        legend_layout = QGridLayout()
        legend_layout.addWidget(QLabel("🟡"), 0, 0)
        legend_layout.addWidget(QLabel("ожидание подтверждения"), 0, 1)
        legend_layout.addWidget(QLabel("🟢"), 1, 0)
        legend_layout.addWidget(QLabel("подтверждено"), 1, 1)
        legend_layout.addWidget(QLabel("🔴"), 2, 0)
        legend_layout.addWidget(QLabel("отменено"), 2, 1)
        legend_layout.addWidget(QLabel("🔵"), 3, 0)
        legend_layout.addWidget(QLabel("завершено"), 3, 1)
        info_layout.addLayout(legend_layout)

        info_group.setLayout(info_layout)
        layout.addWidget(info_group)

        # Таблица заявок
        self.client_bookings_table = QTableWidget()
        self.client_bookings_table.setColumnCount(8)
        self.client_bookings_table.setHorizontalHeaderLabels([
            "ID", "Тур", "Страна", "Дата заявки",
            "Кол-во человек", "Общая стоимость", "Статус", "Туроператор"
        ])
        header = self.client_bookings_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)

        layout.addWidget(self.client_bookings_table)
        self.tabs.addTab(tab, "Мои заявки")

    def create_tours_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        # Группа с информацией
        info_group = QGroupBox("Каталог туров")
        info_layout = QVBoxLayout()

        info_label = QLabel(
            "В каталоге представлены все доступные туры. Выберите тур для бронирования на вкладке 'Бронирование тура'.")
        info_label.setWordWrap(True)
        info_layout.addWidget(info_label)

        # Фильтры
        filter_layout = QHBoxLayout()
        filter_layout.addWidget(QLabel("Фильтр по стране:"))
        self.country_filter_combo = QComboBox()
        self.country_filter_combo.addItem("Все страны")
        self.country_filter_combo.currentIndexChanged.connect(self.filter_tours_by_country)
        filter_layout.addWidget(self.country_filter_combo)
        filter_layout.addStretch()
        info_layout.addLayout(filter_layout)

        info_group.setLayout(info_layout)
        layout.addWidget(info_group)

        # Таблица туров
        self.client_tours_table = QTableWidget()
        self.client_tours_table.setColumnCount(8)
        self.client_tours_table.setHorizontalHeaderLabels([
            "ID", "Название", "Страна", "Город", "Туроператор",
            "Дата начала", "Дата окончания", "Стоимость"
        ])
        header = self.client_tours_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)

        # Двойной клик по туру
        self.client_tours_table.doubleClicked.connect(self.on_tour_double_click)

        layout.addWidget(self.client_tours_table)
        self.tabs.addTab(tab, "Доступные туры")

    def load_initial_data(self):
        self.load_client_tours()
        self.load_client_bookings()
        self.load_all_tours_table()
        self.load_country_filters()

    def load_country_filters(self):
        """Загрузка списка стран для фильтра"""
        try:
            tours = self.db.get_all_tours()
            countries = set()
            for tour in tours:
                countries.add(tour['country'])

            self.country_filter_combo.clear()
            self.country_filter_combo.addItem("Все страны")
            for country in sorted(countries):
                self.country_filter_combo.addItem(country)
        except Error as e:
            print(f"Ошибка при загрузке стран для фильтра: {e}")

    def filter_tours_by_country(self):
        """Фильтрация туров по стране"""
        selected_country = self.country_filter_combo.currentText()
        if selected_country == "Все страны":
            self.load_all_tours_table()
        else:
            try:
                tours = self.db.get_all_tours()
                filtered_tours = [tour for tour in tours if tour['country'] == selected_country]
                self.update_tours_table(filtered_tours)
            except Error as e:
                print(f"Ошибка при фильтрации туров: {e}")

    def update_tours_table(self, tours):
        """Обновление таблицы туров с заданным списком"""
        self.client_tours_table.setRowCount(len(tours))
        for row, tour in enumerate(tours):
            self.client_tours_table.setItem(row, 0, QTableWidgetItem(str(tour['id'])))
            self.client_tours_table.setItem(row, 1, QTableWidgetItem(tour['tour_name']))
            self.client_tours_table.setItem(row, 2, QTableWidgetItem(tour['country']))
            self.client_tours_table.setItem(row, 3, QTableWidgetItem(tour.get('city', '')))
            self.client_tours_table.setItem(row, 4, QTableWidgetItem(tour['tour_operator']))
            self.client_tours_table.setItem(row, 5, QTableWidgetItem(tour.get('start_date', '')))
            self.client_tours_table.setItem(row, 6, QTableWidgetItem(tour.get('end_date', '')))
            self.client_tours_table.setItem(row, 7, QTableWidgetItem(f"{float(tour['price']):.2f} руб."))

    def on_tour_double_click(self, index):
        """При двойном клике на тур в таблице, переходим на вкладку бронирования и выбираем этот тур"""
        row = index.row()
        tour_id = self.client_tours_table.item(row, 0).text()

        # Переходим на вкладку бронирования
        self.tabs.setCurrentIndex(0)

        # Ищем и выбираем тур в комбобоксе
        for i in range(self.client_tour_combo.count()):
            if str(self.client_tour_combo.itemData(i)) == tour_id:
                self.client_tour_combo.setCurrentIndex(i)
                break

    def load_client_tours(self):
        try:
            tours = self.db.get_all_tours()
            self.client_tour_combo.clear()
            for tour in tours:
                self.client_tour_combo.addItem(
                    f"{tour['tour_name']} ({tour['country']}, {tour['price']} руб.)",
                    tour['id']
                )
        except Error as e:
            print(f"Ошибка при загрузке туров: {e}")

    def update_client_tour_info(self):
        tour_id = self.client_tour_combo.currentData()
        if not tour_id:
            # Очищаем поля если тур не выбран
            self.clear_tour_info_fields()
            return

        try:
            tour = self.db.get_tour_by_id(tour_id)
            if tour:
                # Заполняем QLineEdit поля (только для чтения)
                self.client_country_input.setText(tour['country'])
                self.client_city_input.setText(tour.get('city', 'не указан'))
                self.client_operator_input.setText(tour['tour_operator'])
                self.client_type_input.setText(tour['tour_type'])
                self.client_dates_input.setText(f"{tour['start_date']} - {tour['end_date']}")
                self.client_duration_input.setText(f"{tour['duration_days']} дней")
                self.client_price_input.setText(f"{float(tour['price']):.2f} руб.")
                self.client_seats_input.setText(str(tour['available_seats']))
                self.calculate_client_total_price()
            else:
                self.clear_tour_info_fields()
        except Error as e:
            print(f"Ошибка при обновлении информации о туре: {e}")
            self.clear_tour_info_fields()

    def clear_tour_info_fields(self):
        """Очистка всех полей с информацией о туре"""
        self.client_country_input.clear()
        self.client_city_input.clear()
        self.client_operator_input.clear()
        self.client_type_input.clear()
        self.client_dates_input.clear()
        self.client_duration_input.clear()
        self.client_price_input.clear()
        self.client_seats_input.clear()
        self.client_total_price_input.setText("0.00 руб.")

    def calculate_client_total_price(self):
        tour_id = self.client_tour_combo.currentData()
        if not tour_id:
            self.client_total_price_input.setText("0.00 руб.")
            return

        try:
            tour = self.db.get_tour_by_id(tour_id)
            if tour:
                persons = self.client_persons_count.value()
                total = float(tour['price']) * persons
                self.client_total_price_input.setText(f"{total:.2f} руб.")
        except Error as e:
            print(f"Ошибка при расчете стоимости: {e}")
            self.client_total_price_input.setText("0.00 руб.")

    def create_client_booking(self):
        tour_id = self.client_tour_combo.currentData()
        persons_count = self.client_persons_count.value()
        notes = self.client_booking_notes.toPlainText()

        if not tour_id:
            QMessageBox.warning(self, "Ошибка", "Выберите тур для бронирования")
            return

        try:
            tour = self.db.get_tour_by_id(tour_id)
            if not tour:
                QMessageBox.warning(self, "Ошибка", "Выбранный тур не найден")
                return

            # Проверка доступности мест
            if tour['available_seats'] < persons_count:
                QMessageBox.warning(self, "Ошибка",
                                    f"Недостаточно свободных мест. Доступно: {tour['available_seats']}")
                return

            total_price = float(tour['price']) * persons_count
            booking_date = QDate.currentDate().toString("yyyy-MM-dd")

            booking_data = (
                self.user['id'], tour_id, booking_date,
                persons_count, total_price, 'pending', notes
            )

            booking_id, error = self.db.create_booking(booking_data)
            if booking_id:
                QMessageBox.information(self, "Успех",
                                        f"Тур успешно забронирован!\n\n"
                                        f"Номер заявки: {booking_id}\n"
                                        f"Тур: {tour['tour_name']}\n"
                                        f"Страна: {tour['country']}\n"
                                        f"Даты: {tour['start_date']} - {tour['end_date']}\n"
                                        f"Количество человек: {persons_count}\n"
                                        f"Общая стоимость: {total_price:.2f} руб.\n"
                                        f"Статус: ожидание подтверждения")

                # Обновляем данные
                self.load_client_bookings()
                self.load_client_tours()
                self.load_all_tours_table()
                self.clear_client_booking_form()

            else:
                QMessageBox.warning(self, "Ошибка", f"Не удалось забронировать тур: {error}")

        except Error as e:
            print(f"Ошибка при бронировании тура: {e}")
            QMessageBox.critical(self, "Ошибка", "Не удалось забронировать тур")

    def load_client_bookings(self):
        try:
            bookings = self.db.get_client_bookings(self.user['id'])
            self.client_bookings_table.setRowCount(len(bookings))

            for row, booking in enumerate(bookings):
                self.client_bookings_table.setItem(row, 0, QTableWidgetItem(str(booking.get('id', ''))))
                self.client_bookings_table.setItem(row, 1, QTableWidgetItem(booking.get('tour_name', '')))
                self.client_bookings_table.setItem(row, 2, QTableWidgetItem(booking.get('country', '')))
                self.client_bookings_table.setItem(row, 3, QTableWidgetItem(booking.get('booking_date', '')))
                self.client_bookings_table.setItem(row, 4, QTableWidgetItem(str(booking.get('persons_count', ''))))
                self.client_bookings_table.setItem(row, 5,
                                                   QTableWidgetItem(f"{float(booking.get('total_price', 0)):.2f} руб."))

                status_item = QTableWidgetItem(booking.get('status', ''))
                status_text = booking.get('status', '')
                if status_text == 'confirmed':
                    status_item.setBackground(QColor(200, 255, 200))
                elif status_text == 'cancelled':
                    status_item.setBackground(QColor(255, 200, 200))
                elif status_text == 'completed':
                    status_item.setBackground(QColor(150, 200, 255))
                elif status_text == 'pending':
                    status_item.setBackground(QColor(255, 255, 200))
                self.client_bookings_table.setItem(row, 6, status_item)

                self.client_bookings_table.setItem(row, 7, QTableWidgetItem(booking.get('tour_operator', '')))
        except Error as e:
            print(f"Ошибка при загрузке заявок клиента: {e}")

    def load_all_tours_table(self):
        try:
            tours = self.db.get_all_tours()
            self.update_tours_table(tours)
        except Error as e:
            print(f"Ошибка при загрузке туров в таблицу: {e}")

    def clear_client_booking_form(self):
        """Очистка формы бронирования"""
        self.client_persons_count.setValue(1)
        self.client_booking_notes.clear()
        self.clear_tour_info_fields()