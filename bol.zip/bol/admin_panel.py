from datetime import timedelta

from PyQt6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                             QTabWidget, QTableWidget, QTableWidgetItem, QPushButton,
                             QLabel, QLineEdit, QDateEdit, QComboBox, QTextEdit,
                             QGroupBox, QMessageBox, QHeaderView, QFormLayout,
                             QTimeEdit, QGridLayout, QSpinBox)
from PyQt6.QtCore import Qt, QDate, QTime
from PyQt6.QtGui import QFont, QColor
from pymysql import Error


class AdminPanel(QMainWindow):
    def __init__(self, db, user):
        super().__init__()
        self.db = db
        self.user = user
        self.current_editing_appointment_id = None
        self.current_appointments_data = []

        self.setWindowTitle(f"Панель администратора - {user['full_name']}")
        self.setGeometry(100, 100, 1400, 800)

        self.setup_ui()
        self.load_initial_data()

    def setup_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)

        self.tabs = QTabWidget()
        self.create_appointments_tab()
        self.create_patients_tab()
        self.create_doctors_tab()

        main_layout.addWidget(self.tabs)

    def create_appointments_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        # ФОРМА ЗАПИСИ НА ПРИЕМ
        appointment_form_group = QGroupBox("Запись пациента на прием")
        appointment_form_layout = QVBoxLayout()

        # Пациент и Врач
        row1 = QHBoxLayout()
        row1.addWidget(QLabel("Пациент:"))
        self.patient_combo = QComboBox()
        self.patient_combo.setMinimumWidth(300)
        row1.addWidget(self.patient_combo)

        row1.addWidget(QLabel("Врач:"))
        self.doctor_combo = QComboBox()
        self.doctor_combo.setMinimumWidth(250)
        self.doctor_combo.currentIndexChanged.connect(self.on_doctor_changed)
        row1.addWidget(self.doctor_combo)

        row1.addStretch()
        appointment_form_layout.addLayout(row1)

        # Дата и время
        row2 = QHBoxLayout()
        row2.addWidget(QLabel("Дата приема:"))
        self.appointment_date = QDateEdit()
        self.appointment_date.setDate(QDate.currentDate().addDays(1))
        self.appointment_date.setCalendarPopup(True)
        self.appointment_date.setMinimumDate(QDate.currentDate())
        row2.addWidget(self.appointment_date)

        row2.addWidget(QLabel("Время:"))
        self.appointment_time = QTimeEdit()
        self.appointment_time.setTime(QTime(9, 0))
        row2.addWidget(self.appointment_time)

        row2.addWidget(QLabel("Длительность (мин):"))
        self.duration_input = QSpinBox()
        self.duration_input.setRange(15, 240)
        self.duration_input.setValue(30)
        row2.addWidget(self.duration_input)

        row2.addStretch()
        appointment_form_layout.addLayout(row2)

        # Причина и симптомы
        row3 = QHBoxLayout()
        row3.addWidget(QLabel("Причина обращения:"))
        self.reason_input = QLineEdit()
        self.reason_input.setPlaceholderText("Опишите причину обращения")
        row3.addWidget(self.reason_input)

        row3.addWidget(QLabel("Симптомы:"))
        self.symptoms_input = QLineEdit()
        self.symptoms_input.setPlaceholderText("Основные симптомы")
        row3.addWidget(self.symptoms_input)

        appointment_form_layout.addLayout(row3)

        # Стоимость и статус
        row4 = QHBoxLayout()
        row4.addWidget(QLabel("Стоимость:"))
        self.price_input = QLineEdit()
        self.price_input.setPlaceholderText("0.00")
        row4.addWidget(self.price_input)

        row4.addWidget(QLabel("Статус:"))
        self.status_combo = QComboBox()
        self.status_combo.addItems(['scheduled', 'completed', 'cancelled', 'no_show'])
        row4.addWidget(self.status_combo)

        row4.addStretch()
        appointment_form_layout.addLayout(row4)

        # Примечания
        row5 = QHBoxLayout()
        row5.addWidget(QLabel("Примечания:"))
        self.notes_text = QTextEdit()
        self.notes_text.setMaximumHeight(60)
        row5.addWidget(self.notes_text)
        appointment_form_layout.addLayout(row5)

        # Кнопки
        buttons_row = QHBoxLayout()
        self.new_appointment_btn = QPushButton("Создать запись")
        self.new_appointment_btn.clicked.connect(self.create_appointment_from_form)
        buttons_row.addWidget(self.new_appointment_btn)

        self.update_appointment_btn = QPushButton("Обновить запись")
        self.update_appointment_btn.clicked.connect(self.update_appointment_from_form)
        self.update_appointment_btn.setEnabled(False)
        buttons_row.addWidget(self.update_appointment_btn)

        self.delete_appointment_btn = QPushButton("Удалить запись")
        self.delete_appointment_btn.clicked.connect(self.delete_appointment)
        self.delete_appointment_btn.setEnabled(False)
        buttons_row.addWidget(self.delete_appointment_btn)

        buttons_row.addStretch()
        appointment_form_layout.addLayout(buttons_row)

        appointment_form_group.setLayout(appointment_form_layout)
        layout.addWidget(appointment_form_group)

        # Группа фильтров
        filter_group = QGroupBox("Фильтр записей")
        filter_layout = QVBoxLayout()

        # Фильтр по дате
        date_filter_layout = QHBoxLayout()
        date_filter_layout.addWidget(QLabel("Период с:"))
        self.start_date_filter = QDateEdit()
        self.start_date_filter.setDate(QDate.currentDate())
        self.start_date_filter.setCalendarPopup(True)
        date_filter_layout.addWidget(self.start_date_filter)

        date_filter_layout.addWidget(QLabel("по:"))
        self.end_date_filter = QDateEdit()
        self.end_date_filter.setDate(QDate.currentDate().addDays(30))
        self.end_date_filter.setCalendarPopup(True)
        date_filter_layout.addWidget(self.end_date_filter)

        filter_button = QPushButton("Фильтровать по дате")
        filter_button.clicked.connect(self.filter_appointments_by_date)
        date_filter_layout.addWidget(filter_button)

        date_filter_layout.addStretch()
        filter_layout.addLayout(date_filter_layout)

        # Фильтр по врачу
        doctor_filter_layout = QHBoxLayout()
        doctor_filter_layout.addWidget(QLabel("Врач:"))
        self.doctor_filter_combo = QComboBox()
        self.doctor_filter_combo.addItem("Все врачи", 0)
        doctor_filter_layout.addWidget(self.doctor_filter_combo)

        filter_doctor_button = QPushButton("Фильтровать по врачу")
        filter_doctor_button.clicked.connect(self.filter_appointments_by_doctor)
        doctor_filter_layout.addWidget(filter_doctor_button)

        show_all_button = QPushButton("Показать все")
        show_all_button.clicked.connect(self.show_all_appointments)
        doctor_filter_layout.addWidget(show_all_button)

        doctor_filter_layout.addStretch()
        filter_layout.addLayout(doctor_filter_layout)

        filter_group.setLayout(filter_layout)
        layout.addWidget(filter_group)

        # ТАБЛИЦА ЗАПИСЕЙ
        self.appointments_table = QTableWidget()
        self.appointments_table.setColumnCount(9)
        self.appointments_table.setHorizontalHeaderLabels([
            "ID", "Пациент", "Врач", "Дата", "Время", "Причина", "Стоимость", "Статус", "Примечания"
        ])

        header = self.appointments_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)

        self.appointments_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.appointments_table.clicked.connect(self.on_appointment_table_click)
        layout.addWidget(self.appointments_table)

        self.tabs.addTab(tab, "Записи на прием")

        # Загружаем данные для формы
        self.load_patients_for_combo()
        self.load_doctors_for_combo()
        self.load_doctors_for_filter()

    def load_doctors_for_filter(self):
        """Загрузка врачей для фильтра"""
        try:
            doctors = self.db.get_all_doctors()
            self.doctor_filter_combo.clear()
            self.doctor_filter_combo.addItem("Все врачи", 0)
            for doctor in doctors:
                self.doctor_filter_combo.addItem(
                    f"{doctor['full_name']} ({doctor['specialization']})",
                    doctor['id']
                )
        except Error as e:
            print(f"Ошибка при загрузке врачей для фильтра: {e}")

    def filter_appointments_by_date(self):
        """Фильтрация записей по дате"""
        start_date = self.start_date_filter.date().toString("yyyy-MM-dd")
        end_date = self.end_date_filter.date().toString("yyyy-MM-dd")

        try:
            # Получаем все записи и фильтруем их локально
            appointments = self.db.get_all_appointments()
            filtered_appointments = []

            for appointment in appointments:
                appointment_date = appointment.get('appointment_date', '')
                # Преобразуем дату в строку для сравнения
                if appointment_date:
                    if not isinstance(appointment_date, str):
                        appointment_date = appointment_date.strftime('%Y-%m-%d')

                    # Проверяем, попадает ли дата в диапазон
                    if start_date <= appointment_date <= end_date:
                        filtered_appointments.append(appointment)

            self.update_appointments_table(filtered_appointments)
            QMessageBox.information(self, "Фильтр",
                                    f"Показано {len(filtered_appointments)} записей с {start_date} по {end_date}")

        except Exception as e:
            print(f"Ошибка при фильтрации по дате: {e}")
            QMessageBox.warning(self, "Ошибка", f"Не удалось применить фильтр: {str(e)}")

    def filter_appointments_by_doctor(self):
        """Фильтрация записей по врачу"""
        doctor_id = self.doctor_filter_combo.currentData()

        if doctor_id == 0:  # "Все врачи"
            self.show_all_appointments()
            return

        try:
            appointments = self.db.get_all_appointments()
            filtered_appointments = []

            for appointment in appointments:
                if appointment.get('doctor_id') == doctor_id:
                    filtered_appointments.append(appointment)

            self.update_appointments_table(filtered_appointments)

            doctor_name = self.doctor_filter_combo.currentText()
            QMessageBox.information(self, "Фильтр",
                                    f"Показано {len(filtered_appointments)} записей для врача: {doctor_name}")

        except Exception as e:
            print(f"Ошибка при фильтрации по врачу: {e}")
            QMessageBox.warning(self, "Ошибка", f"Не удалось применить фильтр: {str(e)}")

    def show_all_appointments(self):
        """Показать все записи (сбросить фильтры)"""
        self.load_appointments()
        QMessageBox.information(self, "Фильтр", "Показаны все записи")

    def on_doctor_changed(self):
        """Обновляет цену при выборе врача"""
        doctor_data = self.doctor_combo.currentData()
        if not doctor_data:
            return

        # doctor_data теперь кортеж (id, price) или просто id
        price = 0.0
        if isinstance(doctor_data, tuple) and len(doctor_data) >= 2:
            _, price = doctor_data
        else:
            # Пробуем получить цену из БД
            try:
                doctor_id = doctor_data
                with self.db.connection.cursor() as cursor:
                    sql = "SELECT price_per_appointment FROM doctors WHERE id = %s"
                    cursor.execute(sql, (doctor_id,))
                    doctor = cursor.fetchone()
                    if doctor and doctor.get('price_per_appointment'):
                        price = float(doctor['price_per_appointment'])
            except Error as e:
                print(f"Ошибка при получении цены врача: {e}")

        self.price_input.setText(f"{price:.2f}")

    def create_patients_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        # ФОРМА РЕГИСТРАЦИИ ПАЦИЕНТА
        patient_form_group = QGroupBox("Регистрация нового пациента")
        patient_form_layout = QGridLayout()

        # Личные данные
        patient_form_layout.addWidget(QLabel("ФИО:"), 0, 0)
        self.new_patient_name = QLineEdit()
        self.new_patient_name.setPlaceholderText("Иванов Иван Иванович")
        patient_form_layout.addWidget(self.new_patient_name, 0, 1)

        patient_form_layout.addWidget(QLabel("Дата рождения:"), 0, 2)
        self.new_patient_birth_date = QDateEdit()
        self.new_patient_birth_date.setCalendarPopup(True)
        self.new_patient_birth_date.setDate(QDate(1990, 1, 1))
        patient_form_layout.addWidget(self.new_patient_birth_date, 0, 3)

        # Контакты
        patient_form_layout.addWidget(QLabel("Телефон:"), 1, 0)
        self.new_patient_phone = QLineEdit()
        self.new_patient_phone.setPlaceholderText("+79991234567")
        patient_form_layout.addWidget(self.new_patient_phone, 1, 1)

        patient_form_layout.addWidget(QLabel("Email:"), 1, 2)
        self.new_patient_email = QLineEdit()
        self.new_patient_email.setPlaceholderText("patient@mail.ru")
        patient_form_layout.addWidget(self.new_patient_email, 1, 3)

        # Медицинская информация
        patient_form_layout.addWidget(QLabel("Номер мед. карты:"), 2, 0)
        self.new_patient_medical_card = QLineEdit()
        patient_form_layout.addWidget(self.new_patient_medical_card, 2, 1)

        patient_form_layout.addWidget(QLabel("Страховой полис:"), 2, 2)
        self.new_patient_insurance = QLineEdit()
        patient_form_layout.addWidget(self.new_patient_insurance, 2, 3)

        patient_form_layout.addWidget(QLabel("Группа крови:"), 3, 0)
        self.new_patient_blood_type = QComboBox()
        self.new_patient_blood_type.addItems(["Не указано", "A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"])
        patient_form_layout.addWidget(self.new_patient_blood_type, 3, 1)

        patient_form_layout.addWidget(QLabel("Аллергии:"), 3, 2)
        self.new_patient_allergies = QTextEdit()
        self.new_patient_allergies.setMaximumHeight(50)
        patient_form_layout.addWidget(self.new_patient_allergies, 3, 3)

        # Данные для входа
        patient_form_layout.addWidget(QLabel("Логин:"), 4, 0)
        self.new_patient_username = QLineEdit()
        self.new_patient_username.setPlaceholderText("Логин для входа в систему")
        patient_form_layout.addWidget(self.new_patient_username, 4, 1)

        patient_form_layout.addWidget(QLabel("Пароль:"), 4, 2)
        self.new_patient_password = QLineEdit()
        self.new_patient_password.setPlaceholderText("Пароль для входа")
        patient_form_layout.addWidget(self.new_patient_password, 4, 3)

        # Кнопки
        patient_buttons_layout = QHBoxLayout()
        register_patient_btn = QPushButton("Зарегистрировать пациента")
        register_patient_btn.clicked.connect(self.register_new_patient)
        patient_buttons_layout.addWidget(register_patient_btn)

        clear_patient_btn = QPushButton("Очистить форму")
        clear_patient_btn.clicked.connect(self.clear_patient_form)
        patient_buttons_layout.addWidget(clear_patient_btn)

        patient_buttons_layout.addStretch()
        patient_form_layout.addLayout(patient_buttons_layout, 5, 0, 1, 4)

        patient_form_group.setLayout(patient_form_layout)
        layout.addWidget(patient_form_group)

        # ТАБЛИЦА ПАЦИЕНТОВ
        self.patients_table = QTableWidget()
        self.patients_table.setColumnCount(7)
        self.patients_table.setHorizontalHeaderLabels([
            "ID", "ФИО", "Телефон", "Дата рождения", "Мед. карта", "Полис", "Группа крови"
        ])

        header = self.patients_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)

        layout.addWidget(self.patients_table)

        self.tabs.addTab(tab, "Пациенты")

    def create_doctors_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        # ФОРМА ДОБАВЛЕНИЯ ВРАЧА
        doctor_form_group = QGroupBox("Добавление нового врача")
        doctor_form_layout = QGridLayout()

        # Основная информация
        doctor_form_layout.addWidget(QLabel("ФИО:"), 0, 0)
        self.new_doctor_name = QLineEdit()
        self.new_doctor_name.setPlaceholderText("Петров Петр Петрович")
        doctor_form_layout.addWidget(self.new_doctor_name, 0, 1)

        doctor_form_layout.addWidget(QLabel("Специализация:"), 0, 2)
        self.new_doctor_specialization = QComboBox()
        doctor_form_layout.addWidget(self.new_doctor_specialization, 0, 3)

        doctor_form_layout.addWidget(QLabel("Квалификация:"), 1, 0)
        self.new_doctor_qualification = QLineEdit()
        self.new_doctor_qualification.setPlaceholderText("Высшая категория, к.м.н.")
        doctor_form_layout.addWidget(self.new_doctor_qualification, 1, 1)

        doctor_form_layout.addWidget(QLabel("Опыт (лет):"), 1, 2)
        self.new_doctor_experience = QSpinBox()
        self.new_doctor_experience.setRange(0, 50)
        doctor_form_layout.addWidget(self.new_doctor_experience, 1, 3)

        # Контакты
        doctor_form_layout.addWidget(QLabel("Телефон:"), 2, 0)
        self.new_doctor_phone = QLineEdit()
        self.new_doctor_phone.setPlaceholderText("+79991234567")
        doctor_form_layout.addWidget(self.new_doctor_phone, 2, 1)

        doctor_form_layout.addWidget(QLabel("Email:"), 2, 2)
        self.new_doctor_email = QLineEdit()
        self.new_doctor_email.setPlaceholderText("doctor@hospital.ru")
        doctor_form_layout.addWidget(self.new_doctor_email, 2, 3)

        doctor_form_layout.addWidget(QLabel("Кабинет:"), 3, 0)
        self.new_doctor_office = QLineEdit()
        self.new_doctor_office.setPlaceholderText("101")
        doctor_form_layout.addWidget(self.new_doctor_office, 3, 1)

        # График и стоимость
        doctor_form_layout.addWidget(QLabel("График работы:"), 3, 2)
        self.new_doctor_schedule = QLineEdit()
        self.new_doctor_schedule.setPlaceholderText("Пн-Пт 9:00-18:00")
        doctor_form_layout.addWidget(self.new_doctor_schedule, 3, 3)

        doctor_form_layout.addWidget(QLabel("Стоимость приема:"), 4, 0)
        self.new_doctor_price = QLineEdit()
        self.new_doctor_price.setPlaceholderText("2000.00")
        doctor_form_layout.addWidget(self.new_doctor_price, 4, 1)

        # Кнопки
        doctor_buttons_layout = QHBoxLayout()
        add_doctor_btn = QPushButton("Добавить врача")
        add_doctor_btn.clicked.connect(self.add_new_doctor)
        doctor_buttons_layout.addWidget(add_doctor_btn)

        clear_doctor_btn = QPushButton("Очистить форму")
        clear_doctor_btn.clicked.connect(self.clear_doctor_form)
        doctor_buttons_layout.addWidget(clear_doctor_btn)

        doctor_buttons_layout.addStretch()
        doctor_form_layout.addLayout(doctor_buttons_layout, 5, 0, 1, 4)

        doctor_form_group.setLayout(doctor_form_layout)
        layout.addWidget(doctor_form_group)

        # ТАБЛИЦА ВРАЧЕЙ
        self.doctors_table = QTableWidget()
        self.doctors_table.setColumnCount(7)
        self.doctors_table.setHorizontalHeaderLabels([
            "ID", "ФИО", "Специализация", "Квалификация", "Телефон", "Кабинет", "Стоимость"
        ])

        header = self.doctors_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)

        layout.addWidget(self.doctors_table)

        self.tabs.addTab(tab, "Врачи")

    def load_initial_data(self):
        self.load_appointments()
        self.load_patients()
        self.load_doctors()
        self.load_specializations()

    def load_appointments(self):
        try:
            appointments = self.db.get_all_appointments()
            self.update_appointments_table(appointments)
        except Exception as e:
            print(f"Ошибка при загрузке записей: {e}")
            QMessageBox.warning(self, "Ошибка", f"Не удалось загрузить записи: {str(e)}")

    def load_patients(self):
        patients = self.db.get_all_patients()
        self.patients_table.setRowCount(len(patients))

        for row, patient in enumerate(patients):
            self.patients_table.setItem(row, 0, QTableWidgetItem(str(patient['id'])))
            self.patients_table.setItem(row, 1, QTableWidgetItem(patient['full_name']))
            self.patients_table.setItem(row, 2, QTableWidgetItem(patient.get('phone', '')))

            # Исправлено: преобразуем дату рождения в строку
            birth_date = patient.get('birth_date', '')
            if birth_date:
                if not isinstance(birth_date, str):
                    # Если это datetime объект, преобразуем в строку
                    birth_date = birth_date.strftime('%Y-%m-%d')
            self.patients_table.setItem(row, 3, QTableWidgetItem(birth_date))

            self.patients_table.setItem(row, 4, QTableWidgetItem(patient.get('medical_card_number', '')))
            self.patients_table.setItem(row, 5, QTableWidgetItem(patient.get('insurance_policy', '')))
            self.patients_table.setItem(row, 6, QTableWidgetItem(patient.get('blood_type', '')))

    def load_doctors(self):
        doctors = self.db.get_all_doctors()
        self.doctors_table.setRowCount(len(doctors))

        for row, doctor in enumerate(doctors):
            self.doctors_table.setItem(row, 0, QTableWidgetItem(str(doctor['id'])))
            self.doctors_table.setItem(row, 1, QTableWidgetItem(doctor['full_name']))
            self.doctors_table.setItem(row, 2, QTableWidgetItem(doctor['specialization']))
            self.doctors_table.setItem(row, 3, QTableWidgetItem(doctor.get('qualification', '')))
            self.doctors_table.setItem(row, 4, QTableWidgetItem(doctor.get('phone', '')))
            self.doctors_table.setItem(row, 5, QTableWidgetItem(doctor.get('office_number', '')))
            self.doctors_table.setItem(row, 6, QTableWidgetItem(f"{float(doctor.get('price_per_appointment', 0)):.2f}"))

    def load_specializations(self):
        specializations = self.db.get_all_specializations()
        self.new_doctor_specialization.clear()
        for spec in specializations:
            self.new_doctor_specialization.addItem(spec['specialization_name'])

    def load_patients_for_combo(self):
        try:
            patients = self.db.get_all_patients()
            self.patient_combo.clear()
            for patient in patients:
                self.patient_combo.addItem(
                    f"{patient['full_name']} (тел: {patient.get('phone', '')})",
                    patient['id']  # Только ID
                )
        except Error as e:
            print(f"Ошибка при загрузке пациентов для комбобокса: {e}")

    def load_doctors_for_combo(self):
        try:
            doctors = self.db.get_all_doctors()
            self.doctor_combo.clear()
            for doctor in doctors:
                price = float(doctor.get('price_per_appointment', 0))
                self.doctor_combo.addItem(
                    f"{doctor['full_name']} ({doctor['specialization']}) - {price:.2f} руб.",
                    doctor['id']  # Только ID, цену будем получать отдельно
                )
        except Error as e:
            print(f"Ошибка при загрузке врачей для комбобокса: {e}")

    def register_new_patient(self):
        """Регистрация нового пациента"""
        # Получаем данные из формы
        full_name = self.new_patient_name.text().strip()
        birth_date = self.new_patient_birth_date.date().toString("yyyy-MM-dd")
        phone = self.new_patient_phone.text().strip()
        email = self.new_patient_email.text().strip() or None
        username = self.new_patient_username.text().strip()
        password = self.new_patient_password.text()

        medical_card = self.new_patient_medical_card.text().strip() or None
        insurance = self.new_patient_insurance.text().strip() or None
        blood_type = self.new_patient_blood_type.currentText()
        if blood_type == "Не указано":
            blood_type = None
        allergies = self.new_patient_allergies.toPlainText().strip() or None

        # Проверяем обязательные поля
        if not full_name or not phone or not username or not password:
            QMessageBox.warning(self, "Ошибка", "Заполните все обязательные поля")
            return

        try:
            # Данные для пользователя
            user_data = (username, password, full_name, email, phone, birth_date)
            # Данные для пациента
            patient_data = (medical_card, insurance, blood_type, allergies, None)

            patient_id = self.db.register_patient(user_data, patient_data)

            if patient_id:
                QMessageBox.information(self, "Успех",
                                        f"Пациент успешно зарегистрирован!\n\nЛогин: {username}\nПароль: {password}")

                # Обновляем данные
                self.load_patients()
                self.load_patients_for_combo()
                self.clear_patient_form()

        except Error as e:
            print(f"Ошибка при регистрации пациента: {e}")
            QMessageBox.critical(self, "Ошибка", "Не удалось зарегистрировать пациента")

    def clear_patient_form(self):
        """Очистка формы регистрации пациента"""
        self.new_patient_name.clear()
        self.new_patient_birth_date.setDate(QDate(1990, 1, 1))
        self.new_patient_phone.clear()
        self.new_patient_email.clear()
        self.new_patient_medical_card.clear()
        self.new_patient_insurance.clear()
        self.new_patient_blood_type.setCurrentIndex(0)
        self.new_patient_allergies.clear()
        self.new_patient_username.clear()
        self.new_patient_password.clear()

    def add_new_doctor(self):
        """Добавление нового врача"""
        # Получаем данные из формы
        full_name = self.new_doctor_name.text().strip()
        specialization = self.new_doctor_specialization.currentText()
        qualification = self.new_doctor_qualification.text().strip()
        experience = self.new_doctor_experience.value()
        phone = self.new_doctor_phone.text().strip()
        email = self.new_doctor_email.text().strip() or None
        office = self.new_doctor_office.text().strip()
        schedule = self.new_doctor_schedule.text().strip()

        try:
            price = float(self.new_doctor_price.text().strip() or "0")
        except ValueError:
            price = 0.0

        # Проверяем обязательные поля
        if not full_name or not specialization or not phone:
            QMessageBox.warning(self, "Ошибка", "Заполните все обязательные поля")
            return

        try:
            doctor_data = (full_name, specialization, qualification, phone, email,
                           office, schedule, experience, price)

            doctor_id = self.db.add_doctor(doctor_data)

            if doctor_id:
                QMessageBox.information(self, "Успех", "Врач успешно добавлен!")

                # Обновляем данные
                self.load_doctors()
                self.load_doctors_for_combo()
                self.clear_doctor_form()

        except Error as e:
            print(f"Ошибка при добавлении врача: {e}")
            QMessageBox.critical(self, "Ошибка", "Не удалось добавить врача")

    def clear_doctor_form(self):
        """Очистка формы добавления врача"""
        self.new_doctor_name.clear()
        self.new_doctor_specialization.setCurrentIndex(0)
        self.new_doctor_qualification.clear()
        self.new_doctor_experience.setValue(0)
        self.new_doctor_phone.clear()
        self.new_doctor_email.clear()
        self.new_doctor_office.clear()
        self.new_doctor_schedule.clear()
        self.new_doctor_price.clear()

    def create_appointment_from_form(self):
        patient_id = self.patient_combo.currentData()
        doctor_id = self.doctor_combo.currentData()

        if not doctor_id:
            QMessageBox.warning(self, "Ошибка", "Выберите врача")
            return

        appointment_date = self.appointment_date.date().toString("yyyy-MM-dd")
        appointment_time = self.appointment_time.time().toString("HH:mm")
        duration = self.duration_input.value()
        reason = self.reason_input.text().strip()
        status = self.status_combo.currentText()

        # Получаем цену из поля ввода
        price_text = self.price_input.text().strip()
        try:
            price = float(price_text) if price_text else 0.0
        except ValueError:
            price = 0.0

        notes = self.notes_text.toPlainText().strip()

        if not patient_id or not doctor_id or not reason:
            QMessageBox.warning(self, "Ошибка", "Заполните все обязательные поля")
            return

        # Проверяем доступность времени
        is_available = self.db.check_time_availability(
            doctor_id, appointment_date, appointment_time, duration
        )

        if not is_available:
            QMessageBox.warning(self, "Ошибка", "Выбранное время уже занято")
            return

        appointment_data = (
            patient_id, doctor_id, appointment_date, appointment_time,
            duration, reason, "", status, price, notes
        )

        try:
            appointment_id = self.db.create_appointment(appointment_data)
            if appointment_id:
                QMessageBox.information(self, "Успех",
                                        f"Запись создана. ID: {appointment_id}\nСтоимость: {price:.2f} руб.")
                self.load_appointments()
                self.clear_appointment_form()
        except Error as e:
            print(f"Ошибка при создании записи: {e}")
            QMessageBox.critical(self, "Ошибка", "Не удалось создать запись")

    def update_appointment_from_form(self):
        if not self.current_editing_appointment_id:
            QMessageBox.warning(self, "Ошибка", "Сначала выберите запись из таблицы")
            return

        patient_id = self.patient_combo.currentData()
        doctor_id = self.doctor_combo.currentData()
        appointment_date = self.appointment_date.date().toString("yyyy-MM-dd")
        appointment_time = self.appointment_time.time().toString("HH:mm")
        duration = self.duration_input.value()
        reason = self.reason_input.text().strip()
        status = self.status_combo.currentText()

        # Получаем цену из поля ввода
        price_text = self.price_input.text().strip()
        try:
            price = float(price_text) if price_text else 0.0
        except ValueError:
            price = 0.0

        notes = self.notes_text.toPlainText().strip()

        if not patient_id or not doctor_id or not reason:
            QMessageBox.warning(self, "Ошибка", "Заполните все обязательные поля")
            return

        update_data = (
            doctor_id, appointment_date, appointment_time,
            duration, reason, status, price, notes
        )

        try:
            success = self.db.update_appointment(self.current_editing_appointment_id, update_data)
            if success:
                QMessageBox.information(self, "Успех", "Запись обновлена")
                self.load_appointments()
                self.clear_appointment_form()
                self.reset_form_buttons()
        except Error as e:
            print(f"Ошибка при обновлении записи: {e}")
            QMessageBox.critical(self, "Ошибка", "Не удалось обновить запись")

    def delete_appointment(self):
        if not self.current_editing_appointment_id:
            QMessageBox.warning(self, "Ошибка", "Сначала выберите запись из таблицы")
            return

        reply = QMessageBox.question(
            self, 'Подтверждение',
            'Вы уверены, что хотите удалить эту запись?',
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )

        if reply == QMessageBox.StandardButton.Yes:
            try:
                success = self.db.delete_appointment(self.current_editing_appointment_id)
                if success:
                    QMessageBox.information(self, "Успех", "Запись удалена")
                    self.load_appointments()
                    self.clear_appointment_form()
                    self.reset_form_buttons()
            except Error as e:
                print(f"Ошибка при удалении записи: {e}")
                QMessageBox.critical(self, "Ошибка", "Не удалось удалить запись")

    def on_appointment_table_click(self):
        selected = self.appointments_table.currentRow()
        if selected < 0:
            return

        appointment_id = int(self.appointments_table.item(selected, 0).text())
        self.current_editing_appointment_id = appointment_id

        # Получаем данные выбранной записи
        try:
            appointments = self.db.get_all_appointments()
            selected_appointment = None
            for app in appointments:
                if app['id'] == appointment_id:
                    selected_appointment = app
                    break

            if selected_appointment:
                # Заполняем форму данными записи
                # Находим пациента в комбобоксе
                patient_found = False
                for i in range(self.patient_combo.count()):
                    if self.patient_combo.itemData(i) == selected_appointment['patient_id']:
                        self.patient_combo.setCurrentIndex(i)
                        patient_found = True
                        break
                if not patient_found:
                    QMessageBox.warning(self, "Внимание", "Пациент не найден в списке")

                # Находим врача в комбобоксе
                doctor_found = False
                for i in range(self.doctor_combo.count()):
                    # itemData возвращает только ID врача
                    if self.doctor_combo.itemData(i) == selected_appointment['doctor_id']:
                        self.doctor_combo.setCurrentIndex(i)
                        doctor_found = True
                        # Обновляем цену после выбора врача
                        self.on_doctor_changed()
                        break
                if not doctor_found:
                    QMessageBox.warning(self, "Внимание", "Врач не найден в списке")

                # Устанавливаем дату и время
                if selected_appointment.get('appointment_date'):
                    try:
                        date_str = selected_appointment['appointment_date']
                        if isinstance(date_str, str):
                            date_parts = date_str.split('-')
                            if len(date_parts) == 3:
                                year, month, day = map(int, date_parts)
                                self.appointment_date.setDate(QDate(year, month, day))
                    except Exception as e:
                        print(f"Ошибка при установке даты: {e}")

                if selected_appointment.get('appointment_time'):
                    try:
                        time_str = selected_appointment['appointment_time']
                        if isinstance(time_str, str) and ':' in time_str:
                            time_parts = time_str.split(':')
                            if len(time_parts) >= 2:
                                hours = int(time_parts[0])
                                minutes = int(time_parts[1])
                                self.appointment_time.setTime(QTime(hours, minutes))
                    except Exception as e:
                        print(f"Ошибка при установке времени: {e}")

                # Устанавливаем остальные поля
                self.duration_input.setValue(selected_appointment.get('duration_minutes', 30))
                self.reason_input.setText(selected_appointment.get('reason', ''))

                price = selected_appointment.get('total_price', 0)
                try:
                    price_float = float(price)
                except (ValueError, TypeError):
                    price_float = 0.0
                self.price_input.setText(f"{price_float:.2f}")

                status_text = selected_appointment.get('status', 'scheduled')
                index = self.status_combo.findText(status_text)
                if index >= 0:
                    self.status_combo.setCurrentIndex(index)
                else:
                    self.status_combo.setCurrentIndex(0)

                self.notes_text.setPlainText(selected_appointment.get('notes', ''))

                # Активируем кнопки обновления и удаления
                self.new_appointment_btn.setEnabled(False)
                self.update_appointment_btn.setEnabled(True)
                self.delete_appointment_btn.setEnabled(True)

        except Exception as e:
            print(f"Ошибка при загрузке данных записи: {e}")
            QMessageBox.critical(self, "Ошибка", f"Не удалось загрузить данные записи: {str(e)}")

    def clear_appointment_form(self):
        self.appointment_date.setDate(QDate.currentDate().addDays(1))
        self.appointment_time.setTime(QTime(9, 0))
        self.duration_input.setValue(30)
        self.reason_input.clear()
        self.symptoms_input.clear()
        self.price_input.clear()
        self.status_combo.setCurrentIndex(0)
        self.notes_text.clear()

    def reset_form_buttons(self):
        self.current_editing_appointment_id = None
        self.new_appointment_btn.setEnabled(True)
        self.update_appointment_btn.setEnabled(False)
        self.delete_appointment_btn.setEnabled(False)

    def update_appointments_table(self, appointments):
        self.appointments_table.setRowCount(len(appointments))

        for row, appointment in enumerate(appointments):
            self.appointments_table.setItem(row, 0, QTableWidgetItem(str(appointment.get('id', ''))))
            self.appointments_table.setItem(row, 1, QTableWidgetItem(appointment.get('patient_name', '')))
            self.appointments_table.setItem(row, 2, QTableWidgetItem(appointment.get('doctor_name', '')))

            # Исправлено: преобразуем дату в строку
            appointment_date = appointment.get('appointment_date', '')
            if appointment_date:
                if not isinstance(appointment_date, str):
                    # Если это datetime объект, преобразуем в строку
                    appointment_date = appointment_date.strftime('%Y-%m-%d')
            self.appointments_table.setItem(row, 3, QTableWidgetItem(appointment_date))

            appointment_time = appointment.get('appointment_time', '')
            if appointment_time:
                if not isinstance(appointment_time, str):
                    # Если это время, преобразуем в строку
                    if hasattr(appointment_time, 'strftime'):
                        appointment_time = appointment_time.strftime('%H:%M')
                    elif isinstance(appointment_time, timedelta):
                        # Если это timedelta
                        total_seconds = int(appointment_time.total_seconds())
                        hours = total_seconds // 3600
                        minutes = (total_seconds % 3600) // 60
                        appointment_time = f"{hours:02d}:{minutes:02d}"
            self.appointments_table.setItem(row, 4, QTableWidgetItem(appointment_time))

            self.appointments_table.setItem(row, 5, QTableWidgetItem(appointment.get('reason', '')))

            price = appointment.get('total_price', 0)
            if isinstance(price, (int, float)):
                price_str = f"{float(price):.2f} руб."
            else:
                price_str = str(price)
            self.appointments_table.setItem(row, 6, QTableWidgetItem(price_str))

            status_item = QTableWidgetItem(appointment.get('status', ''))
            status_text = appointment.get('status', '')

            # Раскрашиваем статусы
            if status_text == 'completed':
                status_item.setBackground(QColor(200, 255, 200))  # Зеленый
            elif status_text == 'cancelled':
                status_item.setBackground(QColor(255, 200, 200))  # Красный
            elif status_text == 'no_show':
                status_item.setBackground(QColor(255, 150, 150))  # Темно-красный
            elif status_text == 'scheduled':
                status_item.setBackground(QColor(255, 255, 200))  # Желтый

            self.appointments_table.setItem(row, 7, status_item)
            self.appointments_table.setItem(row, 8, QTableWidgetItem(appointment.get('notes', '')))