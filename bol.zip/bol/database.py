import pymysql
from pymysql import Error
from datetime import datetime, timedelta


class Database:
    def __init__(self):
        self.host = "localhost"
        self.user = "root"
        self.password = "dn260306"  # Измените на ваш пароль MySQL
        self.database = "hospital_db"
        self.charset = "utf8mb4"
        self.connection = None

    def connect(self):
        try:
            self.connection = pymysql.connect(
                host=self.host,
                user=self.user,
                password=self.password,
                database=self.database,
                charset=self.charset,
                cursorclass=pymysql.cursors.DictCursor
            )
            print("Успешное подключение к базе данных")
            return True
        except Error as e:
            print(f"Ошибка подключения к базе данных: {e}")
            return False

    def disconnect(self):
        if self.connection:
            self.connection.close()
            print("Отключение от базы данных")

    def authenticate_user(self, username, password):
        try:
            with self.connection.cursor() as cursor:
                sql = "SELECT * FROM users WHERE username = %s AND password = %s AND is_active = TRUE"
                cursor.execute(sql, (username, password))
                user = cursor.fetchone()
                return user
        except Error as e:
            print(f"Ошибка аутентификации: {e}")
            return None

    # Методы для работы с пациентами
    def get_patient_by_user_id(self, user_id):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                SELECT p.*, u.full_name, u.email, u.phone, u.birth_date, u.address,
                       DATE_FORMAT(u.birth_date, '%%Y-%%m-%%d') as birth_date_str,
                       DATE_FORMAT(u.registration_date, '%%Y-%%m-%%d') as registration_date_str
                FROM patients p
                JOIN users u ON p.user_id = u.id
                WHERE u.id = %s
                """
                cursor.execute(sql, (user_id,))
                patient = cursor.fetchone()
                return patient
        except Error as e:
            print(f"Ошибка при получении пациента: {e}")
            return None

    def get_all_patients(self):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                SELECT p.*, u.full_name, u.email, u.phone, u.birth_date, 
                       DATE_FORMAT(u.birth_date, '%%Y-%%m-%%d') as birth_date_str,
                       DATE_FORMAT(u.registration_date, '%%Y-%%m-%%d') as registration_date_str
                FROM patients p
                JOIN users u ON p.user_id = u.id
                WHERE u.role = 'patient'
                ORDER BY u.full_name
                """
                cursor.execute(sql)
                patients = cursor.fetchall()
                return patients
        except Error as e:
            print(f"Ошибка при получении пациентов: {e}")
            return []

    # Методы для работы с врачами
    def get_all_doctors(self):
        try:
            with self.connection.cursor() as cursor:
                sql = "SELECT * FROM doctors WHERE is_active = TRUE ORDER BY full_name"
                cursor.execute(sql)
                doctors = cursor.fetchall()

                # Преобразуем цену в float для удобства
                for doctor in doctors:
                    if 'price_per_appointment' in doctor:
                        doctor['price_per_appointment'] = float(doctor['price_per_appointment'])
                return doctors
        except Error as e:
            print(f"Ошибка при получении врачей: {e}")
            return []

    # Методы для работы со специальностями
    def get_all_specializations(self):
        try:
            with self.connection.cursor() as cursor:
                sql = "SELECT * FROM specializations ORDER BY specialization_name"
                cursor.execute(sql)
                return cursor.fetchall()
        except Error as e:
            print(f"Ошибка при получении специальностей: {e}")
            return []

    # Методы для работы с услугами
    def get_all_services(self):
        try:
            with self.connection.cursor() as cursor:
                sql = "SELECT * FROM services WHERE is_active = TRUE ORDER BY service_name"
                cursor.execute(sql)
                services = cursor.fetchall()

                # Преобразуем цену в float для удобства
                for service in services:
                    if 'price' in service:
                        service['price'] = float(service['price'])
                return services
        except Error as e:
            print(f"Ошибка при получении услуг: {e}")
            return []

    # Методы для работы с записями
    def get_patient_appointments(self, patient_id):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                SELECT a.*, 
                       d.full_name as doctor_name,
                       d.specialization as doctor_specialization,
                       d.office_number,
                       DATE(a.appointment_date) as appointment_date,
                       TIME(a.appointment_time) as appointment_time
                FROM appointments a
                JOIN doctors d ON a.doctor_id = d.id
                WHERE a.patient_id = %s
                ORDER BY a.appointment_date DESC, a.appointment_time DESC
                """
                cursor.execute(sql, (patient_id,))
                appointments = cursor.fetchall()

                # Преобразуем даты и цены
                for appointment in appointments:
                    # Обработка даты
                    if appointment.get('appointment_date'):
                        if hasattr(appointment['appointment_date'], 'strftime'):
                            appointment['appointment_date'] = appointment['appointment_date'].strftime('%Y-%m-%d')
                        elif isinstance(appointment['appointment_date'], str):
                            # Уже строка
                            pass
                        else:
                            appointment['appointment_date'] = str(appointment['appointment_date'])

                    # Обработка времени
                    if appointment.get('appointment_time'):
                        if hasattr(appointment['appointment_time'], 'strftime'):
                            appointment['appointment_time'] = appointment['appointment_time'].strftime('%H:%M')
                        elif isinstance(appointment['appointment_time'], timedelta):
                            total_seconds = int(appointment['appointment_time'].total_seconds())
                            hours = total_seconds // 3600
                            minutes = (total_seconds % 3600) // 60
                            appointment['appointment_time'] = f"{hours:02d}:{minutes:02d}"
                        elif isinstance(appointment['appointment_time'], str):
                            # Уже строка
                            pass
                        else:
                            appointment['appointment_time'] = str(appointment['appointment_time'])

                    # Обработка цены
                    if appointment.get('total_price') is not None:
                        try:
                            appointment['total_price'] = float(appointment['total_price'])
                        except (ValueError, TypeError):
                            appointment['total_price'] = 0.0
                    else:
                        appointment['total_price'] = 0.0
                return appointments
        except Error as e:
            print(f"Ошибка при получении записей пациента: {e}")
            return []

    def get_all_appointments(self):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                SELECT a.*, 
                       p.id as patient_id,
                       u.full_name as patient_name, 
                       u.phone as patient_phone,
                       d.full_name as doctor_name,
                       d.specialization as doctor_specialization,
                       DATE(a.appointment_date) as appointment_date,
                       TIME(a.appointment_time) as appointment_time
                FROM appointments a
                JOIN patients p ON a.patient_id = p.id
                JOIN users u ON p.user_id = u.id
                JOIN doctors d ON a.doctor_id = d.id
                ORDER BY a.appointment_date DESC, a.appointment_time DESC
                """
                cursor.execute(sql)
                appointments = cursor.fetchall()

                # Преобразуем даты и цены
                for appointment in appointments:
                    # Обработка даты
                    if appointment.get('appointment_date'):
                        if hasattr(appointment['appointment_date'], 'strftime'):
                            appointment['appointment_date'] = appointment['appointment_date'].strftime('%Y-%m-%d')
                        elif isinstance(appointment['appointment_date'], str):
                            # Уже строка
                            pass
                        else:
                            appointment['appointment_date'] = str(appointment['appointment_date'])

                    # Обработка времени
                    if appointment.get('appointment_time'):
                        if hasattr(appointment['appointment_time'], 'strftime'):
                            appointment['appointment_time'] = appointment['appointment_time'].strftime('%H:%M')
                        elif isinstance(appointment['appointment_time'], timedelta):
                            total_seconds = int(appointment['appointment_time'].total_seconds())
                            hours = total_seconds // 3600
                            minutes = (total_seconds % 3600) // 60
                            appointment['appointment_time'] = f"{hours:02d}:{minutes:02d}"
                        elif isinstance(appointment['appointment_time'], str):
                            # Уже строка
                            pass
                        else:
                            appointment['appointment_time'] = str(appointment['appointment_time'])

                    # Обработка цены
                    if appointment.get('total_price') is not None:
                        try:
                            appointment['total_price'] = float(appointment['total_price'])
                        except (ValueError, TypeError):
                            appointment['total_price'] = 0.0
                    else:
                        appointment['total_price'] = 0.0

                return appointments
        except Error as e:
            print(f"Ошибка при получении всех записей: {e}")
            return []

    def create_appointment(self, appointment_data):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                INSERT INTO appointments (
                    patient_id, doctor_id, appointment_date, appointment_time, 
                    duration_minutes, reason, symptoms, status, total_price, notes
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """
                cursor.execute(sql, appointment_data)
                self.connection.commit()
                return cursor.lastrowid
        except Error as e:
            print(f"Ошибка при создании записи: {e}")
            return None

    def update_appointment(self, appointment_id, update_data):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                UPDATE appointments SET 
                    doctor_id = %s,
                    appointment_date = %s,
                    appointment_time = %s,
                    duration_minutes = %s,
                    reason = %s,
                    status = %s,
                    total_price = %s,
                    notes = %s
                WHERE id = %s
                """
                cursor.execute(sql, (*update_data, appointment_id))
                self.connection.commit()
                return cursor.rowcount > 0
        except Error as e:
            print(f"Ошибка при обновлении записи: {e}")
            return False

    def delete_appointment(self, appointment_id):
        try:
            with self.connection.cursor() as cursor:
                sql = "DELETE FROM appointments WHERE id = %s"
                cursor.execute(sql, (appointment_id,))
                self.connection.commit()
                return cursor.rowcount > 0
        except Error as e:
            print(f"Ошибка при удалении записи: {e}")
            return False

    def check_time_availability(self, doctor_id, appointment_date, appointment_time, duration_minutes):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                SELECT COUNT(*) as count
                FROM appointments 
                WHERE doctor_id = %s 
                AND appointment_date = %s 
                AND status = 'scheduled'
                AND (
                    (appointment_time <= %s AND 
                     ADDTIME(appointment_time, SEC_TO_TIME(%s * 60)) > %s)
                    OR (appointment_time < ADDTIME(%s, SEC_TO_TIME(%s * 60)) AND 
                        ADDTIME(appointment_time, SEC_TO_TIME(duration_minutes * 60)) > %s)
                )
                """
                cursor.execute(sql, (doctor_id, appointment_date,
                                     appointment_time, duration_minutes, appointment_time,
                                     appointment_time, duration_minutes, appointment_time))
                result = cursor.fetchone()
                return result['count'] == 0
        except Error as e:
            print(f"Ошибка при проверке доступности времени: {e}")
            return False

    # Методы для регистрации новых пользователей
    def register_patient(self, user_data, patient_data):
        try:
            with self.connection.cursor() as cursor:
                # Создаем пользователя
                user_sql = """
                INSERT INTO users (username, password, full_name, role, email, phone, birth_date)
                VALUES (%s, %s, %s, 'patient', %s, %s, %s)
                """
                cursor.execute(user_sql, user_data)
                user_id = cursor.lastrowid

                # Создаем пациента
                patient_sql = """
                INSERT INTO patients (user_id, medical_card_number, insurance_policy, 
                                    blood_type, allergies, chronic_diseases)
                VALUES (%s, %s, %s, %s, %s, %s)
                """
                cursor.execute(patient_sql, (user_id, *patient_data))

                self.connection.commit()
                return user_id
        except Error as e:
            print(f"Ошибка при регистрации пациента: {e}")
            return None

    def add_doctor(self, doctor_data):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                INSERT INTO doctors (full_name, specialization, qualification, 
                                   phone, email, office_number, work_schedule, 
                                   experience_years, price_per_appointment)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                """
                cursor.execute(sql, doctor_data)
                self.connection.commit()
                return cursor.lastrowid
        except Error as e:
            print(f"Ошибка при добавлении врача: {e}")
            return None

    def get_doctor_by_id(self, doctor_id):
        try:
            with self.connection.cursor() as cursor:
                sql = "SELECT * FROM doctors WHERE id = %s"
                cursor.execute(sql, (doctor_id,))
                doctor = cursor.fetchone()
                if doctor and 'price_per_appointment' in doctor:
                    doctor['price_per_appointment'] = float(doctor['price_per_appointment'])
                return doctor
        except Error as e:
            print(f"Ошибка при получении врача: {e}")
            return None