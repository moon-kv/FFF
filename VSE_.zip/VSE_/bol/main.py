

import sys
import traceback
from PyQt6.QtWidgets import QApplication
from PyQt6.QtCore import Qt
from database import Database
from auth_window import AuthWindow
from admin_panel import AdminPanel
from client_panel import ClientPanel


def excepthook(exctype, value, tb):
    """Обработчик необработанных исключений"""
    print("Произошла ошибка:")
    traceback.print_exception(exctype, value, tb)
    sys.exit(1)


class HospitalSystem:
    def __init__(self):
        self.db = Database()
        sys.excepthook = excepthook

        # Устанавливаем высокий DPI масштабирование для Windows
        QApplication.setHighDpiScaleFactorRoundingPolicy(
            Qt.HighDpiScaleFactorRoundingPolicy.PassThrough
        )

        self.app = QApplication(sys.argv)
        self.app.setStyle('Fusion')  # Более стабильный стиль

    def run(self):
        # Подключаемся к базе данных
        if not self.db.connect():
            print("Не удалось подключиться к базе данных")
            sys.exit(1)

        try:
            # Показываем окно авторизации
            auth_window = AuthWindow(self.db, self.on_auth_success)
            auth_window.show()

            sys.exit(self.app.exec())
        except Exception as e:
            print(f"Ошибка при запуске приложения: {e}")
            traceback.print_exc()
            sys.exit(1)

    def on_auth_success(self, user):
        try:
            # Открываем соответствующую панель в зависимости от роли
            if user['role'] == 'admin':
                self.admin_panel = AdminPanel(self.db, user)
                self.admin_panel.show()
            elif user['role'] == 'patient':
                self.client_panel = ClientPanel(self.db, user)
                self.client_panel.show()
            else:
                print(f"Неизвестная роль: {user['role']}")
        except Exception as e:
            print(f"Ошибка при открытии панели: {e}")
            traceback.print_exc()


if __name__ == "__main__":
    print("Запуск системы управления больницы...")
    system = HospitalSystem()
    system.run()