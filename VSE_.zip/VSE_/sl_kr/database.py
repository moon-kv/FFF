import pymysql
from pymysql import Error
from datetime import datetime, timedelta


class Database:
    def __init__(self):
        self.host = "localhost"
        self.user = "root"
        self.password = "dn260306"  # Измените на ваш пароль MySQL
        self.database = "beauty_salon"
        self.charset = "utf8mb4"
        self.connection = None

    def connect(self):
        try:
            self.connection = pymysql.connect(
                host=self.host,
                user=self.user,
                password=self.password,
                database=self.database,
                charset=self.charset,
                cursorclass=pymysql.cursors.DictCursor
            )
            print("Успешное подключение к базе данных")
            return True
        except Error as e:
            print(f"Ошибка подключения к базе данных: {e}")
            return False

    def disconnect(self):
        if self.connection:
            self.connection.close()
            print("Отключение от базы данных")

    def authenticate_user(self, username, password):
        try:
            with self.connection.cursor() as cursor:
                sql = "SELECT * FROM users WHERE username = %s AND password = %s"
                cursor.execute(sql, (username, password))
                user = cursor.fetchone()
                return user
        except Error as e:
            print(f"Ошибка аутентификации: {e}")
            return None

    def get_client_appointments(self, client_id):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                SELECT a.*, 
                       m.full_name as master_name,
                       m.specialization as master_specialization,
                       s.service_name,
                       s.price as service_price
                FROM appointments a
                JOIN masters m ON a.master_id = m.id
                JOIN services s ON a.service_id = s.id
                WHERE a.client_id = %s
                ORDER BY a.appointment_date DESC, a.appointment_time DESC
                """
                cursor.execute(sql, (client_id,))
                appointments = cursor.fetchall()

                for appointment in appointments:
                    if appointment.get('appointment_date'):
                        appointment['appointment_date'] = appointment['appointment_date'].strftime('%Y-%m-%d')
                    if appointment.get('appointment_time'):
                        # Преобразуем timedelta в строку времени
                        time_delta = appointment['appointment_time']
                        total_seconds = int(time_delta.total_seconds())
                        hours = total_seconds // 3600
                        minutes = (total_seconds % 3600) // 60
                        appointment['appointment_time'] = f"{hours:02d}:{minutes:02d}"
                return appointments
        except Error as e:
            print(f"Ошибка при получении записей клиента: {e}")
            return []

    # Методы для работы с клиентами
    def get_client_by_user_id(self, user_id):
        try:
            with self.connection.cursor() as cursor:
                sql = "SELECT * FROM clients WHERE user_id = %s"
                cursor.execute(sql, (user_id,))
                client = cursor.fetchone()

                if client and client.get('birth_date'):
                    client['birth_date'] = client['birth_date'].strftime('%Y-%m-%d')
                if client and client.get('registration_date'):
                    client['registration_date'] = client['registration_date'].strftime('%Y-%m-%d')
                return client
        except Error as e:
            print(f"Ошибка при получении клиента: {e}")
            return None

    def get_all_clients(self):
        try:
            with self.connection.cursor() as cursor:
                sql = "SELECT * FROM clients ORDER BY full_name"
                cursor.execute(sql)
                clients = cursor.fetchall()

                for client in clients:
                    if client.get('birth_date'):
                        client['birth_date'] = client['birth_date'].strftime('%Y-%m-%d')
                    if client.get('registration_date'):
                        client['registration_date'] = client['registration_date'].strftime('%Y-%m-%d')
                return clients
        except Error as e:
            print(f"Ошибка при получении клиентов: {e}")
            return []

    # Методы для работы с мастерами
    def get_all_masters(self):
        try:
            with self.connection.cursor() as cursor:
                sql = "SELECT * FROM masters WHERE is_active = TRUE ORDER BY full_name"
                cursor.execute(sql)
                return cursor.fetchall()
        except Error as e:
            print(f"Ошибка при получении мастеров: {e}")
            return []

    # Методы для работы с услугами
    def get_all_services(self):
        try:
            with self.connection.cursor() as cursor:
                sql = "SELECT * FROM services WHERE is_active = TRUE ORDER BY service_name"
                cursor.execute(sql)
                return cursor.fetchall()
        except Error as e:
            print(f"Ошибка при получении услуг: {e}")
            return []

    # Методы для работы с записями
    def get_appointments_by_period(self, start_date, end_date):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                SELECT a.*, 
                       c.full_name as client_name, 
                       c.phone as client_phone,
                       m.full_name as master_name,
                       m.specialization as master_specialization,
                       s.service_name,
                       s.price as service_price
                FROM appointments a
                JOIN clients c ON a.client_id = c.id
                JOIN masters m ON a.master_id = m.id
                JOIN services s ON a.service_id = s.id
                WHERE a.appointment_date BETWEEN %s AND %s
                ORDER BY a.appointment_date, a.appointment_time
                """
                cursor.execute(sql, (start_date, end_date))
                appointments = cursor.fetchall()

                for appointment in appointments:
                    if appointment.get('appointment_date'):
                        appointment['appointment_date'] = appointment['appointment_date'].strftime('%Y-%m-%d')
                    if appointment.get('appointment_time'):
                        # Преобразуем timedelta в строку времени
                        time_delta = appointment['appointment_time']
                        total_seconds = int(time_delta.total_seconds())
                        hours = total_seconds // 3600
                        minutes = (total_seconds % 3600) // 60
                        appointment['appointment_time'] = f"{hours:02d}:{minutes:02d}"
                return appointments
        except Error as e:
            print(f"Ошибка при получении записей: {e}")
            return []

    def get_appointments_by_service(self, service_id):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                SELECT a.*, 
                       c.full_name as client_name, 
                       c.phone as client_phone,
                       m.full_name as master_name,
                       m.specialization as master_specialization,
                       s.service_name,
                       s.price as service_price
                FROM appointments a
                JOIN clients c ON a.client_id = c.id
                JOIN masters m ON a.master_id = m.id
                JOIN services s ON a.service_id = s.id
                WHERE a.service_id = %s
                ORDER BY a.appointment_date DESC
                """
                cursor.execute(sql, (service_id,))
                appointments = cursor.fetchall()

                for appointment in appointments:
                    if appointment.get('appointment_date'):
                        appointment['appointment_date'] = appointment['appointment_date'].strftime('%Y-%m-%d')
                    if appointment.get('appointment_time'):
                        # Преобразуем timedelta в строку времени
                        time_delta = appointment['appointment_time']
                        total_seconds = int(time_delta.total_seconds())
                        hours = total_seconds // 3600
                        minutes = (total_seconds % 3600) // 60
                        appointment['appointment_time'] = f"{hours:02d}:{minutes:02d}"
                return appointments
        except Error as e:
            print(f"Ошибка при получении записей по услуге: {e}")
            return []

    def get_all_appointments(self):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                SELECT a.*, 
                       c.full_name as client_name, 
                       c.phone as client_phone,
                       m.full_name as master_name,
                       m.specialization as master_specialization,
                       s.service_name,
                       s.price as service_price
                FROM appointments a
                JOIN clients c ON a.client_id = c.id
                JOIN masters m ON a.master_id = m.id
                JOIN services s ON a.service_id = s.id
                ORDER BY a.appointment_date DESC, a.appointment_time DESC
                """
                cursor.execute(sql)
                appointments = cursor.fetchall()

                for appointment in appointments:
                    if appointment.get('appointment_date'):
                        appointment['appointment_date'] = appointment['appointment_date'].strftime('%Y-%m-%d')
                    if appointment.get('appointment_time'):
                        # Преобразуем timedelta в строку времени
                        time_delta = appointment['appointment_time']
                        # Получаем общее количество секунд
                        total_seconds = int(time_delta.total_seconds())
                        # Преобразуем в часы и минуты
                        hours = total_seconds // 3600
                        minutes = (total_seconds % 3600) // 60
                        appointment['appointment_time'] = f"{hours:02d}:{minutes:02d}"
                return appointments
        except Error as e:
            print(f"Ошибка при получении всех записей: {e}")
            return []

    def create_appointment(self, appointment_data):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                INSERT INTO appointments (
                    client_id, master_id, service_id, 
                    appointment_date, appointment_time, 
                    duration_minutes, total_price, status, notes
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                """
                cursor.execute(sql, appointment_data)
                self.connection.commit()
                return cursor.lastrowid
        except Error as e:
            print(f"Ошибка при создании записи: {e}")
            return None

    def update_appointment(self, appointment_id, update_data):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                UPDATE appointments SET 
                    master_id = %s,
                    service_id = %s,
                    appointment_date = %s,
                    appointment_time = %s,
                    duration_minutes = %s,
                    total_price = %s,
                    status = %s,
                    notes = %s
                WHERE id = %s
                """
                cursor.execute(sql, (*update_data, appointment_id))
                self.connection.commit()
                return cursor.rowcount > 0
        except Error as e:
            print(f"Ошибка при обновлении записи: {e}")
            return False

    def delete_appointment(self, appointment_id):
        try:
            with self.connection.cursor() as cursor:
                sql = "DELETE FROM appointments WHERE id = %s"
                cursor.execute(sql, (appointment_id,))
                self.connection.commit()
                return cursor.rowcount > 0
        except Error as e:
            print(f"Ошибка при удалении записи: {e}")
            return False

    def check_time_availability(self, master_id, appointment_date, appointment_time, duration_minutes):
        try:
            with self.connection.cursor() as cursor:
                # Преобразуем время из строки в секунды для сравнения
                time_parts = appointment_time.split(':')
                appointment_seconds = int(time_parts[0]) * 3600 + int(time_parts[1]) * 60

                sql = """
                SELECT COUNT(*) as count
                FROM appointments 
                WHERE master_id = %s 
                AND appointment_date = %s 
                AND status = 'scheduled'
                AND (
                    (TIME_TO_SEC(appointment_time) <= %s AND 
                     TIME_TO_SEC(appointment_time) + (duration_minutes * 60) > %s)
                    OR (TIME_TO_SEC(appointment_time) < %s + (%s * 60) AND 
                        TIME_TO_SEC(appointment_time) + (duration_minutes * 60) > %s)
                )
                """
                cursor.execute(sql, (master_id, appointment_date,
                                     appointment_seconds, appointment_seconds,
                                     appointment_seconds, duration_minutes, appointment_seconds))
                result = cursor.fetchone()
                return result['count'] == 0
        except Error as e:
            print(f"Ошибка при проверке доступности времени: {e}")
            return False