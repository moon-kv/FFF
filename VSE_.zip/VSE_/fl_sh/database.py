import pymysql
from pymysql import Error
from datetime import datetime, timedelta


class Database:
    def __init__(self):
        self.host = "localhost"
        self.user = "root"
        self.password = "dn260306"  # Ваш пароль MySQL
        self.database = "flower_shop"
        self.charset = "utf8mb4"
        self.connection = None

    def connect(self):
        try:
            self.connection = pymysql.connect(
                host=self.host,
                user=self.user,
                password=self.password,
                database=self.database,
                charset=self.charset,
                cursorclass=pymysql.cursors.DictCursor
            )
            print("Успешное подключение к базе данных цветочного магазина")
            return True
        except Error as e:
            print(f"Ошибка подключения к базе данных: {e}")
            return False

    def disconnect(self):
        if self.connection:
            self.connection.close()
            print("Отключение от базы данных")

    def authenticate_user(self, username, password):
        try:
            with self.connection.cursor() as cursor:
                sql = "SELECT * FROM users WHERE username = %s AND password = %s"
                cursor.execute(sql, (username, password))
                user = cursor.fetchone()
                return user
        except Error as e:
            print(f"Ошибка аутентификации: {e}")
            return None

    # Методы для работы с клиентами
    def get_client_by_user_id(self, user_id):
        try:
            with self.connection.cursor() as cursor:
                sql = "SELECT * FROM clients WHERE user_id = %s"
                cursor.execute(sql, (user_id,))
                client = cursor.fetchone()
                return client
        except Error as e:
            print(f"Ошибка при получении клиента: {e}")
            return None

    def get_all_clients(self):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                SELECT c.*, u.email as user_email, u.username as user_username 
                FROM clients c
                LEFT JOIN users u ON c.user_id = u.id
                ORDER BY c.full_name
                """
                cursor.execute(sql)
                clients = cursor.fetchall()
                return clients
        except Error as e:
            print(f"Ошибка при получении клиентов: {e}")
            return []

    def create_client(self, client_data):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                INSERT INTO clients (user_id, full_name, phone, email, address, registration_date, created_by_admin, notes)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                """
                cursor.execute(sql, client_data)
                self.connection.commit()
                return cursor.lastrowid
        except Error as e:
            print(f"Ошибка при создании клиента: {e}")
            return None

    # Методы для работы с флористами
    def get_all_florists(self):
        try:
            with self.connection.cursor() as cursor:
                sql = "SELECT * FROM florists WHERE is_active = TRUE ORDER BY full_name"
                cursor.execute(sql)
                return cursor.fetchall()
        except Error as e:
            print(f"Ошибка при получении флористов: {e}")
            return []

    def create_florist(self, florist_data):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                INSERT INTO florists (full_name, specialization, phone, email, experience_years, work_schedule, is_active)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
                """
                cursor.execute(sql, florist_data)
                self.connection.commit()
                return cursor.lastrowid
        except Error as e:
            print(f"Ошибка при создании флориста: {e}")
            return None

    # Методы для работы с букетами
    def get_all_bouquets(self):
        try:
            with self.connection.cursor() as cursor:
                sql = "SELECT * FROM bouquets WHERE is_available = TRUE ORDER BY name"
                cursor.execute(sql)
                return cursor.fetchall()
        except Error as e:
            print(f"Ошибка при получении букетов: {e}")
            return []

    def create_bouquet(self, bouquet_data):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                INSERT INTO bouquets (name, description, price, composition, category, seasonality, is_available)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
                """
                cursor.execute(sql, bouquet_data)
                self.connection.commit()
                return cursor.lastrowid
        except Error as e:
            print(f"Ошибка при создании букета: {e}")
            return None

    # Методы для работы с заказами
    def get_client_orders(self, client_id):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                SELECT o.*, 
                       b.name as bouquet_name,
                       b.price as bouquet_price,
                       b.description as bouquet_description,
                       b.composition as bouquet_composition,
                       f.full_name as florist_name
                FROM orders o
                JOIN bouquets b ON o.bouquet_id = b.id
                LEFT JOIN florists f ON o.florist_id = f.id
                WHERE o.client_id = %s
                ORDER BY o.order_date DESC, o.delivery_date DESC
                """
                cursor.execute(sql, (client_id,))
                orders = cursor.fetchall()

                # Преобразуем даты в строки
                for order in orders:
                    if order.get('order_date'):
                        order['order_date'] = order['order_date'].strftime('%Y-%m-%d')
                    if order.get('delivery_date'):
                        order['delivery_date'] = order['delivery_date'].strftime('%Y-%m-%d')
                    if order.get('delivery_time'):
                        # Преобразуем timedelta в строку времени
                        if isinstance(order['delivery_time'], timedelta):
                            total_seconds = int(order['delivery_time'].total_seconds())
                            hours = total_seconds // 3600
                            minutes = (total_seconds % 3600) // 60
                            order['delivery_time'] = f"{hours:02d}:{minutes:02d}"
                        else:
                            order['delivery_time'] = str(order['delivery_time'])

                return orders
        except Error as e:
            print(f"Ошибка при получении заказов клиента: {e}")
            return []

    def get_all_orders(self):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                SELECT o.*, 
                       c.full_name as client_name, 
                       c.phone as client_phone,
                       c.email as client_email,
                       b.name as bouquet_name,
                       b.price as bouquet_price,
                       f.full_name as florist_name
                FROM orders o
                JOIN clients c ON o.client_id = c.id
                JOIN bouquets b ON o.bouquet_id = b.id
                LEFT JOIN florists f ON o.florist_id = f.id
                ORDER BY o.order_date DESC, o.delivery_date DESC
                """
                cursor.execute(sql)
                orders = cursor.fetchall()

                # Преобразуем даты в строки
                for order in orders:
                    if order.get('order_date'):
                        order['order_date'] = order['order_date'].strftime('%Y-%m-%d')
                    if order.get('delivery_date'):
                        order['delivery_date'] = order['delivery_date'].strftime('%Y-%m-%d')
                    if order.get('delivery_time'):
                        # Преобразуем timedelta в строку времени
                        if isinstance(order['delivery_time'], timedelta):
                            total_seconds = int(order['delivery_time'].total_seconds())
                            hours = total_seconds // 3600
                            minutes = (total_seconds % 3600) // 60
                            order['delivery_time'] = f"{hours:02d}:{minutes:02d}"
                        else:
                            order['delivery_time'] = str(order['delivery_time'])

                return orders
        except Error as e:
            print(f"Ошибка при получении всех заказов: {e}")
            return []

    def get_orders_by_period(self, start_date, end_date):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                SELECT o.*, 
                       c.full_name as client_name, 
                       c.phone as client_phone,
                       b.name as bouquet_name,
                       b.price as bouquet_price,
                       f.full_name as florist_name
                FROM orders o
                JOIN clients c ON o.client_id = c.id
                JOIN bouquets b ON o.bouquet_id = b.id
                LEFT JOIN florists f ON o.florist_id = f.id
                WHERE o.order_date BETWEEN %s AND %s
                ORDER BY o.order_date, o.delivery_time
                """
                cursor.execute(sql, (start_date, end_date))
                orders = cursor.fetchall()

                # Преобразуем даты в строки
                for order in orders:
                    if order.get('order_date'):
                        order['order_date'] = order['order_date'].strftime('%Y-%m-%d')
                    if order.get('delivery_date'):
                        order['delivery_date'] = order['delivery_date'].strftime('%Y-%m-%d')
                    if order.get('delivery_time'):
                        if isinstance(order['delivery_time'], timedelta):
                            total_seconds = int(order['delivery_time'].total_seconds())
                            hours = total_seconds // 3600
                            minutes = (total_seconds % 3600) // 60
                            order['delivery_time'] = f"{hours:02d}:{minutes:02d}"
                        else:
                            order['delivery_time'] = str(order['delivery_time'])

                return orders
        except Error as e:
            print(f"Ошибка при получении заказов по периоду: {e}")
            return []

    def get_orders_by_status(self, status):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                SELECT o.*, 
                       c.full_name as client_name, 
                       c.phone as client_phone,
                       b.name as bouquet_name,
                       b.price as bouquet_price,
                       f.full_name as florist_name
                FROM orders o
                JOIN clients c ON o.client_id = c.id
                JOIN bouquets b ON o.bouquet_id = b.id
                LEFT JOIN florists f ON o.florist_id = f.id
                WHERE o.status = %s
                ORDER BY o.delivery_date, o.delivery_time
                """
                cursor.execute(sql, (status,))
                orders = cursor.fetchall()

                # Преобразуем даты в строки
                for order in orders:
                    if order.get('order_date'):
                        order['order_date'] = order['order_date'].strftime('%Y-%m-%d')
                    if order.get('delivery_date'):
                        order['delivery_date'] = order['delivery_date'].strftime('%Y-%m-%d')
                    if order.get('delivery_time'):
                        if isinstance(order['delivery_time'], timedelta):
                            total_seconds = int(order['delivery_time'].total_seconds())
                            hours = total_seconds // 3600
                            minutes = (total_seconds % 3600) // 60
                            order['delivery_time'] = f"{hours:02d}:{minutes:02d}"
                        else:
                            order['delivery_time'] = str(order['delivery_time'])

                return orders
        except Error as e:
            print(f"Ошибка при получении заказов по статусу: {e}")
            return []

    def create_order(self, order_data):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                INSERT INTO orders (
                    client_id, bouquet_id, florist_id, order_date, 
                    delivery_date, delivery_time, delivery_address,
                    quantity, total_price, status, payment_method, 
                    payment_status, notes
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """
                cursor.execute(sql, order_data)
                self.connection.commit()
                return cursor.lastrowid
        except Error as e:
            print(f"Ошибка при создании заказа: {e}")
            return None

    def update_order(self, order_id, update_data):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                UPDATE orders SET 
                    bouquet_id = %s,
                    florist_id = %s,
                    delivery_date = %s,
                    delivery_time = %s,
                    delivery_address = %s,
                    quantity = %s,
                    total_price = %s,
                    status = %s,
                    payment_method = %s,
                    payment_status = %s,
                    notes = %s
                WHERE id = %s
                """
                cursor.execute(sql, (*update_data, order_id))
                self.connection.commit()
                return cursor.rowcount > 0
        except Error as e:
            print(f"Ошибка при обновлении заказа: {e}")
            return False

    def delete_order(self, order_id):
        try:
            with self.connection.cursor() as cursor:
                sql = "DELETE FROM orders WHERE id = %s"
                cursor.execute(sql, (order_id,))
                self.connection.commit()
                return cursor.rowcount > 0
        except Error as e:
            print(f"Ошибка при удалении заказа: {e}")
            return False

    # Методы для работы с пользователями
    def create_user(self, user_data):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                INSERT INTO users (username, password, full_name, role, phone, email, is_active)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
                """
                cursor.execute(sql, user_data)
                self.connection.commit()
                return cursor.lastrowid
        except Error as e:
            print(f"Ошибка при создании пользователя: {e}")
            return None

    def get_user_by_username(self, username):
        try:
            with self.connection.cursor() as cursor:
                sql = "SELECT * FROM users WHERE username = %s"
                cursor.execute(sql, (username,))
                return cursor.fetchone()
        except Error as e:
            print(f"Ошибка при получении пользователя: {e}")
            return None

    # Метод для получения статистики
    def get_statistics(self):
        try:
            with self.connection.cursor() as cursor:
                stats = {}

                # Общее количество заказов
                sql = "SELECT COUNT(*) as total_orders FROM orders"
                cursor.execute(sql)
                stats['total_orders'] = cursor.fetchone()['total_orders']

                # Заказы по статусам
                sql = "SELECT status, COUNT(*) as count FROM orders GROUP BY status"
                cursor.execute(sql)
                stats['orders_by_status'] = cursor.fetchall()

                # Количество клиентов
                sql = "SELECT COUNT(*) as total_clients FROM clients"
                cursor.execute(sql)
                stats['total_clients'] = cursor.fetchone()['total_clients']

                # Количество флористов
                sql = "SELECT COUNT(*) as total_florists FROM florists WHERE is_active = TRUE"
                cursor.execute(sql)
                stats['total_florists'] = cursor.fetchone()['total_florists']

                # Общая выручка
                sql = "SELECT SUM(total_price) as total_revenue FROM orders WHERE payment_status = 'paid'"
                cursor.execute(sql)
                stats['total_revenue'] = cursor.fetchone()['total_revenue'] or 0

                return stats
        except Error as e:
            print(f"Ошибка при получении статистики: {e}")
            return {}