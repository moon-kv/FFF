import pymysql
from pymysql import Error
from datetime import datetime, timedelta


class Database:
    def __init__(self):
        self.host = "localhost"
        self.user = "root"
        self.password = "dn260306"
        self.database = "autosalon_db"
        self.charset = "utf8mb4"
        self.connection = None

    def connect(self):
        try:
            self.connection = pymysql.connect(
                host=self.host,
                user=self.user,
                password=self.password,
                database=self.database,
                charset=self.charset,
                cursorclass=pymysql.cursors.DictCursor
            )
            print("Успешное подключение к базе данных")
            return True
        except Error as e:
            print(f"Ошибка подключения к базе данных: {e}")
            return False

    def disconnect(self):
        if self.connection:
            self.connection.close()
            print("Отключение от базы данных")

    def authenticate_user(self, username, password):
        try:
            with self.connection.cursor() as cursor:
                sql = "SELECT * FROM users WHERE username = %s AND password = %s AND is_active = TRUE"
                cursor.execute(sql, (username, password))
                user = cursor.fetchone()
                return user
        except Error as e:
            print(f"Ошибка аутентификации: {e}")
            return None

    # Работа с клиентами
    def get_client_by_user_id(self, user_id):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                SELECT c.*, u.full_name, u.email, u.phone, u.birth_date, u.address,
                       DATE_FORMAT(u.birth_date, '%%Y-%%m-%%d') as birth_date_str,
                       DATE_FORMAT(u.registration_date, '%%Y-%%m-%%d') as registration_date_str
                FROM clients c
                JOIN users u ON c.user_id = u.id
                WHERE u.id = %s
                """
                cursor.execute(sql, (user_id,))
                client = cursor.fetchone()
                return client
        except Error as e:
            print(f"Ошибка при получении клиента: {e}")
            return None

    def get_all_clients(self):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                SELECT c.*, u.full_name, u.email, u.phone, u.birth_date, 
                       DATE_FORMAT(u.birth_date, '%%Y-%%m-%%d') as birth_date_str,
                       DATE_FORMAT(u.registration_date, '%%Y-%%m-%%d') as registration_date_str
                FROM clients c
                JOIN users u ON c.user_id = u.id
                WHERE u.role = 'client'
                ORDER BY u.full_name
                """
                cursor.execute(sql)
                clients = cursor.fetchall()
                return clients
        except Error as e:
            print(f"Ошибка при получении клиентов: {e}")
            return []

    # Работа с автомобилями клиентов
    def get_client_cars(self, client_id):
        try:
            with self.connection.cursor() as cursor:
                sql = "SELECT * FROM cars WHERE client_id = %s ORDER BY brand, model"
                cursor.execute(sql, (client_id,))
                cars = cursor.fetchall()
                return cars
        except Error as e:
            print(f"Ошибка при получении автомобилей клиента: {e}")
            return []

    def get_all_cars(self):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                SELECT c.*, cl.id as client_id, u.full_name as client_name
                FROM cars c
                JOIN clients cl ON c.client_id = cl.id
                JOIN users u ON cl.user_id = u.id
                ORDER BY u.full_name, c.brand, c.model
                """
                cursor.execute(sql)
                cars = cursor.fetchall()
                return cars
        except Error as e:
            print(f"Ошибка при получении всех автомобилей: {e}")
            return []

    def add_client_car(self, car_data):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                INSERT INTO cars (
                    client_id, brand, model, year, license_plate, vin, 
                    engine_volume, fuel_type, transmission, mileage, color
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """
                cursor.execute(sql, car_data)
                self.connection.commit()
                return cursor.lastrowid
        except Error as e:
            print(f"Ошибка при добавлении автомобиля клиента: {e}")
            return None

    # Работа с мастерами
    def get_all_masters(self):
        try:
            with self.connection.cursor() as cursor:
                sql = "SELECT * FROM masters WHERE is_active = TRUE ORDER BY full_name"
                cursor.execute(sql)
                masters = cursor.fetchall()

                for master in masters:
                    if 'hourly_rate' in master:
                        master['hourly_rate'] = float(master['hourly_rate'])
                return masters
        except Error as e:
            print(f"Ошибка при получении мастеров: {e}")
            return []

    def get_master_by_id(self, master_id):
        try:
            with self.connection.cursor() as cursor:
                sql = "SELECT * FROM masters WHERE id = %s"
                cursor.execute(sql, (master_id,))
                master = cursor.fetchone()
                if master and 'hourly_rate' in master:
                    master['hourly_rate'] = float(master['hourly_rate'])
                return master
        except Error as e:
            print(f"Ошибка при получении мастера: {e}")
            return None

    # Работа с услугами
    def get_all_services(self):
        try:
            with self.connection.cursor() as cursor:
                sql = "SELECT * FROM services WHERE is_active = TRUE ORDER BY service_name"
                cursor.execute(sql)
                services = cursor.fetchall()

                for service in services:
                    if 'price' in service:
                        service['price'] = float(service['price'])
                return services
        except Error as e:
            print(f"Ошибка при получении услуг: {e}")
            return []

    def get_service_by_id(self, service_id):
        try:
            with self.connection.cursor() as cursor:
                sql = "SELECT * FROM services WHERE id = %s"
                cursor.execute(sql, (service_id,))
                service = cursor.fetchone()
                if service and 'price' in service:
                    service['price'] = float(service['price'])
                return service
        except Error as e:
            print(f"Ошибка при получении услуги: {e}")
            return None

    # Работа с записями на сервис
    def get_client_service_appointments(self, client_id):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                SELECT sa.*, 
                       m.full_name as master_name,
                       m.specialization as master_specialization,
                       c.brand as car_brand,
                       c.model as car_model,
                       c.license_plate,
                       s.service_name,
                       DATE(sa.appointment_date) as appointment_date,
                       TIME(sa.appointment_time) as appointment_time
                FROM service_appointments sa
                JOIN masters m ON sa.master_id = m.id
                JOIN cars c ON sa.car_id = c.id
                JOIN services s ON sa.service_id = s.id
                WHERE sa.client_id = %s
                ORDER BY sa.appointment_date DESC, sa.appointment_time DESC
                """
                cursor.execute(sql, (client_id,))
                appointments = cursor.fetchall()

                for appointment in appointments:
                    if appointment.get('appointment_date'):
                        if hasattr(appointment['appointment_date'], 'strftime'):
                            appointment['appointment_date'] = appointment['appointment_date'].strftime('%Y-%m-%d')

                    if appointment.get('appointment_time'):
                        if hasattr(appointment['appointment_time'], 'strftime'):
                            appointment['appointment_time'] = appointment['appointment_time'].strftime('%H:%M')
                        elif isinstance(appointment['appointment_time'], timedelta):
                            total_seconds = int(appointment['appointment_time'].total_seconds())
                            hours = total_seconds // 3600
                            minutes = (total_seconds % 3600) // 60
                            appointment['appointment_time'] = f"{hours:02d}:{minutes:02d}"

                    if 'total_price' in appointment:
                        appointment['total_price'] = float(appointment['total_price'])
                return appointments
        except Error as e:
            print(f"Ошибка при получении записей клиента: {e}")
            return []

    def get_all_service_appointments(self):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                SELECT sa.*, 
                       cl.id as client_id,
                       u.full_name as client_name, 
                       u.phone as client_phone,
                       m.full_name as master_name,
                       m.specialization as master_specialization,
                       ca.brand as car_brand,
                       ca.model as car_model,
                       ca.license_plate,
                       s.service_name,
                       DATE(sa.appointment_date) as appointment_date,
                       TIME(sa.appointment_time) as appointment_time
                FROM service_appointments sa
                JOIN clients cl ON sa.client_id = cl.id
                JOIN users u ON cl.user_id = u.id
                JOIN masters m ON sa.master_id = m.id
                JOIN cars ca ON sa.car_id = ca.id
                JOIN services s ON sa.service_id = s.id
                ORDER BY sa.appointment_date DESC, sa.appointment_time DESC
                """
                cursor.execute(sql)
                appointments = cursor.fetchall()

                for appointment in appointments:
                    if appointment.get('appointment_date'):
                        if hasattr(appointment['appointment_date'], 'strftime'):
                            appointment['appointment_date'] = appointment['appointment_date'].strftime('%Y-%m-%d')

                    if appointment.get('appointment_time'):
                        if hasattr(appointment['appointment_time'], 'strftime'):
                            appointment['appointment_time'] = appointment['appointment_time'].strftime('%H:%M')
                        elif isinstance(appointment['appointment_time'], timedelta):
                            total_seconds = int(appointment['appointment_time'].total_seconds())
                            hours = total_seconds // 3600
                            minutes = (total_seconds % 3600) // 60
                            appointment['appointment_time'] = f"{hours:02d}:{minutes:02d}"

                    if 'total_price' in appointment:
                        appointment['total_price'] = float(appointment['total_price'])
                return appointments
        except Error as e:
            print(f"Ошибка при получении всех записей: {e}")
            return []

    def create_service_appointment(self, appointment_data):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                INSERT INTO service_appointments (
                    client_id, master_id, car_id, service_id, appointment_date, appointment_time,
                    duration_hours, problem_description, status, total_price, notes
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """
                cursor.execute(sql, appointment_data)
                self.connection.commit()
                return cursor.lastrowid
        except Error as e:
            print(f"Ошибка при создании записи: {e}")
            return None

    def update_service_appointment(self, appointment_id, update_data):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                UPDATE service_appointments SET 
                    master_id = %s,
                    car_id = %s,
                    service_id = %s,
                    appointment_date = %s,
                    appointment_time = %s,
                    duration_hours = %s,
                    problem_description = %s,
                    status = %s,
                    total_price = %s,
                    notes = %s
                WHERE id = %s
                """
                cursor.execute(sql, (*update_data, appointment_id))
                self.connection.commit()
                return cursor.rowcount > 0
        except Error as e:
            print(f"Ошибка при обновлении записи: {e}")
            return False

    def delete_service_appointment(self, appointment_id):
        try:
            with self.connection.cursor() as cursor:
                sql = "DELETE FROM service_appointments WHERE id = %s"
                cursor.execute(sql, (appointment_id,))
                self.connection.commit()
                return cursor.rowcount > 0
        except Error as e:
            print(f"Ошибка при удалении записи: {e}")
            return False

    def check_time_availability(self, master_id, appointment_date, appointment_time, duration_hours):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                SELECT COUNT(*) as count
                FROM service_appointments 
                WHERE master_id = %s 
                AND appointment_date = %s 
                AND status IN ('запланировано', 'в работе')
                AND (
                    (appointment_time <= %s AND 
                     ADDTIME(appointment_time, SEC_TO_TIME(%s * 3600)) > %s)
                    OR (appointment_time < ADDTIME(%s, SEC_TO_TIME(%s * 3600)) AND 
                        ADDTIME(appointment_time, SEC_TO_TIME(duration_hours * 3600)) > %s)
                )
                """
                cursor.execute(sql, (master_id, appointment_date,
                                     appointment_time, duration_hours, appointment_time,
                                     appointment_time, duration_hours, appointment_time))
                result = cursor.fetchone()
                return result['count'] == 0
        except Error as e:
            print(f"Ошибка при проверке доступности времени: {e}")
            return False

    # Методы для регистрации
    def register_client(self, user_data, client_data):
        try:
            with self.connection.cursor() as cursor:
                user_sql = """
                INSERT INTO users (username, password, full_name, role, email, phone, birth_date)
                VALUES (%s, %s, %s, 'client', %s, %s, %s)
                """
                cursor.execute(user_sql, user_data)
                user_id = cursor.lastrowid

                client_sql = """
                INSERT INTO clients (user_id, driver_license, license_expiry, preferences)
                VALUES (%s, %s, %s, %s)
                """
                cursor.execute(client_sql, (user_id, *client_data))

                self.connection.commit()
                return user_id
        except Error as e:
            print(f"Ошибка при регистрации клиента: {e}")
            return None

    def add_master(self, master_data):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                INSERT INTO masters (
                    full_name, specialization, qualification, phone, email,
                    experience_years, work_schedule, hourly_rate
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                """
                cursor.execute(sql, master_data)
                self.connection.commit()
                return cursor.lastrowid
        except Error as e:
            print(f"Ошибка при добавлении мастера: {e}")
            return None

    def add_service(self, service_data):
        try:
            with self.connection.cursor() as cursor:
                sql = """
                INSERT INTO services (
                    service_name, category, description, duration_hours, price
                ) VALUES (%s, %s, %s, %s, %s)
                """
                cursor.execute(sql, service_data)
                self.connection.commit()
                return cursor.lastrowid
        except Error as e:
            print(f"Ошибка при добавлении услуги: {e}")
            return None

    def get_appointments_by_period(self, start_date, end_date):
        """Получение записей за период"""
        try:
            with self.connection.cursor() as cursor:
                sql = """
                SELECT sa.*, 
                       cl.id as client_id,
                       u.full_name as client_name, 
                       u.phone as client_phone,
                       m.full_name as master_name,
                       m.specialization as master_specialization,
                       ca.brand as car_brand,
                       ca.model as car_model,
                       ca.license_plate,
                       s.service_name,
                       DATE(sa.appointment_date) as appointment_date,
                       TIME(sa.appointment_time) as appointment_time
                FROM service_appointments sa
                JOIN clients cl ON sa.client_id = cl.id
                JOIN users u ON cl.user_id = u.id
                JOIN masters m ON sa.master_id = m.id
                JOIN cars ca ON sa.car_id = ca.id
                JOIN services s ON sa.service_id = s.id
                WHERE sa.appointment_date BETWEEN %s AND %s
                ORDER BY sa.appointment_date DESC, sa.appointment_time DESC
                """
                cursor.execute(sql, (start_date, end_date))
                appointments = cursor.fetchall()

                # Обработка данных (как в get_all_service_appointments)
                for appointment in appointments:
                    if appointment.get('appointment_date'):
                        if hasattr(appointment['appointment_date'], 'strftime'):
                            appointment['appointment_date'] = appointment['appointment_date'].strftime('%Y-%m-%d')

                    if appointment.get('appointment_time'):
                        if hasattr(appointment['appointment_time'], 'strftime'):
                            appointment['appointment_time'] = appointment['appointment_time'].strftime('%H:%M')
                        elif isinstance(appointment['appointment_time'], timedelta):
                            total_seconds = int(appointment['appointment_time'].total_seconds())
                            hours = total_seconds // 3600
                            minutes = (total_seconds % 3600) // 60
                            appointment['appointment_time'] = f"{hours:02d}:{minutes:02d}"

                    if 'total_price' in appointment:
                        appointment['total_price'] = float(appointment['total_price'])
                return appointments
        except Error as e:
            print(f"Ошибка при получении записей за период: {e}")
            return []

    def get_appointments_by_master(self, master_id):
        """Получение записей по мастеру"""
        try:
            with self.connection.cursor() as cursor:
                sql = """
                SELECT sa.*, 
                       cl.id as client_id,
                       u.full_name as client_name, 
                       u.phone as client_phone,
                       m.full_name as master_name,
                       m.specialization as master_specialization,
                       ca.brand as car_brand,
                       ca.model as car_model,
                       ca.license_plate,
                       s.service_name,
                       DATE(sa.appointment_date) as appointment_date,
                       TIME(sa.appointment_time) as appointment_time
                FROM service_appointments sa
                JOIN clients cl ON sa.client_id = cl.id
                JOIN users u ON cl.user_id = u.id
                JOIN masters m ON sa.master_id = m.id
                JOIN cars ca ON sa.car_id = ca.id
                JOIN services s ON sa.service_id = s.id
                WHERE sa.master_id = %s
                ORDER BY sa.appointment_date DESC, sa.appointment_time DESC
                """
                cursor.execute(sql, (master_id,))
                appointments = cursor.fetchall()

                # Обработка данных
                for appointment in appointments:
                    if appointment.get('appointment_date'):
                        if hasattr(appointment['appointment_date'], 'strftime'):
                            appointment['appointment_date'] = appointment['appointment_date'].strftime('%Y-%m-%d')

                    if appointment.get('appointment_time'):
                        if hasattr(appointment['appointment_time'], 'strftime'):
                            appointment['appointment_time'] = appointment['appointment_time'].strftime('%H:%M')
                        elif isinstance(appointment['appointment_time'], timedelta):
                            total_seconds = int(appointment['appointment_time'].total_seconds())
                            hours = total_seconds // 3600
                            minutes = (total_seconds % 3600) // 60
                            appointment['appointment_time'] = f"{hours:02d}:{minutes:02d}"

                    if 'total_price' in appointment:
                        appointment['total_price'] = float(appointment['total_price'])
                return appointments
        except Error as e:
            print(f"Ошибка при получении записей по мастеру: {e}")
            return []

    def get_appointments_by_service(self, service_id):
        """Получение записей по услуге"""
        try:
            with self.connection.cursor() as cursor:
                sql = """
                SELECT sa.*, 
                       cl.id as client_id,
                       u.full_name as client_name, 
                       u.phone as client_phone,
                       m.full_name as master_name,
                       m.specialization as master_specialization,
                       ca.brand as car_brand,
                       ca.model as car_model,
                       ca.license_plate,
                       s.service_name,
                       DATE(sa.appointment_date) as appointment_date,
                       TIME(sa.appointment_time) as appointment_time
                FROM service_appointments sa
                JOIN clients cl ON sa.client_id = cl.id
                JOIN users u ON cl.user_id = u.id
                JOIN masters m ON sa.master_id = m.id
                JOIN cars ca ON sa.car_id = ca.id
                JOIN services s ON sa.service_id = s.id
                WHERE sa.service_id = %s
                ORDER BY sa.appointment_date DESC, sa.appointment_time DESC
                """
                cursor.execute(sql, (service_id,))
                appointments = cursor.fetchall()

                # Обработка данных
                for appointment in appointments:
                    if appointment.get('appointment_date'):
                        if hasattr(appointment['appointment_date'], 'strftime'):
                            appointment['appointment_date'] = appointment['appointment_date'].strftime('%Y-%m-%d')

                    if appointment.get('appointment_time'):
                        if hasattr(appointment['appointment_time'], 'strftime'):
                            appointment['appointment_time'] = appointment['appointment_time'].strftime('%H:%M')
                        elif isinstance(appointment['appointment_time'], timedelta):
                            total_seconds = int(appointment['appointment_time'].total_seconds())
                            hours = total_seconds // 3600
                            minutes = (total_seconds % 3600) // 60
                            appointment['appointment_time'] = f"{hours:02d}:{minutes:02d}"

                    if 'total_price' in appointment:
                        appointment['total_price'] = float(appointment['total_price'])
                return appointments
        except Error as e:
            print(f"Ошибка при получении записей по услуге: {e}")
            return []