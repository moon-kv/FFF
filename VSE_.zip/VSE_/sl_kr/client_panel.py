from PyQt6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                             QTabWidget, QTableWidget, QTableWidgetItem, QPushButton,
                             QLabel, QLineEdit, QDateEdit, QComboBox, QTextEdit,
                             QGroupBox, QMessageBox, QHeaderView, QTimeEdit)
from PyQt6.QtCore import Qt, QDate, QTime
from PyQt6.QtGui import QFont, QColor
from pymysql import Error
from datetime import datetime, timedelta


class ClientPanel(QMainWindow):
    def __init__(self, db, user):
        super().__init__()
        self.db = db
        self.user = user
        self.client = None

        self.setWindowTitle(f"Клиентский портал - {user['full_name']}")
        self.setGeometry(100, 100, 1200, 700)

        self.load_client_data()
        self.setup_ui()

    def load_client_data(self):
        self.client = self.db.get_client_by_user_id(self.user['id'])
        if not self.client:
            QMessageBox.warning(self, "Внимание", "Профиль клиента не найден")

    def setup_ui(self):
        # Центральный виджет
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        # Основной layout
        main_layout = QVBoxLayout(central_widget)

        # Вкладки
        self.tabs = QTabWidget()

        # Создаем вкладки
        self.create_new_appointment_tab()
        self.create_my_appointments_tab()
        self.create_masters_tab()

        main_layout.addWidget(self.tabs)

    def create_new_appointment_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        # ФОРМА ЗАПИСИ НА ПРИЕМ
        appointment_group = QGroupBox("Новая запись на прием")
        appointment_layout = QVBoxLayout()

        # Выбор мастера и услуги
        selection_layout = QHBoxLayout()

        selection_layout.addWidget(QLabel("Мастер:"))
        self.client_master_combo = QComboBox()
        self.client_master_combo.setMinimumWidth(250)
        self.client_master_combo.currentIndexChanged.connect(self.update_client_services_combo)
        selection_layout.addWidget(self.client_master_combo)

        selection_layout.addWidget(QLabel("Услуга:"))
        self.client_service_combo = QComboBox()
        self.client_service_combo.setMinimumWidth(250)
        self.client_service_combo.currentIndexChanged.connect(self.update_client_duration_and_price)
        selection_layout.addWidget(self.client_service_combo)

        selection_layout.addStretch()
        appointment_layout.addLayout(selection_layout)

        # Выбор даты и времени
        datetime_layout = QHBoxLayout()

        datetime_layout.addWidget(QLabel("Дата:"))
        self.client_appointment_date = QDateEdit()
        self.client_appointment_date.setDate(QDate.currentDate().addDays(1))
        self.client_appointment_date.setCalendarPopup(True)
        self.client_appointment_date.setMinimumDate(QDate.currentDate())
        self.client_appointment_date.dateChanged.connect(self.client_check_time_availability)
        datetime_layout.addWidget(self.client_appointment_date)

        datetime_layout.addWidget(QLabel("Время:"))
        self.client_appointment_time = QTimeEdit()
        self.client_appointment_time.setTime(QTime(9, 0))
        self.client_appointment_time.timeChanged.connect(self.client_check_time_availability)
        datetime_layout.addWidget(self.client_appointment_time)

        datetime_layout.addStretch()
        appointment_layout.addLayout(datetime_layout)

        # Информация об услуге
        info_layout = QHBoxLayout()

        info_layout.addWidget(QLabel("Длительность (мин):"))
        self.client_duration_input = QLineEdit()
        self.client_duration_input.setReadOnly(True)
        self.client_duration_input.setMaximumWidth(80)
        info_layout.addWidget(self.client_duration_input)

        info_layout.addWidget(QLabel("Стоимость:"))
        self.client_price_input = QLineEdit()
        self.client_price_input.setReadOnly(True)
        self.client_price_input.setMaximumWidth(100)
        info_layout.addWidget(self.client_price_input)

        info_layout.addStretch()
        appointment_layout.addLayout(info_layout)

        # Примечания
        notes_layout = QHBoxLayout()
        notes_layout.addWidget(QLabel("Примечания:"))
        self.client_notes_text = QTextEdit()
        self.client_notes_text.setMaximumHeight(80)
        notes_layout.addWidget(self.client_notes_text)
        appointment_layout.addLayout(notes_layout)

        # Кнопка записи
        button_layout = QHBoxLayout()
        new_appointment_btn = QPushButton("Записаться на прием")
        new_appointment_btn.clicked.connect(self.create_new_appointment)
        button_layout.addWidget(new_appointment_btn)
        button_layout.addStretch()
        appointment_layout.addLayout(button_layout)

        appointment_group.setLayout(appointment_layout)
        layout.addWidget(appointment_group)

        self.tabs.addTab(tab, "Новая запись")

        # Загружаем начальные данные
        self.load_client_masters()
        self.update_client_services_combo()

    def create_my_appointments_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        # Таблица моих записей
        self.client_appointments_table = QTableWidget()
        self.client_appointments_table.setColumnCount(7)
        self.client_appointments_table.setHorizontalHeaderLabels([
            "ID", "Мастер", "Услуга", "Дата", "Время", "Стоимость", "Статус"
        ])

        header = self.client_appointments_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)  # Мастер
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)  # Услуга

        layout.addWidget(self.client_appointments_table)

        self.tabs.addTab(tab, "Мои записи")

        # Загружаем записи клиента
        if self.client:
            self.load_client_appointments()

    def create_masters_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        # Таблица мастеров
        self.client_masters_table = QTableWidget()
        self.client_masters_table.setColumnCount(5)
        self.client_masters_table.setHorizontalHeaderLabels([
            "ID", "ФИО", "Специализация", "Опыт (лет)", "График работы"
        ])

        header = self.client_masters_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)  # ФИО
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)  # Специализация

        layout.addWidget(self.client_masters_table)

        self.tabs.addTab(tab, "Наши мастера")

        # Загружаем мастеров
        self.load_client_masters_table()

    def load_client_masters(self):
        try:
            masters = self.db.get_all_masters()
            self.client_master_combo.clear()
            for master in masters:
                self.client_master_combo.addItem(
                    f"{master['full_name']} ({master['specialization']})",
                    master['id']
                )
        except Error as e:
            print(f"Ошибка при загрузке мастеров: {e}")

    def load_client_masters_table(self):
        try:
            masters = self.db.get_all_masters()
            self.client_masters_table.setRowCount(len(masters))

            for row, master in enumerate(masters):
                self.client_masters_table.setItem(row, 0, QTableWidgetItem(str(master['id'])))
                self.client_masters_table.setItem(row, 1, QTableWidgetItem(master['full_name']))
                self.client_masters_table.setItem(row, 2, QTableWidgetItem(master['specialization']))
                self.client_masters_table.setItem(row, 3, QTableWidgetItem(str(master.get('experience_years', ''))))
                self.client_masters_table.setItem(row, 4, QTableWidgetItem(master.get('work_schedule', '')))
        except Error as e:
            print(f"Ошибка при загрузке мастеров в таблицу: {e}")

    def update_client_services_combo(self):
        master_id = self.client_master_combo.currentData()
        if not master_id:
            return

        try:
            services = self.db.get_all_services()
            self.client_service_combo.clear()
            for service in services:
                self.client_service_combo.addItem(
                    f"{service['service_name']} - {float(service['price']):.2f} руб.",
                    (service['id'], service['duration_minutes'], service['price'])
                )
        except Error as e:
            print(f"Ошибка при обновлении списка услуг: {e}")

    def update_client_duration_and_price(self):
        current_data = self.client_service_combo.currentData()
        if current_data:
            service_id, duration, price = current_data
            self.client_duration_input.setText(str(duration))
            self.client_price_input.setText(f"{float(price):.2f}")

    def client_check_time_availability(self):
        master_id = self.client_master_combo.currentData()
        appointment_date = self.client_appointment_date.date().toString("yyyy-MM-dd")
        appointment_time = self.client_appointment_time.time().toString("HH:mm")
        duration_text = self.client_duration_input.text()

        if not master_id or not duration_text:
            return

        duration = int(duration_text)
        is_available = self.db.check_time_availability(
            master_id, appointment_date, appointment_time, duration
        )

        if not is_available:
            QMessageBox.warning(self, "Внимание", "Выбранное время уже занято. Пожалуйста, выберите другое время.")

    def create_new_appointment(self):
        if not self.client:
            QMessageBox.warning(self, "Ошибка", "Профиль клиента не найден")
            return

        master_id = self.client_master_combo.currentData()
        service_data = self.client_service_combo.currentData()

        if not master_id or not service_data:
            QMessageBox.warning(self, "Ошибка", "Выберите мастера и услугу")
            return

        service_id, duration, price = service_data
        appointment_date = self.client_appointment_date.date().toString("yyyy-MM-dd")
        appointment_time = self.client_appointment_time.time().toString("HH:mm")
        notes = self.client_notes_text.toPlainText()

        # Проверяем доступность времени
        is_available = self.db.check_time_availability(
            master_id, appointment_date, appointment_time, duration
        )

        if not is_available:
            QMessageBox.warning(self, "Ошибка", "Выбранное время уже занято")
            return

        appointment_data = (
            self.client['id'], master_id, service_id,
            appointment_date, appointment_time,
            duration, price, 'scheduled', notes
        )

        try:
            appointment_id = self.db.create_appointment(appointment_data)
            if appointment_id:
                QMessageBox.information(self, "Успех",
                                        f"Вы успешно записаны на прием! Номер записи: {appointment_id}")
                self.load_client_appointments()
                self.clear_client_appointment_form()
        except Error as e:
            print(f"Ошибка при создании записи: {e}")
            QMessageBox.critical(self, "Ошибка", "Не удалось создать запись")

    def load_client_appointments(self):
        if not self.client:
            return

        try:
            appointments = self.db.get_client_appointments(self.client['id'])
            self.client_appointments_table.setRowCount(len(appointments))

            for row, appointment in enumerate(appointments):
                self.client_appointments_table.setItem(row, 0, QTableWidgetItem(str(appointment.get('id', ''))))
                self.client_appointments_table.setItem(row, 1, QTableWidgetItem(appointment.get('master_name', '')))
                self.client_appointments_table.setItem(row, 2, QTableWidgetItem(appointment.get('service_name', '')))
                self.client_appointments_table.setItem(row, 3,
                                                       QTableWidgetItem(appointment.get('appointment_date', '')))
                self.client_appointments_table.setItem(row, 4,
                                                       QTableWidgetItem(appointment.get('appointment_time', '')))
                self.client_appointments_table.setItem(row, 5, QTableWidgetItem(
                    f"{float(appointment.get('total_price', 0)):.2f} руб."))

                status_item = QTableWidgetItem(appointment.get('status', ''))
                status_text = appointment.get('status', '')

                # Раскрашиваем статусы
                if status_text == 'completed':
                    status_item.setBackground(QColor(200, 255, 200))  # Зеленый
                elif status_text == 'cancelled':
                    status_item.setBackground(QColor(255, 200, 200))  # Красный
                elif status_text == 'no_show':
                    status_item.setBackground(QColor(255, 150, 150))  # Темно-красный
                elif status_text == 'scheduled':
                    status_item.setBackground(QColor(255, 255, 200))  # Желтый

                self.client_appointments_table.setItem(row, 6, status_item)
        except Error as e:
            print(f"Ошибка при загрузке записей клиента: {e}")

    def clear_client_appointment_form(self):
        self.client_appointment_date.setDate(QDate.currentDate().addDays(1))
        self.client_appointment_time.setTime(QTime(9, 0))
        self.client_notes_text.clear()
        self.client_duration_input.clear()
        self.client_price_input.clear()